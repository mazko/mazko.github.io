#include "contiki.h"
#include "contiki-net.h"
#if NETSTACK_CONF_WITH_IPV4
#include "dhcp-client.h"
#endif /* NETSTACK_CONF_WITH_IPV4 */
#include "draw.h"
#include "uip-debug.h"
#include "ip64-addr.h"
#include "assert.h"

/*---------------------------------------------------------------------------*/
PROCESS(display_process, "Display process");
/*---------------------------------------------------------------------------*/
#if NETSTACK_CONF_WITH_IPV4
/*---------------------------------------------------------------------------*/
static void draw_ip(const uint8_t p, const char* s, const uip_ipaddr_t *ip_addr) {
  draw_printf(1, p, "%s %u.%u.%u.%-21u" /* 128 / 6 = 21 chars max */, s,
  ip_addr->u8[0],
  ip_addr->u8[1],
  ip_addr->u8[2],
  ip_addr->u8[3]);
}
static void draw_ip4() {
  uip_ipaddr_t addr;
  uip_gethostaddr(&addr);
  draw_ip(2, "IP:", &addr);
  printf("IP Address:  %d.%d.%d.%d\n", uip_ipaddr_to_quad(&addr));
  uip_getnetmask(&addr);
  draw_ip(5, "MK:", &addr);
  printf("Subnet Mask: %d.%d.%d.%d\n", uip_ipaddr_to_quad(&addr));
  // uip_getdraddr(&addr);
  // draw_ip(7, "GW:", &addr);
}
/*---------------------------------------------------------------------------*/
#endif /* NETSTACK_CONF_WITH_IPV4 */
/*---------------------------------------------------------------------------*/
#if NETSTACK_CONF_WITH_IPV6
/*---------------------------------------------------------------------------*/
static void draw_ip6_hlpr(const uint8_t p, const uip_ipaddr_t *ip_addr) {
  draw_printf(1, p, "%x:%x:%x:%-21x" /* 128 / 6 = 21 chars max */,
    uip_htons(ip_addr->u16[0]),
    uip_htons(ip_addr->u16[1]),
    uip_htons(ip_addr->u16[2]),
    uip_htons(ip_addr->u16[3]));

  draw_printf(1, p+1, "%x:%x:%x:%-21x" /* 128 / 6 = 21 chars max */,
    uip_htons(ip_addr->u16[4]),
    uip_htons(ip_addr->u16[5]),
    uip_htons(ip_addr->u16[6]),
    uip_htons(ip_addr->u16[7]));
}
static void draw_ip6() {
  int i, j;
  int interface_count = 0;
  static int print_once;

  for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
    if(uip_ds6_if.addr_list[i].isused) {
      interface_count++;
    }
  }

  assert(interface_count > 0);

  if (print_once != interface_count) {
    print_once = interface_count;
    for(i = 0, j = 0; i < UIP_DS6_ADDR_NB; i++) {
      if(uip_ds6_if.addr_list[i].isused) {

        // draw display
        if (++j == 1) {
          draw_ip6_hlpr(0, &uip_ds6_if.addr_list[i].ipaddr);
        } else if (j == 2) {
          draw_ip6_hlpr(3, &uip_ds6_if.addr_list[i].ipaddr);
        } else if (j == 3) {
          draw_ip6_hlpr(6, &uip_ds6_if.addr_list[i].ipaddr);
        }

        printf("IPV6 Address: ");
        uip_debug_ipaddr_print(&uip_ds6_if.addr_list[i].ipaddr);
        printf("\n");
      }
    }
  }
}
/*---------------------------------------------------------------------------*/
#endif /* NETSTACK_CONF_WITH_IPV6 */
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(display_process, ev, data)
{
  PROCESS_BEGIN();

  #if NETSTACK_CONF_WITH_IPV6
  static struct etimer et;
  etimer_set(&et, 3*CLOCK_SECOND);
  #endif

  while(1) {

      PROCESS_WAIT_EVENT();

      #if NETSTACK_CONF_WITH_IPV4
      if (ev == dhcp_client_event_updated) {
        draw_ip4();
      }
      #else
      /* TODO: neighbor / route event */
      if (etimer_expired(&et)) {
        etimer_restart(&et);
        draw_ip6();
      }
      #endif
  }
  
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
