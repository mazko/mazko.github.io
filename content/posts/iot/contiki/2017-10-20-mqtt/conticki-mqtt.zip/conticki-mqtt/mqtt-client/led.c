#include "leds.h"
#include <msp430.h>


static void led_toggle_red() {
  P4OUT ^= 0xFF;
  P3OUT ^= (1 << 2) | (1 << 5);
}

static char led_status_red() {
  return P4OUT;
}

static void led_toggle_green() {
  P5OUT ^= 0xF0;
  P3OUT ^= (1 << 3) | (1 << 6);
}

static char led_status_green() {
  return P5OUT & 0xF0;
}

static void led_toggle_blue() {
  P6OUT ^= 0xFF;
  P3OUT ^= (1 << 4) | (1 << 7);
}

static char led_status_blue() {
  return P6OUT;
}


void leds_on(unsigned char c) {
  switch (c) {
    case LEDS_RED:
      if (!led_status_red()) {
        led_toggle_red();
      }
      break;
    case LEDS_GREEN:
      if (!led_status_green()) {
        led_toggle_green();
      }
      break;
    case LEDS_BLUE:
      if (!led_status_blue()) {
        led_toggle_blue();
      }
      break;
  }
}

void leds_off(unsigned char c) {
  switch (c) {
    case LEDS_RED:
      if (led_status_red()) {
        led_toggle_red();
      }
      break;
    case LEDS_GREEN:
      if (led_status_green()) {
        led_toggle_green();
      }
      break;
    case LEDS_BLUE:
      if (led_status_blue()) {
        led_toggle_blue();
      }
      break;
  }
}