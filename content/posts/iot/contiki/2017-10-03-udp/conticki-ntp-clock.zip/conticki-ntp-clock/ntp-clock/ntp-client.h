#ifndef __NTP_CLIENT_APP_H__
#define __NTP_CLIENT_APP_H__

#include "stdint.h"

clock_time_t ntp_get_timestamp();

#endif
