#ifndef LAN_H_
#define LAN_H_

#include <stdint.h>

typedef struct eth_frame {
	uint8_t to_addr[6];
	uint8_t from_addr[6];
	uint16_t type;
	uint8_t data[];
} eth_frame_t;

#ifdef CONFIG_IPV6

/** IPv6 header */
typedef struct ip_packet {
	/** Version (4 bits), Traffic class (8 bits), Flow label (20 bits) */
	uint32_t ver_tc_label;
	/** Payload length, including any extension headers */
	uint16_t payload_len;
	/** Next header type */
	uint8_t next_header;
	/** Hop limit */
	uint8_t hop_limit;
	/** Source address, Destination address */ 
	union {
	 uint8_t   u6_addr8 [16];
	 uint16_t  u6_addr16 [8];
	 uint32_t  u6_addr32 [4];
	} src, dest;

	uint8_t data[];
} ip_packet_t;

#else

typedef struct ip_packet {
	uint8_t ver_head_len;
	uint8_t tos;
	uint16_t total_len;
	uint16_t fragment_id;
	uint16_t flags_framgent_offset;
	uint8_t ttl;
	uint8_t protocol;
	uint16_t cksum;
	uint32_t from_addr;
	uint32_t to_addr;
	uint8_t data[];
} ip_packet_t;

#endif /* CONFIG_IPV6 */

typedef struct udp_packet {
	uint16_t from_port;
	uint16_t to_port;
	uint16_t len;
	uint16_t cksum;
	uint8_t data[];
} udp_packet_t;

void lan_init(void);
void lan_poll(void);

void udp_packet(eth_frame_t *frame, uint16_t len);
void udp_reply(eth_frame_t *frame, uint16_t len);

#endif /* LAN_H_ */