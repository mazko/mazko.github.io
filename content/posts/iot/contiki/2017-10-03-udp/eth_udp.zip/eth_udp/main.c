#include "hal/bsp.h"
#include "hal/uart0.h"
#include "hal/draw.h"
#include "lan.h"

#include <stdio.h>
#include <string.h>

void udp_packet(eth_frame_t *frame, uint16_t len)
{
	ip_packet_t *ip = (void*)(frame->data);
	udp_packet_t *udp = (void*)(ip->data);
	uint8_t *data = udp->data;
	uint16_t i;

	for(i = 0; i < len; ++i) {
		putchar(data[i]);
	}

	draw_clr();
	data[len - 1] = 0;
	draw_str(1, 0, (char*)data);

	const char* response = "!!! OK !!!\n";
	strcpy((char*)data, response);
	udp_reply(frame, strlen(response));
}

int main(void)
{
	bsp_init();
	uart0_init();
	lan_init();
	draw_init();

	printf("Start polling...\n");
	while(1)
		lan_poll();

	return 0;
}