#include "bsp.h"
#include <msp430.h>

void bsp_init(void) {
  WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

  // DCO = 7, RSEL = 7, f = 4.5 MHz
  DCOCTL = DCO2 + DCO1 + DCO0; 
  BCSCTL1 = XT2OFF + RSEL0 + RSEL1 + RSEL2;

  // leds
  P2OUT = 0; P3OUT = 0; P4OUT = 0; P5OUT = 0; P6OUT = 0;
  P2DIR = P3DIR = P4DIR = P5DIR = P6DIR = 0xFF;
}
