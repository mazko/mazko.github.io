/*
 * Copyright (c) 2012-2013, Thingsquare, http://www.thingsquare.com/.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "enc28j60.h"
#include <msp430.h>

void enc28j60_arch_spi_init() {
  // SPI
  P5OUT |= 0b1011;                     // P5(1,2,4) = SPI CS,SIMO,CLK
  P5DIR |= 0b1011;
  UCTL1 = CHAR + SYNC + MM + SWRST;    // 8-bit SPI Master **SWRST**
  UTCTL1 = CKPL + SSEL1 + SSEL0 + STC; // SMCLK, 3-pin mode
  UBR01 = 0x02;                        // UCLK/2
  UBR11 = 0x00;
  UMCTL1 = 0x00;                       // No modulation
  ME2 |= USPIE1;                       // Enable USART1 SPI mode
  UCTL1 &= ~SWRST;                     // Initialize USART state machine
}

uint8_t enc28j60_arch_spi_write(const uint8_t data) {
  while ( (IFG2&UTXIFG1) == 0 );    // wait while not ready for TX
  U1TXBUF = data;                   // write
  while ( (IFG2&URXIFG1) == 0 );    // wait for RX buffer (full)
  return U1RXBUF;
}

uint8_t enc28j60_arch_spi_read(void) {
  return enc28j60_arch_spi_write(0xff);
}

void enc28j60_arch_spi_select() {
  P5OUT &= ~1;
}

void enc28j60_arch_spi_deselect() {
  while(!(U1TCTL&TXEPT));
  P5OUT |= 1;
}