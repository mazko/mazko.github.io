#ifndef UART0_H_
#define UART0_H_

void uart0_writeb(unsigned char c);
void uart0_init(void);

#endif /* UART0_H_ */
