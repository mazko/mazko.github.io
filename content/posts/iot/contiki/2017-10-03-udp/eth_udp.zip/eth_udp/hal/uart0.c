/*
 * Machine dependent MSP430 UART0 code.
 */

#include "uart0.h"
#include <msp430.h>

void
uart0_init(void) {
    // USART
    P3SEL |= 0b110000;    // P3(4,5) = USART0 TXD/RXD
    ME1 |= UTXE0 + URXE0; // Enable USART0 TXD/RXD
    UCTL0 |= CHAR;        // 8-bit character
    UTCTL0 |= SSEL0;      // UCLK = ACLK = 32.768kHz
    UBR00 = 0x03;         // 32.768kHz/9600 - 3.41
    UBR10 = 0x00;
    UMCTL0 = 0x4a;        // Modulation
    UCTL0 &= ~SWRST;      // Initialize USART state machine
}

void
uart0_writeb(unsigned char c) {
    while (!(IFG1 & UTXIFG0)); // USART0 TX buffer ready?
    TXBUF0 = c;
}