import socket
import binascii

MCAST_GRP = '234.42.42.42'
MCAST_PORT = 7001

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)

def crc8(data):
  return binascii.crc32(data) & 0xFF

def transmit_one_byte(b):
  assert(1 <= b)
  assert(b <= 548) # 576(MTU) - 20(IP) - 8(UDP) 
  data = bytes(b)
  sock.sendto(data, (MCAST_GRP, MCAST_PORT))

preamble = [515, 514, 513, 512]
payload  = b'hello world!'

while True:
  for c in preamble:
    transmit_one_byte(c)
  transmit_one_byte(len(payload))
  transmit_one_byte(crc8(payload))
  for c in payload:
    transmit_one_byte(c)