import sys
import binascii

preamble = [515, 514, 513, 512]

def crc8(data):
  return binascii.crc32(data) & 0xFF

def decode(data, crc):
  try:
    data = bytes(data)
    if crc == crc8(data):
      print(data)
  except:
    pass

def parse(data):
  for idx, b in enumerate(data):
    if idx >= len(preamble):
      diff = set(k-i for i, k in zip(preamble, data[idx-len(preamble):idx]))
      if len(diff) == 1 and len(data) > idx + 1:
        c = diff.pop()
        l = data[idx] - c
        payload = [d-c for d in data[idx+1:idx+2+l]]
        decode(payload[1:], payload[0])

received = []

for line in sys.stdin:
  line = line.strip()
  if len(received) > 42:
    received.pop(0)
  if line.isdigit():
    received.append(int(line))
    parse(received)