# AP channel sgould math monitor channel
# sudo iwlist wlx98ded00f9a93 scanning
# iwconfig wlx98ded00f9a93 channel 4 # set channel
# iwlist wlx98ded00f9a93 channel # verify

tshark -i wlx98ded00f9a93 -I -T fields -e data.len subtype data | python3 receiver.py