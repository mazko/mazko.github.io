int  crond_init();
void crond_execute_pending();