#include <string.h>
#include "ssd1306.h"
#include "font.c"

#define STATIC_ASSERT(cond) typedef int foo[(cond) ? 1 : -1]
STATIC_ASSERT(sizeof(font) == 256 * 5 /* uint8_t values 0..255 == 256 */);
#undef STATIC_ASSERT


void draw_chr(const uint8_t x, const uint8_t page, const uint8_t c) {
  for (uint8_t i = 0; i < 5; i++ ) {
    ssd1306_write_byte(x + i, page, *(font+(c*5)+i));
  }
}


void draw_str(uint8_t x, uint8_t page, const char *s) {
  while (s && *s) {
    draw_chr(x, page, *s++);
    x += 6; // 6 pixels wide
    if (x + 6 >= SSD1306_X_PIXELS) {
      x = 0;    // ran out of this page
      page++;
    }
    if (page >= SSD1306_PIXEL_PAGES)
      break;        // ran out of space :(
  }
}


void draw_reset_cursor() {
    ssd1306_reset_cursor();
}


void draw_init() {
    ssd1306_init_display();
}