#include <stdint.h>

void draw_chr(const uint8_t x, const uint8_t page, const uint8_t c);
void draw_str(uint8_t x, uint8_t page, const char *s);
void draw_reset_cursor();
void draw_init();