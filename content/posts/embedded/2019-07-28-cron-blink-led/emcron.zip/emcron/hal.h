#include <stdint.h>
#include <stdbool.h>

void hal_init();
void hal_set_led(uint8_t n, bool r, bool g, bool b);