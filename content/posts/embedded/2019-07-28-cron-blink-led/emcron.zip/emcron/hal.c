#include <msp430.h>
#include <stdint.h>
#include <time.h>
#include "hal.h"

#define BSP_MCK         32768U
#define TICKS_PER_SEC   10U

typedef uint32_t systemticks_t;

static systemticks_t _ticks_ms;


// ISRs used in this project =================================================

void __attribute__ ((interrupt(TIMER0_A0_VECTOR))) TIMER0_A0_ISR (void) {
  _ticks_ms += 100;
}


void hal_init(void) {

  WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

  // DCO = 3, RSEL = 1, f = 0.18 MHz
  DCOCTL = /* DCO2 + */ DCO1 + DCO0; 
  BCSCTL1 = XT2OFF + RSEL0 /* + RSEL1 + RSEL2 */;

  // 8*RGB LEDS
  P4OUT = 0; P5OUT = 0; P6OUT = 0;
  P4DIR = P5DIR = P6DIR = 0xFF;

  // 2 RGB LEDS (pins 2..7) + LCD (pins 0,1)
  P3OUT = 0; P3DIR = 0xFF;
  // LCD data
  P2OUT = 0; P2DIR = 0xFF;

  // timer + isr

  /* Ensure the timer is stopped. */
  TACTL = 0;

  /* Run the timer of the ACLK. */
  TACTL = TASSEL_1;

  /* Clear everything to start with. */
  TACTL |= TACLR;

  /* Set the compare match value according to the tick rate we want. */
  TACCR0 = BSP_MCK / TICKS_PER_SEC;

  /* Enable the interrupts. */
  TACCTL0 = CCIE;

  /* Start up clean. */
  TACTL |= TACLR;

  /* Up mode. */
  TACTL |= MC_1;

  asm ("nop"); // makes compiler happy
  __enable_interrupt();
}


void hal_set_led(uint8_t n, bool r, bool g, bool b) {
  if(n < 8) {
    const uint8_t mask = 1 << n;
    P4OUT = r ? P4OUT | mask : P4OUT & ~mask;
    P5OUT = g ? P5OUT | mask : P5OUT & ~mask;
    P6OUT = b ? P6OUT | mask : P6OUT & ~mask;
  }
  else if (n == 8 || n == 9) {
    const uint8_t mask_r = n == 8 ? 0b100 : 0b100000,
                  mask_g = mask_r << 1,
                  mask_b = mask_g << 1;
    P3OUT = r ? P3OUT | mask_r : P3OUT & ~mask_r;
    P3OUT = g ? P3OUT | mask_g : P3OUT & ~mask_g;
    P3OUT = b ? P3OUT | mask_b : P3OUT & ~mask_b;
  }
}

static systemticks_t get_uptime_ms(void)
{
  const unsigned short stat_ = __get_interrupt_state();
  __disable_interrupt();

  const systemticks_t copy = _ticks_ms;

  __set_interrupt_state(stat_);
  asm ("nop"); // makes compiler happy

  return copy;
}


int gettimeofday (struct timeval *tv, void *tz)
{
  systemticks_t ticks = get_uptime_ms();
  tv->tv_usec = 0;
  tv->tv_sec = ticks / 1000;  // convert to seconds
  return 0;
}