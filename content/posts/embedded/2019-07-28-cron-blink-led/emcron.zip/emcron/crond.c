#include "crond.h"
#include <stdbool.h>
#include "ccronexpr/ccronexpr.h"
#include "hal.h"


struct crond_job {
  const char* expr;
  cron_expr  _expr;
  time_t      when;
  struct {
    uint16_t m;
    bool     r,g,b;
  } led;
};


static struct crond_job jobs[] = {
  { .expr = "*/6 */2 * * * *", .led = {0b0000011111, 1, 0, 0} },
  { .expr = "2/6 */2 * * * *", .led = {0b1111100000, 0, 1, 0} },
  { .expr = "4/6 */2 * * * *", .led = {0b1111111111, 0, 0, 1} },

  { .expr = "*/6 1/2 * * * *", .led = {0b1010101010, 1, 1, 0} },
  { .expr = "2/6 1/2 * * * *", .led = {0b0101010101, 0, 1, 1} },
  { .expr = "4/6 1/2 * * * *", .led = {0b1111111111, 1, 0, 1} },
};


int crond_init() {
  const time_t t = time(NULL);
  for(int i = 0; i < sizeof jobs / sizeof jobs[0]; i++) {
    struct crond_job* job = &jobs[i];
    const char *err = NULL;
    cron_parse_expr(job->expr, &job->_expr, &err);
    if(err) return i + 1;
    job->when = cron_next(&job->_expr, t);
  }
  return 0;
}


void crond_execute_pending() {
  const time_t t = time(NULL);
  for(int i = 0; i < sizeof jobs / sizeof jobs[0]; i++) {
    struct crond_job* job = &jobs[i];
    if(difftime(job->when, t) <= 0)
    {
      // TODO: man cron (Vixie Cron)
      // Special considerations exist when the clock is changed by less than 3 hours,
      // for example at the beginning and end of daylight savings time. If the time has
      // moved  forwards,  those  jobs which would have run in the time that was skipped
      // will be run soon after the change.  Conversely, if the time has moved backwards
      // by less than 3 hours, those jobs that fall into the repeated time will not be re-run.
      job->when = cron_next(&job->_expr, job->when);
      for(int8_t i = 0; i < 10 /* max leds */; i++) {
        if((1 << i) & job->led.m) {
          hal_set_led(i, job->led.r, job->led.g, job->led.b);
        }
      }
    }
  }
}