#include <time.h>
#include <string.h>
#include "hal.h"
#include "crond.h"
#include "draw/draw.h"


static void print_time() {
  draw_reset_cursor();
  char buf[50];
  time_t cur = time(NULL);
  ctime_r(&cur, buf);
  buf[strnlen(buf, sizeof buf) - 1] = 0; // rid of "\n"
  draw_str(0, 0, buf);
}

int main(void) {

    hal_init();
    draw_init();

    if(crond_init())
    {
      draw_str(0, 0, "crond_init error");
      return 0;
    }

    for(;;) {
      print_time();
      crond_execute_pending();
    }

    return 0;
}