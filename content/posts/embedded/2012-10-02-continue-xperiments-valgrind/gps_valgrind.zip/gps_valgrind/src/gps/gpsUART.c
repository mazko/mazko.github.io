#include "gps.h"

/************************************************************************
 *      Each NMEA sting begins with '$' and ends with <CR> and          *
 *      can't be longer than 80 characters of visible text              *
 ************************************************************************/

static char buf[81];

/************************************************************************
 *      Function Name:  getsGPS                                         *
 *      Return Value:   bool                                            *
 *      Parameters:     no                                              *
 *      Description:    This routine read each char while  "\r\n"       *
 *                      sequence not occur. Return true if no overflow  *
 ************************************************************************/

static bool getsGPS(void) {
	register char pt = 0;

	do {
		char c;
		switch(c = Read_UART()) {
			case '\n':
				if (pt) {
					char* prev = &buf[pt - 1];
					if(*prev == '\r') {
						*prev = 0;
						return true;
					}
				}
			default:
				if (pt < sizeof(buf)) buf[pt] = c; // FIX !!!
		}
	}
	while (++pt <= sizeof(buf));

	/* Overflow. Force ensure buf last char is null terminated char */
	
	buf[sizeof(buf) - 1] = 0;

	return false;
}
