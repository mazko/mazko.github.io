#include "gps.h"
#include <string.h>
#include <stdlib.h>

typedef struct 
{
    unsigned long Date, Time;
} DateTimeGPS;

/********************************************************************************
 *      Function Name:  TryGetDateTimeRMCGPS                                    *
 *      Return Value:   true if success, false if not                           *
 *      Parameters:     NMEA RMC string, DateTimeGPS structure, doSwap boolean  *
 *      Description:    Find date and time in RMC string ang fill DateTimeGPS   *
 ********************************************************************************/

bool TryGetDateTimeRMCGPS(const char* rmc, DateTimeGPS* datetime, bool doDateSwap) {
    const register char* s1 = strchr(rmc, ',');
    if (s1) {    
        datetime->Time = atol(s1 + 1);
        for (unsigned char c = 0; c < 8 && (s1 = strchr(s1 + 1, ',')); c++);
        if (s1) {
            if(doDateSwap) {
                char bufD[sizeof("130484")];
                memcpy(bufD, s1 + 1, sizeof(bufD) - 1);
                char swap;
                swap = bufD[0]; bufD[0] = bufD[4]; bufD[4] = swap;
                swap = bufD[1]; bufD[1] = bufD[5]; bufD[5] = swap;
                bufD[sizeof(bufD) - 1] = 0; // fixed NULL-terminating
                datetime->Date = atol(bufD);
            }
            else datetime->Date = atol(s1 + 1);

            return true;
        }
    }

    return false;
}
