#ifndef __GPS_H
#define __GPS_H

double haversine_km(double, double, double, double);
static bool getsGPS(void);

#endif /* __GPS_H */
