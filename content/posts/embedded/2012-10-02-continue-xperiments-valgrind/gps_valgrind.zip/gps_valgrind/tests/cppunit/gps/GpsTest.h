#ifndef __GPS_TEST_H
#define __GPS_TEST_H

#include <cppunit/extensions/HelperMacros.h>

class GpsTest : public CppUnit::TestFixture {
	CPPUNIT_TEST_SUITE( GpsTest );
	CPPUNIT_TEST( test_empty_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST( test_empty_swap_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST( test_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST( test_swap_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST( test_params_immutable_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST( test_params_immutable_swap_TryGetDateTimeRMCGPS );
	CPPUNIT_TEST_SUITE_END();
public:
	void test_empty_TryGetDateTimeRMCGPS();
	void test_empty_swap_TryGetDateTimeRMCGPS();
	void test_TryGetDateTimeRMCGPS();
	void test_swap_TryGetDateTimeRMCGPS();
	void test_params_immutable_TryGetDateTimeRMCGPS();
	void test_params_immutable_swap_TryGetDateTimeRMCGPS();
};

#endif  // __GPS_TEST_H
