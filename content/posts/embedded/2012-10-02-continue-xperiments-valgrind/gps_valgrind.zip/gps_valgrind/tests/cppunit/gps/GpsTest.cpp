#include "GpsTest.h"

extern "C"
{
	#include "../../../src/gps/gps.c"
}

CPPUNIT_TEST_SUITE_REGISTRATION( GpsTest );

#define VALID_TEST_RMC "$GPRMC,225446,A,4916.45,N,12311.12,W,000.5,054.7,191194,020.3,E*68"

DateTimeGPS dt;

void GpsTest::test_empty_TryGetDateTimeRMCGPS() {
	CPPUNIT_ASSERT(!TryGetDateTimeRMCGPS("", &dt, false));
	CPPUNIT_ASSERT(!TryGetDateTimeRMCGPS("$GPRMC,,,,,,,,", &dt, false));
}

void GpsTest::test_empty_swap_TryGetDateTimeRMCGPS() {
	CPPUNIT_ASSERT(!TryGetDateTimeRMCGPS("", &dt, true));
	CPPUNIT_ASSERT(!TryGetDateTimeRMCGPS("$GPRMC,,,,,,,,", &dt, true));
}

void GpsTest::test_TryGetDateTimeRMCGPS() {
	CPPUNIT_ASSERT(TryGetDateTimeRMCGPS(VALID_TEST_RMC, &dt, false));
	CPPUNIT_ASSERT_EQUAL( 191194ul, dt.Date );
	CPPUNIT_ASSERT_EQUAL( 225446ul, dt.Time );
}

void GpsTest::test_swap_TryGetDateTimeRMCGPS() {
	CPPUNIT_ASSERT(TryGetDateTimeRMCGPS(VALID_TEST_RMC, &dt, true));
	CPPUNIT_ASSERT_EQUAL( 941119ul, dt.Date );
	CPPUNIT_ASSERT_EQUAL( 225446ul, dt.Time );
}

void template_params_immutable_TryGetDateTimeRMCGPS(bool doSwap) {
	const char* rmc = "";
	dt.Date = 1;
	dt.Time = 2;
	TryGetDateTimeRMCGPS(rmc, &dt, doSwap);
	CPPUNIT_ASSERT( std::string("") == rmc );
	CPPUNIT_ASSERT_EQUAL( 1ul, dt.Date );
	CPPUNIT_ASSERT_EQUAL( 2ul, dt.Time );
	rmc = VALID_TEST_RMC;
	TryGetDateTimeRMCGPS(rmc, &dt, doSwap);
	CPPUNIT_ASSERT( std::string(VALID_TEST_RMC) == rmc );
}

void GpsTest::test_params_immutable_TryGetDateTimeRMCGPS() {
	template_params_immutable_TryGetDateTimeRMCGPS(false);
}

void GpsTest::test_params_immutable_swap_TryGetDateTimeRMCGPS() {
	template_params_immutable_TryGetDateTimeRMCGPS(true);
}
