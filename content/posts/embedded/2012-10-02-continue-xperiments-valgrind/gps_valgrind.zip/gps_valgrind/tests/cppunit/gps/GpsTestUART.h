#ifndef __GPS_TEST_UART_H
#define __GPS_TEST_UART_H

#include <cppunit/extensions/HelperMacros.h>

class GpsTestUART : public CppUnit::TestFixture {
	CPPUNIT_TEST_SUITE( GpsTestUART );
	CPPUNIT_TEST( test_getsGPS );
	CPPUNIT_TEST( test_rn_getsGPS );
	CPPUNIT_TEST( test_max_getsGPS );
	CPPUNIT_TEST( test_overflow_no_rn_empty_getsGPS );
	CPPUNIT_TEST( test_overflow_no_rn_dollar_getsGPS );
	CPPUNIT_TEST( test_overflow_no_rn_getsGPS );
	CPPUNIT_TEST_SUITE_END();
public:
	void test_getsGPS();
	void test_rn_getsGPS();
	void test_max_getsGPS();
	void test_overflow_no_rn_empty_getsGPS();
	void test_overflow_no_rn_dollar_getsGPS();
	void test_overflow_no_rn_getsGPS();
};

#endif  // __GPS_TEST_UART_H
