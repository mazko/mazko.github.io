#define FAKE_UART_FILL_BUFFER(c)                \
        fakeuartbuf = c;                        \
        fakeuartbuf_s1 = 0

static const char* fakeuartbuf;
static unsigned int fakeuartbuf_s1;

static char Read_UART() {
	if(!fakeuartbuf[fakeuartbuf_s1]) {
		fakeuartbuf_s1 = 0;
	}

	return fakeuartbuf[fakeuartbuf_s1++];
}
