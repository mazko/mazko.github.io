#!/bin/bash

cd "`dirname "${0}"`"

bash build.sh

./a.out

rm -f a.out
