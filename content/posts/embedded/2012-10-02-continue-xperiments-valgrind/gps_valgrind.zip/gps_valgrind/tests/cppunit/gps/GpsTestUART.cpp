#include "GpsTestUART.h"

extern "C"
{
	#include "fakeuart.c"
	#include "../../../src/gps/gpsUART.c"
}

CPPUNIT_TEST_SUITE_REGISTRATION( GpsTestUART );
const int MAX_NMEA_LENGTH = 80;

void GpsTestUART::test_rn_getsGPS() {
	FAKE_UART_FILL_BUFFER("\r\n");
	CPPUNIT_ASSERT(getsGPS());
	CPPUNIT_ASSERT(std::string("") == buf);
}

void GpsTestUART::test_getsGPS() {

	#define GPRMC_FAKE                                              \
	        "$GPRMC,220516,A,5133.82,N,00042.24,W,173.8,"           \
	        "231.8,130694,004.2,W*70"

	FAKE_UART_FILL_BUFFER(GPRMC_FAKE "\r\n");
	CPPUNIT_ASSERT(getsGPS());
	CPPUNIT_ASSERT(std::string(GPRMC_FAKE) == buf);

	#undef GPRMC_FAKE
}

void GpsTestUART::test_max_getsGPS() {

	#define GPRMC_FAKE                                              \
	        "$GPRMC,145932.000,A,4836.5976,N,03433.7255,"           \
	        "E,0.25,0.00,080711,xxxxxx,xxxxxx,A*68"

	CPPUNIT_ASSERT(std::string(GPRMC_FAKE).length() == MAX_NMEA_LENGTH);

	FAKE_UART_FILL_BUFFER(GPRMC_FAKE "\r\n");
	CPPUNIT_ASSERT(getsGPS());
	CPPUNIT_ASSERT(std::string(GPRMC_FAKE) == buf);

	#undef GPRMC_FAKE
}

void GpsTestUART::test_overflow_no_rn_empty_getsGPS() {
	FAKE_UART_FILL_BUFFER("");
	CPPUNIT_ASSERT(!getsGPS());
	CPPUNIT_ASSERT(std::string("") == buf);
}

void GpsTestUART::test_overflow_no_rn_dollar_getsGPS() {
	FAKE_UART_FILL_BUFFER("$");
	CPPUNIT_ASSERT(!getsGPS());
	CPPUNIT_ASSERT(std::string(
		&std::vector<char>(MAX_NMEA_LENGTH,'$')
			.front(), MAX_NMEA_LENGTH) == buf);
}

void GpsTestUART::test_overflow_no_rn_getsGPS() {

	#define GPRMC_OVERFLOW                                          \
	        "$GPRMC,145932.000,A,4836.5976,N,03433.7255,"           \
	        "E,0.25,0.00,080711,xxxxxx,xxxxxx,A*68"

	CPPUNIT_ASSERT(std::string(GPRMC_OVERFLOW).length() == MAX_NMEA_LENGTH);

	FAKE_UART_FILL_BUFFER(GPRMC_OVERFLOW "\n\r");
	CPPUNIT_ASSERT(!getsGPS());
	CPPUNIT_ASSERT(std::string(GPRMC_OVERFLOW) == buf);

	#undef GPRMC_OVERFLOW
}
