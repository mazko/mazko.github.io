#include <FreeRTOS.h>
#include <task.h>

#include "draw.h"


void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed portCHAR *pcTaskName );
void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed portCHAR *pcTaskName ) {
  taskDISABLE_INTERRUPTS(); // game over
  
  draw_clr();
  draw_str(1, 0,  "Error: StackOverflow");
  draw_str(1, 2,  "Task Name:");
  draw_str(1 + (6 * sizeof("Task Name:")), 2,  (char*)pcTaskName);

  for( ;; );
}


void vApplicationMallocFailedHook( void );
void vApplicationMallocFailedHook( void ) {
  taskDISABLE_INTERRUPTS(); // game over

  draw_clr();
  draw_str(1, 0,  "Error: MallocFailed");

  for( ;; );
}


void vAssertCalled( unsigned long ulLine, const char * const pcFileName ) {
  taskDISABLE_INTERRUPTS(); // game over

  draw_clr();
  draw_str(1, 0,  "Error: AssertCalled");
  draw_str(1, 2,  "File Name:");
  draw_str(1, 3,  pcFileName);
  draw_str_hex(5, "Line:", ulLine);

  for( ;; );
}