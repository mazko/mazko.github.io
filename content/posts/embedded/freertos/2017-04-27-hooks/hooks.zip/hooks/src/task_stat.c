#include <FreeRTOS.h>
#include <task.h>

#include "draw.h"
#include "task_stat.h"


void vTaskStat( void *pvParameters ) {

    // once
    for (uint8_t i = 0; i < (128 / 6); i++) {
      draw_char(1 + (i * 6) , 3, '-');
    }

    draw_str_hex(4, "portBASE_TYPE", sizeof(portBASE_TYPE));
    draw_str_hex(5, "portTickType", sizeof(portTickType));
    draw_str_hex(6, "tick rate (Hz)", configTICK_RATE_HZ);

    // loop
    for( ;; ) {
      draw_str_hex(0, "uptime", xTaskGetTickCount());
      draw_str_hex(1, "freeHeapSize", xPortGetFreeHeapSize());
      draw_str_hex(2, "numberOfTasks", uxTaskGetNumberOfTasks());
    }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}
