#include "draw.h"
#include <stdbool.h>
#include <stdlib.h>

#include "ssd1306.h"
#include "font.c"


void draw_char(const uint8_t x, const uint8_t page, const char c) {
  for (uint8_t i = 0; i < 5; i++ ) {
    ssd1306_write_byte(x + i, page, *(font+(c*5)+i));
  }
}


void draw_str(uint8_t x, uint8_t page, const char* s) {
  while (s && *s) {
    draw_char(x, page, *s++);
    x += 6;     // 6 pixels wide
    if (x + 6 >= SSD1306_X_PIXELS) {
      x = 0;    // ran out of this page
      page++;
    }
    if (page >= SSD1306_PIXEL_PAGES)
      break;    // ran out of space :(
  }
}


void draw_str_hex(const uint8_t p, const char* const m, const uint16_t v) {

  // TODO: FreeRtos Inappropriate Use of printf() and sprintf() ?
  char b[1 + sizeof(v) * 2 /* hex maxByte == FF */];

  draw_str(1, p,  m);
  utoa(v, b, 16);
  b[ sizeof(v) * 2 ] = '\0';
  draw_str(1 + (6 * 15), p,  "0x");
  draw_str(1 + (6 * 17), p,  b);
}


void draw_clr() {
  ssd1306_clear_screen();
}


void draw_init() {
  ssd1306_init_display();
}
