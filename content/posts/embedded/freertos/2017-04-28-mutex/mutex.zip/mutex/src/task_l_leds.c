#include <FreeRTOS.h>
#include <task.h>

#include "task_l_leds.h"

volatile xSemaphoreHandle xP4P5P6Mutex;
static portTickType xLastWakeTime;

static void rotate_rgb(volatile uint8_t * const port) {
    for (uint8_t i = 0; i < 6; i++) {

      /* Attempt to take the mutex, blocking indefinitely to wait for the mutex */
      xSemaphoreTake( xP4P5P6Mutex, portMAX_DELAY );
      
      *port = (*port & ~0b11111) | (0b10000 >> i);

      /* The mutex MUST be given back! */
      xSemaphoreGive( xP4P5P6Mutex );

      vTaskDelayUntil( &xLastWakeTime, 5 /* ticks */ );
    }
}


void vTaskLedsL( void *pvParameters ) {

   xLastWakeTime = xTaskGetTickCount();

   for( ;; ) {
     rotate_rgb(&P4OUT);
     rotate_rgb(&P5OUT);
     rotate_rgb(&P6OUT);
   }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}