#include <FreeRTOS.h>
#include <task.h>

#include "task_r_leds.h"


void vTaskLedsR( void *pvParameters ) {
   for( ;; ) {
     P3OUT = (P3OUT ^ 0xFF) & ~0b11 /* don't toggle LCD pins 0b11 */;
     vTaskDelay(15 /* ticks */);
   }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}