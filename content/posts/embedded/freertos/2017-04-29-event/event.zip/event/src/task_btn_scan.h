void vTaskScanBtns( void *pvParameters );

#include <queue.h>

extern volatile QueueHandle_t xQueueBtnsL, xQueueBtnsR;