void vTaskStat( void *pvParameters );

#include <FreeRTOS.h>
#include <semphr.h>

extern volatile xSemaphoreHandle xP3Mutex;