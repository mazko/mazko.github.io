#include <FreeRTOS.h>
#include <task.h>

#include "task_btn_scan.h"


volatile QueueHandle_t xQueueBtnsL, xQueueBtnsR;


void vTaskScanBtns( void *pvParameters ) {
  for( ;; ) {
    while (!P1IN); // button pushed

    if (P1IN & 0b1111) {
      /* Send a char to the queue. Don't block if the queue is already full 
         (the third parameter is zero, so not block time is specified). */
      configASSERT( xQueueSend( xQueueBtnsL, ( void * ) &P1IN, 0 ) == pdPASS );
    } else {
      configASSERT( xQueueSend( xQueueBtnsR, ( void * ) &P1IN, 0 ) == pdPASS );
    }

    while (P1IN);  // button released
  }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}