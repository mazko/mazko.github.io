void btn_scan_init(void);

#include <FreeRTOS.h>
#include <queue.h>

extern volatile QueueHandle_t xQueueBtnsL, xQueueBtnsR;
