#include "btn_scan.h"


volatile QueueHandle_t xQueueBtnsL, xQueueBtnsR;


void btn_scan_init() {
  // clear the interrupt flag
  P1IFG = 0;
  // enable interrupt on BIT 0..7
  P1IE  = 0xFF;
}


void __attribute__ ((interrupt(PORT1_VECTOR))) Port1_ISR (void);
void __attribute__ ((interrupt(PORT1_VECTOR))) Port1_ISR (void) {
  P1IFG = 0;  // clear the interrupt flag

  BaseType_t xHigherPriorityTaskWoken;

  /* xHigherPriorityTaskWoken must be initialised to pdFALSE. */
  xHigherPriorityTaskWoken = pdFALSE;

  if (P1IN & 0b1111) {
    configASSERT( xQueueSendFromISR( 
        xQueueBtnsL, ( void * ) &P1IN, &xHigherPriorityTaskWoken ) == pdPASS );
  } else {
    configASSERT( xQueueSendFromISR( 
        xQueueBtnsR, ( void * ) &P1IN, &xHigherPriorityTaskWoken ) == pdPASS );
  }

  /* If xHigherPriorityTaskWoken is now set to pdTRUE then a context
     switch should be requested. */
  portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
}