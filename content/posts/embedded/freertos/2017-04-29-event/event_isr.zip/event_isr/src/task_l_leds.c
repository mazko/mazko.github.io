#include <FreeRTOS.h>
#include <task.h>

#include "task_l_leds.h"
#include "btn_scan.h" // queues


volatile xSemaphoreHandle xP4P5P6Mutex;

// C99
// an object that has static storage duration is not initialized explicitly, then:
// — if it has pointer type, it is initialized to a null pointer;
static volatile uint8_t * port;


void vTaskLedsL( void *pvParameters ) {

   for( ;; ) {

      uint8_t button;

      // portMAX_DELAY will cause the task to wait indefinitely
      // (without timing out) provided INCLUDE_vTaskSuspend is set to 1
      portBASE_TYPE xStatus = xQueueReceive( xQueueBtnsL, &button, port ? 10 : portMAX_DELAY );

      /* Attempt to take the mutex, blocking indefinitely to wait for the mutex */
      xSemaphoreTake( xP4P5P6Mutex, portMAX_DELAY );

      if ( xStatus == pdPASS ) {
        // set leds color
        switch (button) {
          case 0b10:   /* red blink */
            P5OUT &= ~0b11111;
            P6OUT &= ~0b11111;
            port = &P4OUT;
            break;
          case 0b100:  /* green blink */
            P4OUT &= ~0b11111;
            P6OUT &= ~0b11111;
            port = &P5OUT;
            break;
          case 0b1000: /* blue blink */
            P4OUT &= ~0b11111;
            P5OUT &= ~0b11111;
            port = &P6OUT;
            break;
          case 0b1:    /* off blink */
            P4OUT &= ~0b11111;
            P5OUT &= ~0b11111;
            P6OUT &= ~0b11111;
            port = NULL;
            break;  
        }
      } 

      if (port) {
        *port = (*port & ~0b11111) | ((*port ^ 0b11111) & 0b11111);
      }

      /* The mutex MUST be given back! */
      xSemaphoreGive( xP4P5P6Mutex );
   }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}