#include "RightToLeftState.h"
#include "RightToLeftBrightState.h"
#include "HAL.h"

static void onRightToLeftTickImpl(GarlandStatePtr statePtr) {
	nextLeftLed(); // in HAL.h
}

static void onRightToLeftNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	setStateRightToLeftBright(statePtr);
}

void setStateRightToLeft(GarlandStatePtr statePtr) {
	defaultEventHandlersImpl(statePtr);
	statePtr->tickFunc = onRightToLeftTickImpl;
	statePtr->nextFunc = onRightToLeftNextImpl;
	statePtr->name = "RightToLeftState";
}
