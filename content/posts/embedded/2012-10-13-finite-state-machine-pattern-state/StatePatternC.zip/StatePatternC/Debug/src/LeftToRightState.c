#include "LeftToRightState.h"
#include "RightToLeftState.h"
#include "HAL.h"

static void onLeftToRightTickImpl(GarlandStatePtr statePtr) {
	nextRightLed(); // in HAL.h
}

static void onLeftToRightNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	setStateRightToLeft(statePtr);
}

void setStateLeftToRight(GarlandStatePtr statePtr) {
	defaultEventHandlersImpl(statePtr);
	statePtr->tickFunc = onLeftToRightTickImpl;
	statePtr->nextFunc = onLeftToRightNextImpl;
	statePtr->name = "LeftToRightState";
}
