#include "RightToLeftState.h"
#include "LeftToRightState.h"
#include "HAL.h"

static void onRightToLeftTickImpl(GarlandStatePtr statePtr) {
	nextLeftLed(); // in HAL.h
}

static void onRightToLeftNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	setStateLeftToRight(statePtr);
}

void setStateRightToLeft(GarlandStatePtr statePtr) {
	defaultEventHandlersImpl(statePtr);
	statePtr->tickFunc = onRightToLeftTickImpl;
	statePtr->nextFunc = onRightToLeftNextImpl;
}
