#ifndef __GARLAND_CONTEXT_H
#define __GARLAND_CONTEXT_H

/* Интерфейс управления гирляндой */

void garlandTick();

void garlandNext();

#endif
