#include "GarlandContext.h"
#include "GarlandState.h"
#include "RightToLeftState.h"

/* Начальное состояние справа налево */

static void tick_ctor(GarlandStatePtr statePtr) {
	setStateRightToLeft(statePtr);
	garlandTick();
}

static void next_ctor(GarlandStatePtr statePtr) {
	setStateRightToLeft(statePtr);
	garlandNext();
}

/* 
   В _garlandState хранится текущее состояние.
   HI-TECH PICC не понимает {.tickFunc=tick_ctor, .nextFunc=next_ctor}.
   (C99) разрешает "tagged" инициализацию полей структуры по имени.
*/

static struct GarlandState _garlandState = {tick_ctor, next_ctor};

void garlandTick() {
	_garlandState.tickFunc(&_garlandState);
}

void garlandNext() {
	_garlandState.nextFunc(&_garlandState);
}
