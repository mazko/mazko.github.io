#ifndef __HARDWARE_LAYER_IMPLEMENTATION_H
#define __HARDWARE_LAYER_IMPLEMENTATION_H

void nextLeftLed();

void nextRightLed();

void resetLeds();

void initHardware();

char isNextButtonPressed();

#endif
