#ifndef __GARLAND_STATE_H
#define __GARLAND_STATE_H

/* Неполный тип GarlandState для компиляции Events typedefs */

typedef struct GarlandState* GarlandStatePtr;

/* Events typedefs */

typedef void (*EventTickFunc)(GarlandStatePtr);
typedef void (*EventNextFunc)(GarlandStatePtr);

struct GarlandState {
	EventTickFunc tickFunc;
	EventNextFunc nextFunc;
};

/* Обработчики событий по умолчанию */

void defaultEventHandlersImpl(GarlandStatePtr);

#endif
