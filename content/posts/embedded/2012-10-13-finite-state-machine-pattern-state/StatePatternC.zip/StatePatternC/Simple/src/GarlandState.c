#include "GarlandState.h"

static void defaultTick(GarlandStatePtr statePtr) {
	/* Обработка события Tick по умолчанию */
}

static void defaultNext(GarlandStatePtr statePtr) {
	/* Обработка события Next по умолчанию */
}

void defaultEventHandlersImpl(GarlandStatePtr statePtr) {
	statePtr->tickFunc = defaultTick;
	statePtr->nextFunc = defaultNext;
}
