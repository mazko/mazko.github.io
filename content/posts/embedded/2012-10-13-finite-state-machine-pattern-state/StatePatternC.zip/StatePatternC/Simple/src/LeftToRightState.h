#ifndef __LEFT_TO_RIGHT_STATE_H
#define __LEFT_TO_RIGHT_STATE_H

#include "GarlandState.h"

void setStateLeftToRight(GarlandStatePtr);

#endif
