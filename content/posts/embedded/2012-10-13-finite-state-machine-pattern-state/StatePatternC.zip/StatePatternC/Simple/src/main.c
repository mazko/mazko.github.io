#include "HAL.h"
#include "GarlandContext.h"

void main (void) {

	initHardware(); // in main.h

	for (;;) {

		/* Сканируем кнопку. Если нажата событие NEXT */

 		for (unsigned int i = 5000; i; i--) {
			if (isNextButtonPressed()) {
				garlandNext();
				i = 5000;
			} 
		}

		/* Пришло время события TICK */

		garlandTick();
	}
}
