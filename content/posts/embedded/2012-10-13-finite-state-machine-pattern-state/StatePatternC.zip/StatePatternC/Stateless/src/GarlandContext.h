#ifndef __GARLAND_CONTEXT_H
#define __GARLAND_CONTEXT_H

#include "GarlandState.h"

/* Интерфейс управления гирляндой */

void garlandTick();

void garlandNext();

void changeState(GarlandStatePtr);

#endif
