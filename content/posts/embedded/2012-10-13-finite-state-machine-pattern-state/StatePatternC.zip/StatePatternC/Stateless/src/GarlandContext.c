#include "GarlandContext.h"
#include "RightToLeftState.h"
#include <stdio.h> // NULL

static GarlandStatePtr _garlandStatePtr = NULL;

void garlandTick() {
	if (!_garlandStatePtr) {

		/* Начальное состояние справа налево */

		_garlandStatePtr = getStateRightToLeft();
	}
	_garlandStatePtr->tickFunc(_garlandStatePtr);
}

void garlandNext() {
	if (!_garlandStatePtr) {

		/* Начальное состояние справа налево */

		_garlandStatePtr = getStateRightToLeft();
	}
	_garlandStatePtr->nextFunc(_garlandStatePtr);
}

/* Обратный вызов для смены состояния */

void changeState(GarlandStatePtr newStatePtr) {
	_garlandStatePtr = newStatePtr;
}
