#ifndef __RIGHT_TO_LEFT_STATE_H
#define __RIGHT_TO_LEFT_STATE_H

#include "GarlandState.h"

GarlandStatePtr getStateRightToLeft();

#endif
