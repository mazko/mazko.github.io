#ifndef __GARLAND_STATE_H
#define __GARLAND_STATE_H

/* Неполный тип GarlandState для компиляции Events typedefs. Stateless == const !!! */

typedef struct GarlandState const* GarlandStatePtr;

/* Events typedefs */

typedef void (*EventTickFunc)(GarlandStatePtr);
typedef void (*EventNextFunc)(GarlandStatePtr);

struct GarlandState {
	EventTickFunc tickFunc;
	EventNextFunc nextFunc;
	const char* name;
};

/* Обработчики событий по умолчанию */

void defaultEventHandlersImpl(struct GarlandState*);

#endif
