#include "LeftToRightState.h"
#include "RightToLeftState.h"
#include "GarlandContext.h"

#include "HAL.h"

static void onLeftToRightTickImpl(GarlandStatePtr statePtr) {
	nextRightLed(); // in HAL.h
}

static void onLeftToRightNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	changeState(getStateRightToLeft());
}

GarlandStatePtr getStateLeftToRight() {
	static struct GarlandState garlandState;
	static bit initialized = 0;
	if (!initialized) {
		defaultEventHandlersImpl(&garlandState);
		garlandState.tickFunc = onLeftToRightTickImpl;
		garlandState.nextFunc = onLeftToRightNextImpl;
		garlandState.name = "LeftToRightState";

		initialized = 1;
	}
	return &garlandState;
}
