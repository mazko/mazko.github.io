#include "RightToLeftBrightState.h"
#include "LeftToRightState.h"
#include "GarlandContext.h"

#include "HAL.h"

static void onRightToLeftBrightTickImpl(GarlandStatePtr statePtr) {
	nextLeftBrightLed(); // in HAL.h
}

static void onRightToLeftBrightNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	changeState(getStateLeftToRight());
}

GarlandStatePtr getStateRightToLeftBright() {
	static struct GarlandState garlandState;
	static bit initialized = 0;
	if (!initialized) {
		defaultEventHandlersImpl(&garlandState);
		garlandState.tickFunc = onRightToLeftBrightTickImpl;
		garlandState.nextFunc = onRightToLeftBrightNextImpl;
		garlandState.name = "RightToLeftBrightState";

		initialized = 1;
	}
	return &garlandState;
}
