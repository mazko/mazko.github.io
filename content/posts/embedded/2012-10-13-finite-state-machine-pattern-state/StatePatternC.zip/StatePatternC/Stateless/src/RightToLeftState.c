#include "RightToLeftState.h"
#include "RightToLeftBrightState.h"
#include "GarlandContext.h"

#include "HAL.h"

static void onRightToLeftTickImpl(GarlandStatePtr statePtr) {
	nextLeftLed(); // in HAL.h
}

static void onRightToLeftNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	changeState(getStateRightToLeftBright());
}

GarlandStatePtr getStateRightToLeft() {
	static struct GarlandState garlandState;
	static bit initialized = 0;
	if (!initialized) {
		defaultEventHandlersImpl(&garlandState);
		garlandState.tickFunc = onRightToLeftTickImpl;
		garlandState.nextFunc = onRightToLeftNextImpl;
		garlandState.name = "RightToLeftState";

		initialized = 1;
	}
	return &garlandState;
}
