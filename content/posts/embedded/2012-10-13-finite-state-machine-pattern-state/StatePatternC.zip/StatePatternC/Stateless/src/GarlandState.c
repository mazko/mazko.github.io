#include "GarlandState.h"
#include "HAL.h"

static void defaultTick(GarlandStatePtr statePtr) {
	/* Обработка события Tick по умолчанию */
	signalError("Tick", statePtr->name);
}

static void defaultNext(GarlandStatePtr statePtr) {
	/* Обработка события Next по умолчанию */
	signalError("Next", statePtr->name);
}

void defaultEventHandlersImpl(struct GarlandState* statePtr) {
	statePtr->tickFunc = defaultTick;
	statePtr->nextFunc = defaultNext;
}
