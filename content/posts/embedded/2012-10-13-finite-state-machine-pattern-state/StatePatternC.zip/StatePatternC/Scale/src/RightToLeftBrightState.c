#include "RightToLeftBrightState.h"
#include "LeftToRightState.h"
#include "HAL.h"

static void onRightToLeftBrightTickImpl(GarlandStatePtr statePtr) {
	nextLeftBrightLed(); // in HAL.h
}

static void onRightToLeftBrightNextImpl(GarlandStatePtr statePtr) {
	resetLeds(); // in HAL.h
	setStateLeftToRight(statePtr);
}

void setStateRightToLeftBright(GarlandStatePtr statePtr) {
	defaultEventHandlersImpl(statePtr);
	statePtr->tickFunc = onRightToLeftBrightTickImpl;
	statePtr->nextFunc = onRightToLeftBrightNextImpl;
}
