#ifndef estd_config_gnu_h_
#define estd_config_gnu_h_

/*
 * Compiler details for the GNU compiler
 */

#define HAS_STDINT_H_
//#define HAS_CSTDINT_H_

#endif /* estd_config_gnu_h_ */
