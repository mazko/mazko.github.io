#include <stdint.h>

namespace draw {

    class Food {
        static uint16_t random();
    public:
        // TODO: use C++11 delegating constructors for better encapsulation
        Food(const uint16_t id = random());
        const int8_t x;
        const int8_t y;
    };

    class Snake {
        struct Pimpl* _pimpl;
        struct { int8_t dx; int8_t dy; } _direction;
        uint16_t get_next_id() const;
    public:
        Snake();
        void set_direction(const int8_t dx, const int8_t dy);
        bool move();
        void eat();
        bool can_eat(const int8_t x, const int8_t y) const;
        bool obsticle(const int8_t dx, const int8_t dy);
        void get_head(int& h, int& w) const;
    };

    void character(const uint8_t x, const uint8_t page, const char c);
    void str(uint8_t x, uint8_t page, const char* s);
    void str_hex(const uint8_t, const char* s, const uint16_t);

    void clr(void);
    void init(void);
}
