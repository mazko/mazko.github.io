About The QP-MSP430 Port
========================
This directory contains the QP/C port to the MSP430 processor family
with the IAR-430 compiler.
