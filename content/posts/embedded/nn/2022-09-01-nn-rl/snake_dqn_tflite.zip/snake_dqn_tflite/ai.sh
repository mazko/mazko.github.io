#!/bin/bash

set -e
set -u

cd "`dirname "${BASH_SOURCE[0]}"`"

export LC_ALL=C

if [ ! -d '/tmp/snakeai-tflite-runtime' ]
then
  python -m venv '/tmp/snakeai-tflite-runtime'
  . '/tmp/snakeai-tflite-runtime/bin/activate'
  pip install 'tflite-runtime'
  deactivate
fi

. '/tmp/snakeai-tflite-runtime/bin/activate'

python -c '
import time
import tflite_runtime.interpreter as tflite
import numpy as np
import snake_game

class SnakeEnv(snake_game.SnakeGame):
  # food = [1, 0, 0], head = [0, 1, 0], body = [0, 0, 1]
  def get_state(self):
    arr = np.zeros((self.board_height, self.board_width, 3), int)
    if not self.done:
      state = super().get_state()
      arr[state.food.h, state.food.w,             0] = True
      arr[state.snake.head.h, state.snake.head.w, 1] = True
      for b in state.snake.body: arr[b.h, b.w,    2] = True
    return arr.tolist()

interpreter = tflite.Interpreter("snake.dqn.cnn.tflite")
interpreter.allocate_tensors()

def nn(input_data, test=None):
  input = interpreter.get_input_details()[0]["index"]
  output = interpreter.get_output_details()[0]["index"]
  input_data = np.float32(input_data)
  input_data = np.expand_dims(input_data, axis=0)
  interpreter.set_tensor(input, input_data)
  interpreter.invoke()
  output_data = interpreter.get_tensor(output)
  if test:
    for i, j in zip(output_data.squeeze(), test):
      if abs(i - j) > 3e-4:
        raise AssertionError(str(i) + " != " + str(j))
  return output_data.argmax()

nn(16*[32*[3*[0]]], [   5.945457 ,    6.3849316,    6.178444 ,    6.3890877])
nn(16*[32*[3*[1]]], [  -8.02034  , -200.62529  ,  -95.14251  ,   97.191635 ])

try:
  env = SnakeEnv(gui = True)
  state = env.reset()
  while not env.done:
    time.sleep(0.2)
    state, *done_reward, info = env.step(nn(state))
except KeyboardInterrupt:
  pass

env.end_game()
state = snake_game.SnakeGame.get_state(env)
*state, info = map(tuple, (state.snake.head, *state.snake.body, state.food, info))
print(*state, *done_reward, info)
'
