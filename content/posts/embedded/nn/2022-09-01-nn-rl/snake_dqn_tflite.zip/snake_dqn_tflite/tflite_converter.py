#!/usr/bin/env python3

import tensorflow as tf
import json
import gzip
import numpy as np
import sys

if len(sys.argv) != 2:
  sys.exit("wrong args")

model = tf.keras.models.load_model(sys.argv[1] + '/TF2_DDQN_Snake_CNN/chkpnt/model/')

with gzip.open(sys.argv[1] + '/TF2_DDQN_Snake_CNN/best.weights.gz', 'rb') as f:
  model.set_weights([np.array(w) for w in json.load(f)])

converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

with open('snake.dqn.cnn.tflite', 'wb') as f:
  f.write(tflite_model)
