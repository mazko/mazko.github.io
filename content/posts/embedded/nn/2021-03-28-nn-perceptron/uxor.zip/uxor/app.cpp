#include <stdio.h>
#include "float32.hpp"
#include "nn.h"
#include "draw.h"

using flt = float32;

static float inference(const flt& x1, const flt& x2)
{
  const nn::m<flt, 2, 3> W1
  {
    -0.100219101, 0.0986418799, 0.0540673025,
    -0.101571321, 0.055912815, -0.0540193357
  };
  const nn::i<flt, 3> B1
  {
    0.101785883, -0.0555998087, -7.84907461e-05
  };
  const nn::m<flt, 3, 1> W2
  {
    -85.8035507, -90.0149384, 87.0291138
  };
  const nn::i<flt, 1> B2
  {
    4.28154087
  };

  // Inputs
  nn::i<flt, 2> x{x1, x2};

  // First layer has 3 units
  nn::o<flt, 3> L1;
  nn::dot(W1, x, L1);
  nn::add(B1, L1);
  nn::relu(L1);

  // Second layer has 1 unit
  nn::o<flt, 1> L2;
  nn::dot(W2, L1, L2);
  nn::add(B2, L2);
  nn::sigmoid(L2);
  return L2.at(0);
}

namespace app {

  int run() {
    draw::flt(draw::PAGE_0, inference(0, 0));
    draw::flt(draw::PAGE_2, inference(0, 1));
    draw::flt(draw::PAGE_4, inference(1, 0));
    draw::flt(draw::PAGE_6, inference(1, 1));
    return 0;
  }
}

