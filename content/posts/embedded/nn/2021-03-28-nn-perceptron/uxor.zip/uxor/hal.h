namespace hal {

  void init();

}