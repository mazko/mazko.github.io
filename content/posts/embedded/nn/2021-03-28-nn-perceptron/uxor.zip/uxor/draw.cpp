#include "draw.h"
#include "ssd1306.h"
#include <cstdio>

namespace draw {

    void character(const uint8_t x, const uint8_t page, const char c) {
        #include "font.cpp"
        static_assert(sizeof(font) == 256 * 5 /* uint8_t values 0..255 == 256 */, "WTF");
        for (uint8_t i = 0; i < 5; i++ ) {
          ssd1306::write_byte(x + i, page, *(font+(c*5)+i));
        }
    }

    void str(uint8_t page, const char* s) {
      str(1, page, s);
    }

    void str(uint8_t x, uint8_t page, const char* s) {
        while (s && *s) {
            character(x, page, *s++);
            x += 6;     // 6 pixels wide
            if (x + 6 >= SSD1306_X_PIXELS) {
              x = 0;    // ran out of this page
              page++;
            }
            if (page >= SSD1306_PIXEL_PAGES)
              break;    // ran out of space :(
         }
    }

    void str_hex(const uint8_t p, const char* const m, const uint16_t v) {
      str(1, p,  m);
      char buf[2 + 4 + 1];
      snprintf(buf, sizeof buf, "0x%04hX", v);
      str(1 + (6 * 15), p,  buf);
    }

    void str_hex(const uint8_t p, const char* const m, const uint32_t v) {
      str(1, p,  m);
      char buf[2 + 8 + 1];
      snprintf(buf, sizeof buf, "0x%08lX", v);
      str(1 + (6 * 11), p,  buf);
    }

    void flt(const uint8_t p, const float v) {
      union {
        float f;
        struct {
          uint32_t      : 31;
          uint32_t sign : 1;
        } parts;
      } cast;
      cast.f = v;
      cast.parts.sign = 0; // abs
      uint32_t x = cast.f;
      uint32_t y = 1000000.0 * (cast.f - x);
      char buf[42];
      snprintf(buf, sizeof buf, "%s%lu.%06lu", v < 0 ? "-" : "", x, y);
      str(1, p,  buf);
    }

    void clr() {
        ssd1306::clear_screen();
    }


    void init() {
        ssd1306::init_display();
    }

}
