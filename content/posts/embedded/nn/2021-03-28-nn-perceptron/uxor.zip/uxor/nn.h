#include <cmath>
#include <array>

namespace nn {

  template<typename T, size_t N>
  using o = std::array<T, N>;

  template<typename T, size_t N>
  using i = const o<T, N>;

  template<typename T, size_t N, size_t K>
  using m = i<i<T, K>, N>;

  template<typename T, size_t N, size_t K>
  void dot(m<T, N, K> & x, i<T, N> & y, o<T, K> & o)
  {
    for (size_t c = 0, r; c < K; c++)
      for (r = 0, o.at(c) = 0; r < N; r++)
        o.at(c) += x.at(r).at(c) * y.at(r);
  }

  template<typename T, size_t N>
  void relu(o<T, N> & x)
  {
    const T zero = 0;
    for (size_t i = 0; i < N; i++)
      x.at(i) = std::max(x.at(i), zero);
  }

  template<typename T, size_t N>
  void add(i<T, N> & y, o<T, N> & x)
  {
    for (size_t i = 0; i < N; i++)
      x.at(i) = x.at(i) + y.at(i);
  }

  template<typename T, size_t N>
  void sigmoid(o<T, N> & x)
  {
    const T one = 1;
    for (size_t i = 0; i < N; i++)
      x.at(i) = one / (one + std::exp(-x.at(i)));
  }

} // namespace
