#include "hal.h"
#include "app.h"
#include "draw.h"

int main(void) {

    hal::init();
    draw::init();

    return app::run();
}