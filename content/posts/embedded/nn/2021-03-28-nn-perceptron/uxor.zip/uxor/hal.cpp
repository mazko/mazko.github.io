#include <msp430.h>
#include "hal.h"

namespace hal {

    void init() {
        WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

        // DCO = 3, RSEL = 0, f = 0.13 MHz
        DCOCTL = /* DCO2 + */ DCO1 + DCO0;
        BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

        // Shared between L/R tasks 8*RGB LEDS
        P4OUT = 0; P5OUT = 0; P6OUT = 0;
        P4DIR = P5DIR = P6DIR = 0xFF;

        // 2 RGB LEDS (pins 2..7) + LCD (pins 0,1)
        P3OUT = 0; P3DIR = 0xFF;
        // LCD data
        P2OUT = 0; P2DIR = 0xFF;
    }
}