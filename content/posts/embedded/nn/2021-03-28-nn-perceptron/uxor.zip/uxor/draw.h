#include <stdint.h>

namespace draw {
    void character(const uint8_t x, const uint8_t page, const char c);
    void str(uint8_t x, uint8_t page, const char* s);
    void str(uint8_t page, const char* s);
    void str_hex(const uint8_t page, const char* s, const uint16_t v);
    void str_hex(const uint8_t page, const char* s, const uint32_t v);
    void flt(const uint8_t page, const float v);

    void clr(void);
    void init(void);

    enum { PAGE_0, PAGE_1, PAGE_2, PAGE_3, PAGE_4, PAGE_5, PAGE_6, PAGE_7 };
}
