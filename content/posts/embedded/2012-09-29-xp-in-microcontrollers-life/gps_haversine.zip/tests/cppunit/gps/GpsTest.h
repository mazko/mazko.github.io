#ifndef __GPS_TEST_H
#define __GPS_TEST_H

#include <cppunit/extensions/HelperMacros.h>

class GpsTest : public CppUnit::TestFixture {
	CPPUNIT_TEST_SUITE( GpsTest );
	CPPUNIT_TEST( test_haversine_km_params_immutable );
	CPPUNIT_TEST( test_haversine_km_zero );
	CPPUNIT_TEST( test_haversine_km_params_positive );
	CPPUNIT_TEST( test_haversine_km_params_negative );
	CPPUNIT_TEST( test_haversine_km_lat1_negative );
	CPPUNIT_TEST( test_haversine_km_lon1_negative );
	CPPUNIT_TEST( test_haversine_km_lat2_negative );
	CPPUNIT_TEST( test_haversine_km_lon2_negative );
	CPPUNIT_TEST_SUITE_END();
public:
	void test_haversine_km_params_immutable();
	void test_haversine_km_zero();
	void test_haversine_km_params_positive();
	void test_haversine_km_params_negative();
	void test_haversine_km_lat1_negative();
	void test_haversine_km_lon1_negative();
	void test_haversine_km_lat2_negative();
	void test_haversine_km_lon2_negative();
};

#endif  // __GPS_TEST_H
