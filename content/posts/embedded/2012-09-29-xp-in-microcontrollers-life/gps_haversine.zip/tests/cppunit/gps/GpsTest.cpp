#include "GpsTest.h"

extern "C"
{
	#include "../../../src/gps/gps.c"
}

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( GpsTest );

/* Функция не должна изменять значение передаваемых параметров */

void GpsTest::test_haversine_km_params_immutable() {
	double lat1 = 0.1, lon1 = 3.1, lat2 = -0.1, lon2 = -3.1;
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 689.8, haversine_km(lat1, lon1, lat2, lon2), 0.5 );
	CPPUNIT_ASSERT_EQUAL(0.1, lat1);
	CPPUNIT_ASSERT_EQUAL(3.1, lon1);
	CPPUNIT_ASSERT_EQUAL(-0.1, lat2);
	CPPUNIT_ASSERT_EQUAL(-3.1, lon2);
}

/* Расстояние между одинаковыми точками ноль */

void GpsTest::test_haversine_km_zero() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 0, haversine_km(0, 0, 0, 0), 0 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 0, haversine_km(1.5, 10, 1.5, 10), 0 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 0, haversine_km(-10, 1.5, -10, 1.5), 0 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 0, haversine_km(-90, 180, -90, 180), 0 );
}

void GpsTest::test_haversine_km_params_positive() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 122.4, haversine_km(49, 33, 48.6092, 34.5622), 0.1 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.12, haversine_km(0.1, 0, 0, 0), 0.1 );
}

void GpsTest::test_haversine_km_params_negative() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 122.4, haversine_km(-48.6092, -34.5622, -49, -33), 0.1 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 31.45, haversine_km(-0.1, -0.2, -0.3, -0.4), 0.1 );
}

void GpsTest::test_haversine_km_lat1_negative() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 10850, haversine_km(-48.6092, 34.5622, 49, 33), 2.2 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.12, haversine_km(-0.1, 0, 0, 0), 0.1 );
}

void GpsTest::test_haversine_km_lon1_negative() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 4778, haversine_km(48.6092, -34.5622, 49, 33), 3.5 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.73, haversine_km(0.1, -0.1, 0, 0), 0.1 );
}

void GpsTest::test_haversine_km_lat2_negative() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 12630, haversine_km(48.6092, 34.5622, -49, -33), 4.5 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.73, haversine_km(0, 0, -0.1, 0.1), 0.1 );
}

void GpsTest::test_haversine_km_lon2_negative() {
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 10850, haversine_km(48.6092, 34.5622, -49, 33), 2.2 );
	CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.12, haversine_km(0, 0, 0, -0.1), 0.1 );
}
