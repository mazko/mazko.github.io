#!/bin/bash

cd "`dirname "${0}"`"

#When a source file is compiled with -g, the compiler attaches DWARF3 debugging information which describes the location of all stack and global arrays in the file

g++ -g -ldl main.cpp gps/GpsTest.cpp -lcppunit
