#include <math.h>

/************************************************************************
 *      Function Name:  haversine_km                                    *
 *      Return Value:   Double                                          *
 *      Parameters:     Two coordinates                                 *
 *      Description:    Calculate haversine distance for linear         *
 *                      distance                                        *
 ************************************************************************/

double haversine_km(double lat1, double long1, double lat2, double long2)
{
	#define d2r (3.141592 / 180.0)
	#define sindif(v1, v2) sin(((v1 - v2) * d2r) / 2.0)

	double sdlong = sindif(long2, long1);
	double sdlat  = sindif(lat2, lat1);
	lat1 *= d2r;
	lat2 *= d2r;
	sdlong *= sdlong;
	sdlat  *= sdlat;
	double a = sdlat + cos(lat1) * cos(lat2) * sdlong;

	return 6367 * 2 * atan2(sqrt(a), sqrt(1 - a));
}
