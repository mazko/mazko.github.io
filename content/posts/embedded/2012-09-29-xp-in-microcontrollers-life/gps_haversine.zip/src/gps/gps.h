#ifndef __GPS_H
#define __GPS_H

double haversine_km(double, double, double, double);

#endif /* __GPS_H */
