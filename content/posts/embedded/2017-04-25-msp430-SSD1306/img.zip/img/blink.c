/*

reset && (export GCC_DIR=~/ti/msp430_gcc ; 
    $GCC_DIR/bin/msp430-elf-gcc \
    -I $GCC_DIR/include -L $GCC_DIR/include \
    -Werror -Wall -mmcu=msp430f1611 -O2 blink.c ssd1306.c)

*/


#include <msp430.h>
#include <stdint.h>


#include "ssd1306.h"
#include "images.c"


static void demo_show_image (void) {
  ssd1306_reset_cursor ();

  for (uint8_t page = 0; page < SSD1306_PIXEL_PAGES; page++) {
    for (uint8_t column = 0; column < SSD1306_X_PIXELS; column++) {
      ssd1306_write_data (image[page][column]);
    }
  }
  __delay_cycles(300000);
}


static void demo_set_power_state (void) {
  ssd1306_set_power_state (POWER_STATE_SLEEP);
  __delay_cycles(200000);
  ssd1306_set_power_state (POWER_STATE_ON);
  __delay_cycles(200000);
}


static void demo_set_contrast (void) {
  for (uint16_t contrast = 0; contrast <= 255; contrast++) {
    ssd1306_set_contrast (contrast);
    __delay_cycles(1000);
  }
}


static void demo_set_byte_direct (void) {
  ssd1306_clear_screen ();
  uint8_t x = 0;
  for (uint8_t page = 0; page < SSD1306_PIXEL_PAGES; ++page)
  {
    for (x = 0; x < SSD1306_X_PIXELS; x += 2)
    {
      ssd1306_write_byte (x, page, 0xAA);
    }
  }
  __delay_cycles(300000);
}


static void demo_rotate_display (void) {
  for (uint8_t i = DISP_ORIENT_NORMAL;
                  i <= DISP_ORIENT_UPSIDE_DOWN_MIRRORED; ++i)
  {
    ssd1306_set_display_orientation (i);
    __delay_cycles(200000);
  }
  ssd1306_set_display_orientation (DISP_ORIENT_NORMAL);
}


static void demo_invert_image () {
  ssd1306_set_display_mode (DISPLAY_MODE_INVERTED);
  // Check inverted contrast works
  demo_set_contrast ();
      ssd1306_set_display_mode (DISPLAY_MODE_NORMAL);
  // Check inverted contrast works
  demo_set_contrast ();
}


int main(void) {
    WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

    // DCO = 3, RSEL = 0, f = 0.13 MHz
    DCOCTL = /* DCO2 + */ DCO1 + DCO0; 
    BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

    P2OUT = 0; P3OUT = 0;
    P2DIR = P3DIR = 0xFF;

    ssd1306_init_display();

    for(;;) {
      demo_set_byte_direct ();
      demo_show_image ();
      demo_set_power_state();
      demo_set_contrast();
      demo_rotate_display ();
      demo_invert_image ();
    }

    return 0;
}