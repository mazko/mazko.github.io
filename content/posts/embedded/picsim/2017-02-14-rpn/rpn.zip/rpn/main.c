/*

  re2c -o rpn.c rpn.re.c && \
  xc8 -D_XTAL_FREQ=5e5 -DRPN_MAX_CHARS=16 --float=32 \
      --chip=18f4620 main.c liquid-crystal.c keyboard.c rpn.c

*/

#include <xc.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <string.h>
#include "config-4620.h"
#include "getstr.c"
#include "print.c"

bool rpn(const char *, float * const);

int main() {
  // lcd
  PORTD = TRISD = 0;
  PORTE = TRISE = 0;

  // matrix keyboard: PORTB AN8..AN12 as digital
  ADCON1bits.PCFG0 = ADCON1bits.PCFG1 =
  ADCON1bits.PCFG2 = 1;
  PORTB = TRISB = 0xF0;

  lcd_init();
  lcd_no_cursor();
  lcd_no_blink();

  const char* h = "help: 7 4 2 + *";
  printf("%s", h);

  while(1) {
    const char* s = getstr();
    lcd_no_cursor();
    lcd_no_blink();
    lcd_set_cursor(0, 0);
    printf("%-16s", *s ? s : h);
    lcd_set_cursor(0, 1);
    float x;
    if (rpn(s, &x)) {
      printf("%-16s", *s ? "error :(" : "");
    } else {
      printf("%16g", x);
    }
    if (*s) {
      lcd_set_cursor(strlen(s), 0);
      lcd_cursor();
      lcd_blink();
    }
  }

  return 0;
}