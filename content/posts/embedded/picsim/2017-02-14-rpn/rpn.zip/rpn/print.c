#include <stdint.h>

void lcd_dat(const uint8_t);
void lcd_set_cursor(const uint8_t, uint8_t);
void lcd_home();
void lcd_no_cursor();
void lcd_no_blink();
void lcd_cursor();
void lcd_blink();
void lcd_init();

// http://microchip.wikidot.com/faq:29
void putch(const uint8_t byte) {
  lcd_dat(byte);
}