#include <stdint.h>

char keyboad_get_or_0();

static char getchr() {
  for (;;) {
    const char c = keyboad_get_or_0();
    if (c != '\0') {
      return c;
    }
  }
}

static const char* getstr() {
  static char buffer[RPN_MAX_CHARS + 1];
  static uint8_t p;

  for (;;) {
    const char c = getchr();
    if (c == '$') {
      if (p) {
        buffer[--p] = '\0';
        return buffer;
      }
    } else {
      if (p < RPN_MAX_CHARS) {
        if (p && c == '#' && (buffer[p - 1] == ' ' || buffer[p - 1] == '.')) {
          p -= 1;
        } 
        buffer[p] = c != '#' ? c : buffer[p] == ' ' ? '.' : ' ';
        buffer[++p] = '\0';
        return buffer;
      }
    }
  }
}