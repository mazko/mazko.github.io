#include <xc.h>
#include "HD44780.h"

#define LCD_EN_PIN  PORTEbits.RE1
#define LCD_RS_PIN  PORTEbits.RE2
#define LCD_PORT    PORTD

#define _LCD_DEFAULT_STATE_DISPLAYCONTROL (LCD_DISPLAYON | LCD_CURSORON | LCD_BLINKON)
#define _LCD_DEFAULT_STATE_DISPLAYMODE    (LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT)

static void _lcd_wr(const unsigned char val) {
  LCD_PORT = val;
}

static void _lcd_en_pulse() {
  __delay_ms(3);
  LCD_EN_PIN = 0;
  __delay_ms(3);
  LCD_EN_PIN = 1;
}

void lcd_cmd(const unsigned char val) {
  _lcd_wr(val);
  LCD_RS_PIN = 0;
  _lcd_en_pulse();
}

void lcd_dat(const unsigned char val) {
  _lcd_wr(val);
  LCD_RS_PIN = 1;
  _lcd_en_pulse();
}

void lcd_init() {
  // SEE PAGE 45/46 FOR INITIALIZATION SPECIFICATION!
  // according to datasheet, we need at least 40ms after power rises above 2.7V
  __delay_ms(40);

  LCD_RS_PIN = 0;
  LCD_EN_PIN = 1;

  // this is according to the hitachi HD44780 datasheet
  // page 45 figure 23
  lcd_cmd(LCD_FUNCTIONSET | LCD_8BITMODE);
  __delay_ms(5);
  lcd_cmd(LCD_FUNCTIONSET | LCD_8BITMODE);
  __delay_ms(1);
  lcd_cmd(LCD_FUNCTIONSET | LCD_8BITMODE);

  // finally, set # lines, font size, etc.
  lcd_cmd(LCD_FUNCTIONSET | LCD_8BITMODE | LCD_2LINE);

  // turn the display off
  lcd_cmd(LCD_DISPLAYCONTROL | LCD_DISPLAYOFF);

  lcd_cmd(LCD_CLEARDISPLAY); // clear display, set cursor position to zero
  __delay_ms(2);             // this command takes a long time!

  // turn the display on with default cursor and blinking
  lcd_cmd(LCD_DISPLAYCONTROL | _LCD_DEFAULT_STATE_DISPLAYCONTROL);

  // Initialize to default text direction (for romance languages)
  lcd_cmd(LCD_ENTRYMODESET | _LCD_DEFAULT_STATE_DISPLAYMODE);
}