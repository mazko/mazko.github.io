#include <xc.h>
#include <stdint.h>

static char _keyboard_scan() {

  const char key_code[4][4] = {
    {'1','2','3','+'},
    {'4','5','6','-'},
    {'7','8','9','/'},
    {'*','0','#','$'}};

  for(uint8_t r = 0; r < sizeof key_code / sizeof *key_code; r++) {
    // set PORTB and some delay for voltage to rise / fall
    PORTB = ~(1 << r);
    __delay_ms(1);

    for(uint8_t c = 0; c < sizeof *key_code / sizeof **key_code; c++) {
      if (!(PORTB & (0x80 >> c))) {
        return key_code[r][c];
      }
    }
  }

  return 0;
}

char keyboad_get_or_0() {
  static char _last_key;

  const char key = _keyboard_scan();
  if (key) {
    _last_key = key;
  } else if (_last_key) {
    const char key = _last_key;
    _last_key = 0;
    return key;
  }
  return 0;
}