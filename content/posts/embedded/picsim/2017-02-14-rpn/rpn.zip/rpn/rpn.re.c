#include <stdbool.h>
#include "stack.c"


// 0 == SUCCESS
static bool lex_flt(const char *s, const char * const e, float * const f) {
  float x = 1;
  bool neg = false;
  *f = 0;

  /*!re2c
      re2c:yyfill:enable = 0;
      re2c:define:YYCTYPE = char;
      re2c:define:YYCURSOR = s;

      "-"    { neg = true; goto mant_int; }
      ""     { goto mant_int; }
  */
mant_int:
  /*!re2c
      "."    { goto mant_frac; }
      ""     { goto end; }
      [0-9]  { *f = (*f * 10) + (s[-1] - '0'); goto mant_int; }
  */
mant_frac:
  /*!re2c
      ""     { goto end; }
      [0-9]  { *f += (x /= 10) * (s[-1] - '0'); goto mant_frac; }
  */
end:
  if (neg) {
    *f *= -1;
  }
  
  return e != s;
}


// 0 == SUCCESS
bool cc(const char c) {
  float o1, o2;
  if (!stack_pop(&o2) && !stack_pop(&o1)) {
    switch (c) {
      case '+': return stack_push(o1 + o2);
      case '-': return stack_push(o1 - o2);
      case '/': return o2 == 0 || stack_push(o1 / o2);
      case '*': return stack_push(o1 * o2);
    }
  } 
  return true;
}


// 0 == SUCCESS
static bool lex(const char * cur) {
  
  // YYMARKER is needed because rules overlap:
  // it backups input position of the longest successful match
  const char *YYMARKER;

  for(;;) {
    const char *tok = cur;
    float f;
    /*!re2c
        re2c:yyfill:enable = 0;
        re2c:define:YYCTYPE = char;
        re2c:define:YYCURSOR = cur;

        flt = "-" ? ([0-9]+ | [0-9]* "." [0-9]+);
        mop = [-+*\/];

        *       { return true; }
        "\x00"  { return false; }
        flt     { if (lex_flt(tok, cur, &f) || stack_push(f)) return true; continue; }
        " " flt { if (lex_flt(tok + 1, cur, &f) || stack_push(f)) return true; continue; }
        mop     { if (cc(*tok)) return true; continue; }
        " " mop { if (cc(*(tok + 1))) return true; continue; }
    */
  }

}


// 0 == SUCCESS
bool rpn(const char * cur, float * const f) {
  stack_clr();
  return lex(cur) || stack_pop(f);
}

