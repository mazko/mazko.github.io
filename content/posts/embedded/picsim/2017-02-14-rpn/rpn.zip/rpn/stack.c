#include <stdint.h>
#include <stdbool.h>


static struct {
  float data[RPN_MAX_CHARS / 2];
  uint8_t sp;
} _stack;


// 0 == SUCCESS
bool stack_push(const float f) {
  if (_stack.sp < sizeof _stack.data / sizeof *_stack.data) {
    _stack.data[_stack.sp++] = f;
    return false;
  }
  return true;
}


// 0 == SUCCESS
bool stack_pop(float * const f) {
  if (_stack.sp > 0) {
    *f = _stack.data[--_stack.sp];
    return false;
  }
  return true;
}


void stack_clr() {
  _stack.sp = 0;
}