/*

  re2c -o rpn.c rpn.re.c && gcc -DRPN_MAX_CHARS=16 rpn.c test.c && \
  ./a.out && valgrind ./a.out && valgrind --tool=exp-sgcheck ./a.out

*/

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <float.h>
#include <math.h>
#include <assert.h>

extern bool rpn(const char *, float * const);

static void rpn_assert_r(const char * s, const float f1, const bool b1){
  float f2 = 0;
  bool b2;

  b2 = rpn(s, &f2);
  printf("'%s' | %s | %f\n", s, b2 ? "true" : "false", f2);
  assert(b2 == b1);
  assert(f2 == f1);
}

static void rpn_assert(const char * s, const float f) {
  rpn_assert_r(s, f, false);
}

int main() {

  printf("%f\n", FLT_MAX);

  // errors
  printf("\nerrors...\n");
  rpn_assert_r("", 0, true);
  rpn_assert_r("a", 0, true);
  rpn_assert_r("-", 0, true);
  rpn_assert_r("-.", 0, true);
  rpn_assert_r(".", 0, true);
  rpn_assert_r(".-", 0, true);
  rpn_assert_r("4.", 0, true);
  rpn_assert_r("2-", 0, true);
  rpn_assert_r("-2-", 0, true);
  rpn_assert_r("2 -", 0, true);
  rpn_assert_r("-2 -", 0, true);
  rpn_assert_r("2/", 0, true);
  rpn_assert_r("1 0/", 0, true);
  rpn_assert_r("1 0 /", 0, true);
  rpn_assert_r("1  2 +", 0, true);
  rpn_assert_r(" ", 0, true);
  rpn_assert_r("1 ", 0, true);
  rpn_assert_r(" -", 0, true);
  rpn_assert_r("- ", 0, true);
  rpn_assert_r("- 1", 0, true);

  // numbers
  printf("\nnumbers...\n");
  rpn_assert("340282346638528859811704183484516925440.0", FLT_MAX);
  rpn_assert("3402823466385288598117041834845169254401.0", INFINITY);
  rpn_assert(".0", 0);
  rpn_assert("-0", -0);
  rpn_assert(".1", 0.1f);
  rpn_assert("0.0123", 0.0123f);
  rpn_assert("42", 42);
  rpn_assert("-.2", -0.2f);
  rpn_assert("-0.5", -0.5f);
  rpn_assert("-42", -42);

  // rpn
  printf("\nrpn...\n");
  rpn_assert("1 2", 2);
  rpn_assert("1 2.2+", 3.2f);
  rpn_assert("1.1 -2+", -0.9f);
  rpn_assert("-1 -2+", -3);
  rpn_assert("0 2/", 0);
  rpn_assert("-0 2/", -0);
  rpn_assert("4.5 2.25/", 2);
  rpn_assert("4.5 -2.25/", -2);
  rpn_assert("-4.5 2.25/", -2);
  rpn_assert("-4.5 -2.25/", 2);
  rpn_assert("4 2*", 8);
  rpn_assert("7 2-", 5);
  rpn_assert("-7 2-", -9);
  rpn_assert("-7 -2-", -5);

  rpn_assert("1 2.2 +", 3.2f);
  rpn_assert("1.1 -2 +", -0.9f);
  rpn_assert("-1 -2 +", -3);
  rpn_assert("0 2 /", 0);
  rpn_assert("-0 2 /", -0);
  rpn_assert("4.5 2.25 /", 2);
  rpn_assert("4.5 -2.25 /", -2);
  rpn_assert("-4.5 2.25 /", -2);
  rpn_assert("-4.5 -2.25 /", 2);
  rpn_assert("4 2 *", 8);
  rpn_assert("7 2 -", 5);
  rpn_assert("-7 2 -", -9);
  rpn_assert("-7 -2 -", -5);

  rpn_assert("-7 -2 6 -*", 56);
  rpn_assert("7 2 6 -*", -28);

  rpn_assert("1 2 3 4 + * +", 15);
  rpn_assert("1 2 + 3 4 + *", 21);

  rpn_assert("1 2 + 3 4 + * 3.14+", 21+3.14);
  rpn_assert("1 2 + 3 4 + * 3.14/", 21/3.14);
  rpn_assert("2 3 4 5 6 * + - /", -0.06451612903225806f);
  rpn_assert("2 3 * 4 5 * +", (2 * 3) + (4 * 5));

  printf("\nOK\n");

  return 0;
}