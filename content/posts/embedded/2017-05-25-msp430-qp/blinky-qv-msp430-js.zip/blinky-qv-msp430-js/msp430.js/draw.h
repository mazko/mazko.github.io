#include <stdint.h>

namespace draw {
    void character(const uint8_t x, const uint8_t page, const char c);
    void str(uint8_t x, uint8_t page, const char* s);
    void str_hex(const uint8_t, const char* s, const uint16_t);

    void clr(void);
    void init(void);
}
