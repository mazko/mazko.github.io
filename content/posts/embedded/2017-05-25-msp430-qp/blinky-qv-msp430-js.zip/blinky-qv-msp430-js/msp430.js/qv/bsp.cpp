//****************************************************************************
// Product: "Blinky" example on MSP-EXP430F5529LP board, cooperative QV kernel
// Last updated for version 5.5.0
// Last updated on  2015-09-23
//
//                    Q u a n t u m     L e a P s
//                    ---------------------------
//                    innovating embedded systems
//
// Copyright (C) Quantum Leaps, LLC. All rights reserved.
//
// This program is open source software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Alternatively, this program may be distributed and modified under the
// terms of Quantum Leaps commercial licenses, which expressly supersede
// the GNU General Public License and are specifically designed for
// licensees interested in retaining the proprietary status of their code.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.
//
// Contact information:
// http://www.state-machine.com
// mailto:info@state-machine.com
//****************************************************************************
#include "qpcpp.h"
#include "bsp.h"
#include "draw.h"

#include <msp430.h>  // MSP430 variant used
// add other drivers if necessary...

#ifdef Q_SPY
    #error Simple Blinky Application does not provide Spy build configuration
#endif

//Q_DEFINE_THIS_FILE

// Local-scope objects -------------------------------------------------------
// 1MHz clock setting, see BSP_init()
//#define BSP_MCK     1000000U
//#define BSP_SMCLK   1000000U
#define BSP_MCK      32768U

// ISRs used in this project =================================================
extern "C" {

    //............................................................................
    #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
        __interrupt void TIMER0_A0_ISR (void); // prototype
        #pragma vector=TIMER0_A0_VECTOR
        __interrupt void TIMER0_A0_ISR(void)
    #elif defined(__GNUC__)
        __attribute__ ((interrupt(TIMER0_A0_VECTOR)))
        void TIMER0_A0_ISR (void)
    #else
        #error Compiler not supported!
    #endif
    {
    #ifdef NDEBUG
        __low_power_mode_off_on_exit(); // see NOTE1
    #endif

        TACTL &= ~TAIFG;   // clear the interrupt pending flag
        QP::QF::TICK_X(0U, (void *)0); // process time events for rate 0
    }

} // extern "C"

namespace BSP {
    // BSP functions =============================================================
    void init(void) {
        WDTCTL = WDTPW | WDTHOLD; // stop watchdog timer

        // DCO = 3, RSEL = 0, f = 0.13 MHz
        DCOCTL = /* DCO2 + */ DCO1 + DCO0;
        BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

        // Shared between L/R tasks 8*RGB LEDS
        P4OUT = 0; P5OUT = 0; P6OUT = 0;
        P4DIR = P5DIR = P6DIR = 0xFF;

        // 2 RGB LEDS (pins 2..7) + LCD (pins 0,1)
        P3OUT = 0; P3DIR = 0xFF;
        // LCD data
        P2OUT = 0; P2DIR = 0xFF;

        draw::init();

        // test assert
    //    Q_DEFINE_THIS_MODULE("bsp")
    //    Q_ASSERT(0);
    }

    namespace L {
        void set_red() {
            clr();
            P4OUT |= 0b11111;
        }

        void set_green() {
            clr();
            P5OUT |= 0b11111;
        }

        void set_blue() {
            clr();
            P6OUT |= 0b11111;
        }

        void clr() {
            P4OUT &= ~0b11111; P5OUT &= ~0b11111; P6OUT &= ~0b11111;
        }
    }

    namespace R {
        void or_red() {
            P3OUT |= 0b100100;
            P4OUT |= ~0b11111;
        }

        void or_green() {
            P3OUT |= 0b100100 << 1;
            P5OUT |= ~0b11111;
        }

        void or_blue() {
            P3OUT |= 0b100100 << 2;
            P6OUT |= ~0b11111;
        }

        void clr() {
            P3OUT &= 0b11;
            P6OUT &= 0b11111; P5OUT &= 0b11111; P4OUT &= 0b11111;
        }
    }

}

// QF callbacks ==============================================================
void QP::QF::onStartup(void) {
//    TA0CCTL0 = CCIE;                          // CCR0 interrupt enabled
//    TA0CCR0 = BSP_MCK / BSP_TICKS_PER_SEC;
//    TA0CTL = TASSEL_2 + MC_1 + TACLR;         // SMCLK, upmode, clear TAR

     /* Ensure the timer is stopped. */
     TACTL = 0;

     /* Run the timer of the ACLK. */
     TACTL = TASSEL_1;

     /* Clear everything to start with. */
     TACTL |= TACLR;

     /* Set the compare match value according to the tick rate we want. */
     TACCR0 = BSP_MCK / BSP::TICKS_PER_SEC;

     /* Enable the interrupts. */
     TACCTL0 = CCIE;

     /* Start up clean. */
     TACTL |= TACLR;

     /* Up mode. */
     TACTL |= MC_1;
}
//............................................................................
void QP::QF::onCleanup(void) {
}
//............................................................................
void QP::QV::onIdle(void) { // NOTE: called with interrutps DISABLED, see NOTE1
    // toggle LED2 on and then off, see NOTE2
    //P4OUT |=  LED2;        // turn LED2 on
    //P4OUT &= ~LED2;        // turn LED2 off
    BSP::R::or_red();
    BSP::R::clr();

#ifdef NDEBUG
    // Put the CPU and peripherals to the low-power mode.
    // you might need to customize the clock management for your application,
    // see the datasheet for your particular MSP430 MCU.
    //
    __low_power_mode_1(); // Enter LPM1; also ENABLES interrupts
#else
    QF_INT_ENABLE(); // just enable interrupts
#endif
}

//............................................................................
extern "C" void Q_onAssert(char const *module, int loc) {
    // implement the error-handling policy for your application!!!
    QF_INT_DISABLE(); // disable all interrupts

    draw::clr();
    draw::str_hex(0, module, loc);

    for(;;);

    // TODO: what is it for ?
    //    QS_ASSERTION(module, loc, static_cast<uint32_t>(10000U));
    //
    //    // cause the reset of the CPU...
    //    WDTCTL = WDTPW | WDTHOLD;
    //    __asm("    push &0xFFFE");
    // return from function does the reset
}

//****************************************************************************
// NOTE1:
// With the cooperative QV kernel for MSP430, it is necessary to explicitly
// turn the low-power mode OFF in the interrupt, because the return
// from the interrupt will restore the CPU status register, which will
// re-enter the low-power mode. This, in turn, will prevent the QV event-loop
// from running.
//
// NOTE2:
// NOTE1:
// One of the LEDs is used to visualize the idle loop activity. The brightness
// of the LED is proportional to the frequency of invcations of the idle loop.
// Please note that the LED is toggled with interrupts locked, so no interrupt
// execution time contributes to the brightness of the User LED.
//
