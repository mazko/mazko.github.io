#include "draw.h"
#include "ssd1306.h"
#include "qpcpp.h"  // Q_ASSERT_COMPILE
#include <stddef.h> // size_t

namespace draw {

    void character(const uint8_t x, const uint8_t page, const char c) {
        #include "font.cpp"
        Q_ASSERT_COMPILE(sizeof(font) == 256 * 5 /* uint8_t values 0..255 == 256 */);
        for (uint8_t i = 0; i < 5; i++ ) {
          ssd1306::write_byte(x + i, page, *(font+(c*5)+i));
        }
    }


    void str(uint8_t x, uint8_t page, const char* s) {
        while (s && *s) {
            character(x, page, *s++);
            x += 6;     // 6 pixels wide
            if (x + 6 >= SSD1306_X_PIXELS) {
              x = 0;    // ran out of this page
              page++;
            }
            if (page >= SSD1306_PIXEL_PAGES)
              break;    // ran out of space :(
         }
    }


    // http://stackoverflow.com/a/33447587

    template <typename I, size_t hex_len = (sizeof(I)<<1)> const char* n2hexstr(I w) {
        static char rc[1 + hex_len]; // non-reentrant
        for (size_t i=0, j=(hex_len-1)*4 ; i<hex_len; ++i,j-=4)
            rc[i] = "0123456789ABCDEF"[(w>>j) & 0x0f];
        rc[ hex_len ] = '\0';
        return rc;
    }


    void str_hex(const uint8_t p, const char* const m, const uint16_t v) {
      str(1, p,  m);
      str(1 + (6 * 15), p,  "0x");
      str(1 + (6 * 17), p,  n2hexstr(v));
    }

    void clr() {
        ssd1306::clear_screen();
    }


    void init() {
        ssd1306::init_display();
    }

}
