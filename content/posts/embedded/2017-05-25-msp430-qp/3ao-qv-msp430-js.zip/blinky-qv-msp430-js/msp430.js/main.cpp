//****************************************************************************
// Product: Simple Blinky example
// Last Updated for Version: 5.4.0
// Date of the Last Update:  2015-05-04
//
//                    Q u a n t u m     L e a P s
//                    ---------------------------
//                    innovating embedded systems
//
// Copyright (C) 2002-2013 Quantum Leaps, LLC. All rights reserved.
//
// This program is open source software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Alternatively, this program may be distributed and modified under the
// terms of Quantum Leaps commercial licenses, which expressly supersede
// the GNU General Public License and are specifically designed for
// licensees interested in retaining the proprietary status of their code.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.
//
// Contact information:
// Web  : http://www.state-machine.com
// Email: info@state-machine.com
//****************************************************************************
#include "qpcpp.h"
#include "bsp.h"
#include "events.h"
#include "left.h"
#include "right.h"
#include "display.h"

int main() {
    static QP::QEvt const *leftQSto[10];    // Event queue storage for LeftBlinky
    static QP::QEvt const *rightQSto[10];   // Event queue storage for RightBlinky
    static QP::QEvt const *displayQSto[10]; // Event queue storage for Display
    static QP::QSubscrList subscrSto[blinky::MAX_PUB_SIG];
    static QF_MPOOL_EL(blinky::BtnEvt) smlPoolSto[2];

    BSP::init(); // initialize the Board Support Package
    QP::QF::init(); // initialize the framework and the underlying RT kernel

    QP::QF::psInit(subscrSto, Q_DIM(subscrSto)); // init publish-subscribe
    // initialize event pools...
    QP::QF::poolInit(smlPoolSto, sizeof(smlPoolSto), sizeof(smlPoolSto[0]));

    // instantiate and start the active objects...

    blinky::AO_DisplayPtr->start(1U,                  // lowest priority
                     displayQSto, Q_DIM(displayQSto), // event queue
                     (void *)0, 0U);                  // stack (unused)

    blinky::AO_LeftPtr->start(2U,                     // priority
                     leftQSto, Q_DIM(leftQSto),       // event queue
                     (void *)0, 0U);                  // stack (unused)

    blinky::AO_RightPtr->start(3U,                    // priority
                     rightQSto, Q_DIM(rightQSto),     // event queue
                     (void *)0, 0U);                  // stack (unused)

    return QP::QF::run(); // run the QF application
}
