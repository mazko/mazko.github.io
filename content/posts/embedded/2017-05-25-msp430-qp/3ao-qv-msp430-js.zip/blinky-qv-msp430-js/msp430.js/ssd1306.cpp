#include "ssd1306.h"

namespace ssd1306 {

    #include <msp430.h>

    enum
    {
        SSD1306_DATA_INST = 0, SSD1306_DATA_E = 1
    };

    static void strobe(void)
    {
        P3OUT |= (1 << SSD1306_DATA_E);
        P3OUT &= ~(1 << SSD1306_DATA_E);
    }

    void write_data(const uint8_t byte)
    {
        P2OUT = byte;
        P3OUT |= (1 << SSD1306_DATA_INST);
        strobe();
    }

    void write_instruction(const uint8_t byte)
    {
        P2OUT = byte;
        P3OUT &= ~(1 << SSD1306_DATA_INST);
        strobe();
    }

    /* Initialise display mostly as per p64 of the datasheet */
    void init_display(void)
    {
        set_power_state(POWER_STATE_SLEEP);

        write_instruction(SSD1306_SET_MULTIPLEX_RATIO);
        write_instruction(0x3F);

        write_instruction(SSD1306_SET_VERTICAL_OFFSET);
        write_instruction(0x00);

        write_instruction(SSD1306_SET_DISP_START_LINE);

        set_display_orientation(DISP_ORIENT_NORMAL);

        write_instruction(SSD1306_SET_WIRING_SCHEME);
        write_instruction(0x12);

        set_contrast(SSD1306_DEFAULT_CONTRAST);

        write_instruction(SSD1306_RESUME_TO_RAM_CONTENT);

        set_display_mode(DISPLAY_MODE_NORMAL);

        // Horizontal memory addressing mode
        write_instruction(SSD1306_MEM_ADDRESSING);
        write_instruction(0x00);

        write_instruction(SSD1306_SET_DISP_CLOCK);
        write_instruction(0x80);

        write_instruction(SSD1306_CHARGE_PUMP_REGULATOR);
        write_instruction(SSD1306_CHARGE_PUMP_ON);

        set_power_state(POWER_STATE_ON);
    }

    void set_display_orientation(const disp_orient_t disp_orient)
    {
        switch (disp_orient)
        {
        case DISP_ORIENT_NORMAL:
            write_instruction(SSD1306_SET_SEG_REMAP_0);
            write_instruction(SSD1306_SET_COM_SCAN_NORMAL);
            break;
        case DISP_ORIENT_NORMAL_MIRRORED:
            // The display is mirrored from the upper edge
            write_instruction(SSD1306_SET_SEG_REMAP_0);
            write_instruction(SSD1306_SET_COM_SCAN_INVERTED);
            break;
        case DISP_ORIENT_UPSIDE_DOWN:
            write_instruction(SSD1306_SET_SEG_REMAP_127);
            write_instruction(SSD1306_SET_COM_SCAN_INVERTED);
            break;
        case DISP_ORIENT_UPSIDE_DOWN_MIRRORED:
            // The upside down display is mirrored from the upper edge
            write_instruction(SSD1306_SET_SEG_REMAP_127);
            write_instruction(SSD1306_SET_COM_SCAN_NORMAL);
            break;
        default:
            break;
        }
    }

    /* Move the cursor to the start */
    void reset_cursor(void)
    {
        write_instruction(SSD1306_SET_PAGE_START_ADDR);
        write_instruction(SSD1306_SET_COL_HI_NIBBLE);
        write_instruction(SSD1306_SET_COL_LO_NIBBLE);
    }

    void set_contrast(const uint8_t contrast)
    {
        write_instruction(SSD1306_SET_CONTRAST);
        write_instruction(contrast);
    }

    void set_display_mode(const display_mode_t display_mode)
    {
        switch (display_mode)
        {
        case DISPLAY_MODE_NORMAL:
            write_instruction(SSD1306_DISP_NORMAL);
            break;
        case DISPLAY_MODE_INVERTED:
            write_instruction(SSD1306_DISP_INVERTED);
            break;
        default:
            write_instruction(SSD1306_DISP_NORMAL);
            break;
        }
    }

    void set_power_state(const power_state_t power_state)
    {
        switch (power_state)
        {
        case POWER_STATE_ON:
            write_instruction(SSD1306_DISP_ON);
            break;
        case POWER_STATE_SLEEP:
            write_instruction(SSD1306_DISP_SLEEP);
            break;
        default:
            break;
        }
    }

    void write_byte(const uint8_t x, const uint8_t page, const uint8_t byte)
    {
        write_instruction(SSD1306_SET_PAGE_START_ADDR | page);
        write_instruction(SSD1306_SET_COL_LO_NIBBLE | (x & 0xF));
        write_instruction(SSD1306_SET_COL_HI_NIBBLE | (x >> 4));
        write_data(byte);
    }

    void clear_screen(void)
    {
        reset_cursor();

        for (uint16_t byte = 0; byte < SSD1306_PIXEL_BYTES; byte++)
        {
            write_data(0x00);
        }
    }

}
