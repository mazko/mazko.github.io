#include <msp430.h>
#include "hal.h"

namespace hal {

    void LeftLeds::set_red() {
        P4OUT |= 0b11111;
    }

    void LeftLeds::set_green() {
        P5OUT |= 0b11111;
    }

    void LeftLeds::set_blue() {
        P6OUT |= 0b11111;
    }

    void LeftLeds::clr() {
        P4OUT &= ~0b11111; P5OUT &= ~0b11111; P6OUT &= ~0b11111;
    }

    void RightLeds::set_red() {
        P3OUT |= 0b100100;
        P4OUT |= ~0b11111;
    }

    void RightLeds::set_green() {
        P3OUT |= 0b100100 << 1;
        P5OUT |= ~0b11111;
    }

    void RightLeds::set_blue() {
        P3OUT |= 0b100100 << 2;
        P6OUT |= ~0b11111;
    }

    void RightLeds::clr() {
        P3OUT &= 0b11;
        P6OUT &= 0b11111; P5OUT &= 0b11111; P4OUT &= 0b11111;
    }

    char get_buttons() {
        return P1IN;
    }


    void init() {
        WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

        // DCO = 3, RSEL = 0, f = 0.13 MHz
        DCOCTL = /* DCO2 + */ DCO1 + DCO0;
        BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

        // Shared between L/R tasks 8*RGB LEDS
        P4OUT = 0; P5OUT = 0; P6OUT = 0;
        P4DIR = P5DIR = P6DIR = 0xFF;

        // 2 RGB LEDS (pins 2..7) + LCD (pins 0,1)
        P3OUT = 0; P3DIR = 0xFF;
        // LCD data
        P2OUT = 0; P2DIR = 0xFF;
    }
}