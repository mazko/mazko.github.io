#include "app.h"
#include "hal.h"
#include "observers/buttons.h"
#include "observers/state.h"
#include "tasks/left.h"
#include "tasks/right.h"
#include "tasks/counter.h"

using namespace obsevers;

buttons::Container obsevers::buttons::event;
state::Container   obsevers::state::event;

namespace app {

    int run() {

        tasks::left::start();
        tasks::right::start();
        tasks::counter::start();

        char lastBtns = 0;
        volatile uint16_t longPress = 0; // TODO: use timer
        state::state_t lastState = state::left_sleep;

        for (;;) {

            char btns = hal::get_buttons();

            if (!lastBtns && btns) {
                buttons::event.notifyObservers(btns);
            }

            if (btns & 1 /* left first button */) {
                if (longPress && !--longPress) 
                {
                    switch (lastState) {
                        case state::left_active:
                            lastState = state::left_sleep;
                            break;
                        case state::left_sleep:
                            lastState = state::left_active;
                            break;
                    }
                    state::event.notifyObservers(lastState);
                }
            } else {
                longPress = 5000;
            }

            lastBtns = btns;

            // other events like timer e.t.c...
        }

        return 0;
    }
}

