#include "hal.h"
#include "app.h"
#include "draw.h"

int main(void) {

    hal::init();
    draw::init();

    return app::run();
}

void assert_called(char const *module, int loc) {

    draw::clr();
    draw::str(1, 0, module);
    draw::str_hex(7, "line:", loc);

    for(;;);
}