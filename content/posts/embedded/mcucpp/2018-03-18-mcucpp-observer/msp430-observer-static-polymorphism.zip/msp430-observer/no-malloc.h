#define __wrap_malloc(...)  bare_malloc_erroneously_called
#define __wrap_calloc(...)  bare_calloc_erroneously_called
#define __wrap_realloc(...) bare_realloc_erroneously_called
#define __wrap_free(...)    bare_free_erroneously_called
#define __wrap_sbrk(...)    bare_sbrk_erroneously_called