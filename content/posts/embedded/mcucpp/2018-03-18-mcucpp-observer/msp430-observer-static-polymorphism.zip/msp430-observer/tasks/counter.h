namespace tasks {

    namespace counter {

        void start();

    }

}