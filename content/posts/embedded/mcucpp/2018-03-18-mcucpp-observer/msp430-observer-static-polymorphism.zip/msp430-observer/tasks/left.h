namespace tasks {

    namespace left {

        void start();

    }

}