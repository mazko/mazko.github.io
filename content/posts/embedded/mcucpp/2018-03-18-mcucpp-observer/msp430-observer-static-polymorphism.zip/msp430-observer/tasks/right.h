namespace tasks {

    namespace right {

        void start();

    }

}