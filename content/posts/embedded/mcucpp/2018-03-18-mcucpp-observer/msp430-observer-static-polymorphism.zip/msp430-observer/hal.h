#include "non-copyable.h"

namespace hal {

  struct LeftLeds : NonCopyable {
      void set_red();

      void set_green();

      void set_blue();

      void clr();
  };

  struct RightLeds : NonCopyable {
      void set_red();

      void set_green();

      void set_blue();

      void clr();
  };

  char get_buttons();

  void init();

}