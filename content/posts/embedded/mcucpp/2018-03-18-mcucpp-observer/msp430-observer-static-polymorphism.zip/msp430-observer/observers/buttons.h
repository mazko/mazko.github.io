#include "DoublyLinkedList.h"
#include "non-copyable.h"

namespace obsevers {

    // alias
    template<class T> using DLLE = mozilla::DoublyLinkedListElement<T>;

    namespace buttons {

        struct Observer : public DLLE<Observer>, NonCopyable
        {
            typedef void (*ObserveFunc) (char, Observer*);

            ObserveFunc m_observe_func_ptr;

        public:

            void observe(char aButton) {
                (*m_observe_func_ptr)(aButton, this);
            }

            Observer(ObserveFunc f): m_observe_func_ptr(f){}
        };


        template<class T>
        class Adapter : public Observer
        {
            T m_observer_impl;

        public:
            Adapter(): Observer(
                [](char aButton, Observer* aThis)
                {
                    auto self = static_cast<Adapter*>(aThis);
                    self->m_observer_impl.observe(aButton);
                }){/* empty constructor */}
        };
    }
}

namespace obsevers {

    namespace buttons {

        class Container : NonCopyable
        {
            mozilla::DoublyLinkedList<Observer> mList;

        public:
            void addObserver(Observer* aObserver)
            {
                // Will assert if |aObserver| is part of another list.
                mList.pushFront(aObserver);
            }

            void removeObserver(Observer* aObserver)
            {
                // Will assert if |aObserver| is not part of |list|.
                mList.remove(aObserver);
            }

            void notifyObservers(char aButton)
            {
                for (Observer& o : mList) {
                    o.observe(aButton);
                }
            }
        };

        extern Container event;

    }
  
}