/*
reset && (export GCC_DIR=~/ti/msp430_gcc ; 
    $GCC_DIR/bin/msp430-elf-c++ \
    -I $GCC_DIR/include -L $GCC_DIR/include \
    -Werror -Wall -mmcu=msp430f1611 -O2 *.cpp)
*/


#include <msp430.h>
#include "app.h"


int main(void) {
    WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

    // DCO = 3, RSEL = 0, f = 0.13 MHz
    DCOCTL = /* DCO2 + */ DCO1 + DCO0; 
    BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

    constexpr auto O = 0;

    P1OUT = O; P2OUT = O; P3OUT = O; P4OUT = O; P5OUT = O; P6OUT = O;
    P1DIR = P2DIR = P3DIR = P4DIR = P5DIR = P6DIR = 0xFF;

    return app::run();
}
