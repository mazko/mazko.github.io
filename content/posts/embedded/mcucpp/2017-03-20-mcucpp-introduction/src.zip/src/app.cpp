#include <initializer_list>
#include "rgb.h"


namespace app {
    int run() {
        rgb::RgbStripLayer rgb_strip;
        constexpr auto colors = {
            rgb_strip.RED, rgb_strip.GREEN,
            rgb_strip.BLUE, rgb_strip.YELLOW, 
            rgb_strip.VIOLET, rgb_strip.CYAN,
            rgb_strip.WHITE, rgb_strip.BLACK
        };
        for (;;) {
            for (const auto& c : colors) {
                for (auto& m : rgb_strip.mem) {
                    m = c;
                    rgb_strip.flush();
                    __delay_cycles(10000);
                }
            }
        }
        return 0;
    }
}