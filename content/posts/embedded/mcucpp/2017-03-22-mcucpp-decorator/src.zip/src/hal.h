#include "pin.h"
#include <msp430.h>
#include <cstdint>


namespace pin {
    // MSP430 aliases
    using msp430_port_t = decltype(P1OUT);
    using msp430_pin_t = Pin<msp430_port_t, std::uint8_t>;
}