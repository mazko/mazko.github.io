#include "animation.h"


namespace app {

    using namespace animation;

    constexpr auto R = RgbStripLayer::RED, 
                   G = RgbStripLayer::GREEN, 
                   B = RgbStripLayer::BLUE,
                   Y = RgbStripLayer::YELLOW;
    constexpr auto SZ = RgbStripLayer::STRIP_SZ;


    int run() {
        for (;;) {
            RgbStripLayer l1, l2;

            EachColor< DynFill< 0, SZ - 1, Flush< Sleep< 55555, Flush<> >>>>().draw(l1);
            EachColor< FillCW< Sleep< 4444, Flush<> >>>().draw(l1);
            EachColor< FillCCW< Sleep< 4444, Flush<> >>>().draw(l1);
            Clear< EachColor< DynFill< 0, 3, Flush< RotateCW< SZ, Sleep< 4444, Flush<> >>>>>>().draw(l1);
            Clear< Fill< R, 0, 3, Fill< G, 4, 7, Fill< B, 8, 11, Fill< Y, 12, 15, Flush< RotateCCW< 5*SZ, Sleep< 4444, Flush<> >>>>>>>>().draw(l1);

            Clear< Fill< R, 0, 3, Nop >>().draw(l1);
            Clear< Fill< G, 0, 3, Nop >>().draw(l2);
            for (auto i = 5*SZ; i--;) {
                RgbStripLayer m;
                RotateCW< 1, Sleep< 4444, Nop >>().draw(l1);
                RotateCCW< 1, Nop >().draw(l2);
                m += l1; m += l2; Flush<>().draw(m);
            }
        }

        return 0;
    }

}