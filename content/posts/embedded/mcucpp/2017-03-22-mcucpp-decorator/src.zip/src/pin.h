#include "non-copyable.h"


namespace pin {
    template<typename port_t, typename pos_t>
    class Pin : NonCopyable {
        port_t& m_port;
        const port_t m_mask;
    public:

        Pin(port_t& port, const pos_t pos): m_port(port), m_mask(1 << pos) {}

        void set(const bool v = true) {
            if (v) {
                m_port |= m_mask;
            } else {
                clr();
            }
        }

        void clr() {
            m_port &= ~m_mask;
        }
    };
}