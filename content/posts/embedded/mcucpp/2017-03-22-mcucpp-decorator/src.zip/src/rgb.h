#include "hal.h"
#include <array>


namespace rgb {

    using namespace pin;

    class RgbStripLayer : NonCopyable {

        template<msp430_port_t& p1, msp430_port_t& p2> struct MonoStrip;
        static MonoStrip<P1OUT, P2OUT> red;
        static MonoStrip<P3OUT, P4OUT> green;
        static MonoStrip<P5OUT, P6OUT> blue;

    public:

        RgbStripLayer(): mem() {}

        static constexpr std::size_t STRIP_SZ = 2*8;

        struct RGB {
            bool r, g, b;
        };

        std::array<RGB, STRIP_SZ> mem;

        static constexpr RGB RED = { 1, 0, 0 }, GREEN  = { 0, 1, 0 }, 
                         BLUE    = { 0, 0, 1 }, YELLOW = { 1, 1, 0 }, 
                         CYAN    = { 0, 1, 1 }, VIOLET = { 1, 0, 1 }, 
                         WHITE   = { 1, 1, 1 }, BLACK  = { 0 };

        void flush();

        RgbStripLayer& operator += (const RgbStripLayer& layer);
    };
}