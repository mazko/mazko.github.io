#include "rgb.h"
#include <algorithm>


namespace animation {

    using namespace rgb;


    struct Nop : NonCopyable {
        void draw(RgbStripLayer& layer) {}
    };


    template<class A = Nop>
    class Flush : NonCopyable {
        A m_stream;
    public:
        void draw(RgbStripLayer& layer) {
            layer.flush();
            m_stream.draw(layer);
        }
    };


    template<const std::int32_t cycles, class A>
    class Sleep : NonCopyable {
        A m_stream;
    public:
        void draw(RgbStripLayer& layer) {
            static_assert(cycles > 0);
            __delay_cycles(cycles);
            m_stream.draw(layer);
        }
    };


    template<class A, const RgbStripLayer::RGB& c = RgbStripLayer::RED>
    class FillCW : NonCopyable /* clockwise */ {
        A m_stream;
        RgbStripLayer::RGB m_color = c;
    public:
        void draw(RgbStripLayer& layer) {
            for (auto& m : layer.mem) {
                m = m_color;
                m_stream.draw(layer);
            }
        }

        void set_color(const auto& co) {
            m_color = co;
        }
    };


    template<class A, const RgbStripLayer::RGB& c = RgbStripLayer::RED>
    class FillCCW : NonCopyable /* counterclockwise */ {
        A m_stream;
        RgbStripLayer::RGB m_color = c;
    public:
        void draw(RgbStripLayer& layer) {
            // while a pointer is a form of iterator, 
            // not all iterators have the same functionality of pointer
            for (auto it = layer.mem.rbegin(); it != layer.mem.crend(); it++) {
                *it = m_color;
                m_stream.draw(layer);
            }
        }

        void set_color(const auto& co) {
            m_color = co;
        }
    };


    template<class A>
    class EachColor : NonCopyable {
        A m_stream;
        static constexpr auto colors = {
            RgbStripLayer::RED,    RgbStripLayer::GREEN,
            RgbStripLayer::BLUE,   RgbStripLayer::YELLOW, 
            RgbStripLayer::VIOLET, RgbStripLayer::CYAN,
            RgbStripLayer::WHITE,  
        };
     
    public:
        void draw(RgbStripLayer& layer) {
            for (const auto& c : colors) {
                m_stream.set_color(c);
                m_stream.draw(layer);
            }
        }
    };


    template<const RgbStripLayer::RGB& c,
             const std::int8_t f, const std::int8_t l, class A>
    class Fill : NonCopyable {
        A m_stream;
    public:
        void draw(RgbStripLayer& layer) {
            static_assert(f >= 0);
            static_assert(l > f);
            static_assert(l < layer.mem.size());
            for (auto i = f; i <= l; i++) {
                layer.mem[i] = c;
            }
            m_stream.draw(layer);
        }
    };


    template<class T> using Clear = Fill< RgbStripLayer::BLACK, 0, RgbStripLayer::STRIP_SZ - 1, T>;


    template<const std::int8_t f, const std::int8_t l, class A>
    class DynFill : NonCopyable {
        A m_stream;
        RgbStripLayer::RGB m_color = RgbStripLayer::RED;
    public:
        void draw(RgbStripLayer& layer) {
            static_assert(f >= 0);
            static_assert(l > f);
            static_assert(l < layer.mem.size());
            for (auto i = f; i <= l; i++) {
                layer.mem[i] = m_color;
            }
            m_stream.draw(layer);
        }

        void set_color(const auto& co) {
            m_color = co;
        }
    };


    // http://en.cppreference.com/w/cpp/algorithm/rotate


    template<const std::int16_t n, class A>
    class RotateCW : NonCopyable /* clockwise */ {
        A m_stream;
    public:
        void draw(RgbStripLayer& layer) {
            static_assert(n > 0);
            for (auto i = 0; i < n; i++) {
                std::rotate(layer.mem.rbegin(),
                            layer.mem.rbegin() + 1,
                            layer.mem.rend());
                m_stream.draw(layer);
            }
        }
    };


    template<const std::int16_t n, class A>
    class RotateCCW : NonCopyable /* counterclockwise */ {
        A m_stream;
    public:
        void draw(RgbStripLayer& layer) {
            static_assert(n > 0);
            for (auto i = 0; i < n; i++) {
                std::rotate(layer.mem.begin(),
                            layer.mem.begin() + 1,
                            layer.mem.end());
                m_stream.draw(layer);
            }
        }
    };
}