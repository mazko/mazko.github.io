#include "rgb.h"


namespace rgb {

    template<msp430_port_t& p1, msp430_port_t& p2>
    struct RgbStripLayer::MonoStrip : NonCopyable {
        msp430_pin_t leds[STRIP_SZ] = {
            { p1, 0 }, { p1, 1 }, { p1, 2 }, { p1, 3 }, 
            { p1, 4 }, { p1, 5 }, { p1, 6 }, { p1, 7 },
            { p2, 0 }, { p2, 1 }, { p2, 2 }, { p2, 3 }, 
            { p2, 4 }, { p2, 5 }, { p2, 6 }, { p2, 7 },
        };
    };
    
    decltype(RgbStripLayer::red) RgbStripLayer::red;
    decltype(RgbStripLayer::green) RgbStripLayer::green;
    decltype(RgbStripLayer::blue) RgbStripLayer::blue;

    void RgbStripLayer::flush() {
        for (auto i = mem.size(); i--;) {
            red.leds[i].set(mem[i].r);
            green.leds[i].set(mem[i].g);
            blue.leds[i].set(mem[i].b);
        }
    }

    RgbStripLayer& RgbStripLayer::operator += (const RgbStripLayer& layer) {
        for (auto i = mem.size(); i--;) {
            mem[i].r |= layer.mem[i].r;
            mem[i].g |= layer.mem[i].g;
            mem[i].b |= layer.mem[i].b;
        }

        return *this;
    }
}