#!/bin/sh

set -e

curl --progress-bar -L https://git.ugfx.io/uGFX/uGFX/archive/v2.7.tar.gz | tar xz

# git diff --ignore-space-at-eol > msp430.js.patch && dos2unix msp430.js.patch

patch -p1 < msp430.js.patch