/*
 * Copyright (c) 2012, 2013, Joel Bodenmann aka Tectu <joel@unormal.org>
 * Copyright (c) 2012, 2013, Andrew Hannam aka inmarket
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of the <organization> nor the
 *      names of its contributors may be used to endorse or promote products
 *      derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "gfx.h"
#include <stdio.h>

static void show(delaytime_t ms) {
    gdispFlush();
    gfxSleepMilliseconds(ms);
    gdispClear(Black);
    gdispFlush();
}

int main(void) {
    // Initialize and clear the display
    gfxInit();

    const coord_t h = gdispGetHeight(), w = gdispGetWidth();

    // Рисование по пикселям
    for (coord_t x = 0; x < w; x += 3) {
        for (coord_t y = 0; y < h; y += 3) {
            gdispDrawPixel(x, y, White);
        }
    }
    show(4444);

    // кириллица
    const font_t f = gdispOpenFont("Archangelsk Regular 12");
    const char * const txt = "Все Буде Добре";
    gdispDrawString(w/2 - gdispGetStringWidth(txt, f)/2, h/4, txt, f, White);
    char str[10];
    sprintf (str, "%dx%d", w, h);
    gdispDrawString(w/2 - gdispGetStringWidth(str, f)/2, h/2, str, f, White);
    show(4444);

    while(TRUE) {
        // линии
        gdispDrawLine(3, 3, w - 3, h - 3, White);
        gdispDrawLine(w - 3, 3, 3, h - 3, White);
        gdispDrawLine(w/2, 3, w/2, h - 3, White);
        gdispDrawLine(3, h/2, w - 3, h/2, White);
        show(4444);

        // Прямоугольники
        gdispDrawBox(3, 3, 2*w/5, 2*h/5, White);
        gdispFillArea(w-2*w/5-3, h-2*h/5-3, 2*w/5, 2*h/5, White);
        gdispDrawRoundedBox(3, h-2*h/5-3, 2*w/5, 2*h/5, 10, White);
        gdispFillRoundedBox(w-2*w/5-3, 3, 2*w/5, 2*h/5, 10, White);
        show(4444);

        // Окружность, круг, эллипсы
        gdispDrawCircle(h/4, h/4, h/5, White);
        gdispDrawEllipse(w/2, h/4, w/5, h/5, White);
        gdispFillCircle(w-1-h/4, h-1-h/4, h/5, White);
        gdispFillEllipse(w-1-w/2, h-1-h/4, w/5, h/5, White);
        show(4444);

        // Дуга и сектор
        gdispFillArc(w/2, h/2, 2*h/5, 0, 90, White);
        gdispDrawArc(w/2, h/2, 2*h/5, 90, 180, White);
        gdispFillArc(w/2, h/2, 2*h/5, 180, 270, White);
        gdispDrawArc(w/2, h/2, 2*h/5, 270, 0, White);
        show(4444);

        // многоугольник (полигон)
        static const point shape[] = {
            {-GDISP_SCREEN_WIDTH/4, GDISP_SCREEN_HEIGHT/4},
            {0, 0},
            {GDISP_SCREEN_WIDTH/3, GDISP_SCREEN_HEIGHT/3},
        };
        gdispDrawPoly(w/3, 3, shape, sizeof(shape)/sizeof(shape[0]), White);
        gdispFillConvexPoly(2*w/3, h/2, shape, sizeof(shape)/sizeof(shape[0]), White);
        show(4444);
    }   
}

