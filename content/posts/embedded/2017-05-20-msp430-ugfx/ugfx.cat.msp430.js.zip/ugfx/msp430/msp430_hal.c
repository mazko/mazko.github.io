#include <msp430.h>
#include "gfx.h"


#define BSP_MCK         32768U
#define TICKS_PER_SEC   10U


static systemticks_t _ticks_ms;


// !!!!   msp430-gcc 6.2.1.16   !!!!
// msp430_gcc/examples/watchdog.txt

static void __attribute__((naked, section(".crt_0042"), used))
disable_watchdog (void)
{
  WDTCTL = WDTPW | WDTHOLD; // Stop watchdog timer
}


// ISRs used in this project =================================================

void __attribute__ ((interrupt(TIMER0_A0_VECTOR))) TIMER0_A0_ISR (void) {
  _ticks_ms += 100;
}


void msp430_bsp_init(void) {

  // DCO = 3, RSEL = 1, f = 0.18 MHz
  DCOCTL = /* DCO2 + */ DCO1 + DCO0; 
  BCSCTL1 = XT2OFF + RSEL0 /* + RSEL1 + RSEL2 */;

  // timer + isr

  /* Ensure the timer is stopped. */
  TACTL = 0;

  /* Run the timer of the ACLK. */
  TACTL = TASSEL_1;

  /* Clear everything to start with. */
  TACTL |= TACLR;

  /* Set the compare match value according to the tick rate we want. */
  TACCR0 = BSP_MCK / TICKS_PER_SEC;

  /* Enable the interrupts. */
  TACCTL0 = CCIE;

  /* Start up clean. */
  TACTL |= TACLR;

  /* Up mode. */
  TACTL |= MC_1;

  __enable_interrupt();
}

systemticks_t gfxSystemTicks(void)
{
  const unsigned short stat_ = __get_interrupt_state();
  __disable_interrupt();

  const systemticks_t copy = _ticks_ms;

  __set_interrupt_state(stat_);

  return copy;
}
 
systemticks_t gfxMillisecondsToTicks(delaytime_t ms)
{
  return ms;
}