#!/usr/bin/env python                                                      

# chmod +x iptv-cli.py && sudo ln -s "`pwd`/iptv-cli.py" /usr/local/bin/iptv-cli

import curses
import sys
import os
from threading import Lock

import m3u
from validator import Validator


# https://gist.github.com/bellbind/3058567
# http://stackoverflow.com/questions/14200721/how-to-create-a-menu-and-submenus-in-python-curses

class Menu(object):
    def __init__(self, items, screen):
        self.__screen = screen
        self.__rows = len(items)
        self.__cols = max(len(l['title']) for l in items)
        self.__top = 0
        self.__left = 0

        # logcal window for line texts
        self.__pad = curses.newpad(self.__rows + 1, self.__cols)
        self.__pad.keypad(1)  # accept arrow keys
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)

        self.__position = 0
        self.__items = items
        self.__good_items = set()
        self.__bad_items = set()
        self.__render_lock = Lock()

    def navigate(self, n):
        self.__position += n
        if self.__position < 0:
            self.__position = 0
        elif self.__position >= len(self.__items):
            self.__position = len(self.__items) - 1

    def render(self, data=False):
        if data:
            with self.__render_lock:
                self.__pad.clear()
                for index, item in enumerate(self.__items):
                    mode = curses.A_REVERSE if index == self.__position else curses.A_LOW
                    if index in self.__bad_items:
                        mode |= curses.color_pair(2)
                    elif index in self.__good_items:
                        mode |= curses.color_pair(1)
                    self.__pad.addstr(index, 0, item['title'], mode)
        size = self.__screen.getmaxyx()  # current screen size
        self.__pad.refresh(self.__top, self.__left, 0, 0, size[0] - 1, size[1] - 2)

    def show(self):
        self.render(True)

        validator = Validator(on_ok=lambda u, i: self.__good_items.add(i),
                              on_fail=lambda u, i, e: self.__bad_items.add(i),
                              on_finish=lambda: self.render(True))
        validator.scan([item['model'] for item in self.__items], threads=16)

        while True:

            key = self.__pad.getch()

            if key in [curses.KEY_ENTER, ord('\n')]:
                menu_item = self.__items[self.__position]
                if int(menu_item['play-func'](menu_item['model'])) == 0:
                    self.__good_items.add(self.__position)
                else:
                    self.__bad_items.add(self.__position)
                self.render(True)

            elif key in [27, ord('q'), ord('Q')]:
                break

            elif key == ord(' '):
                self.__items[self.__position]['stop-func']()

            elif key == ord('c'):
                menu_item = self.__items[self.__position]
                menu_item['copy-func'](menu_item['model'], menu_item['title'].split(None, 1)[1])

            elif key == ord('p'):
                self.__items[self.__position]['pause-func']()

            elif key == ord('f'):
                self.__items[self.__position]['seek-forward-func']()

            elif key == ord('b'):
                self.__items[self.__position]['seek-backward-func']()

            elif key == curses.KEY_UP:
                self.navigate(-1)
                self.__top = max(self.__top - 1, 0)
                self.render(True)

            elif key == curses.KEY_DOWN:
                self.navigate(1)
                size = self.__screen.getmaxyx()
                self.__top = min(self.__top + 1, self.__rows - size[0])
                self.render(True)

            elif key == curses.KEY_LEFT:
                self.__left = max(self.__left - 1, 0)
                self.render()

            elif key == curses.KEY_RIGHT:
                size = self.__screen.getmaxyx()
                self.__left = min(self.__left + 1, self.__cols - size[1] + 1)
                self.render()


class MyApp(object):
    def __init__(self, screen):
        pwd = os.path.dirname(os.path.realpath(__file__)) + os.path.sep
        m3u_items = m3u.parse(sys.argv[1] if len(sys.argv) > 1 else pwd + 'iptv.m3u')
        menu_items = map(lambda (i, x): {
            'title': '%3d. %s' % (i + 1, '? Unknown ?' if x.title is None else x.title.strip()),
            'model': x.path,
            'play-func': lambda uri: os.system(pwd + 'player.sh ' + uri + ' > /dev/null 2>&1'),
            'stop-func': lambda: os.system(pwd + 'player.sh > /dev/null 2>&1'),
            'copy-func': lambda uri, title: os.system(pwd + "player.sh -c '%s' '%s' > /dev/null 2>&1"
                                                      % (title, uri,)),
            'pause-func': lambda: os.system(pwd + 'player.sh -p > /dev/null 2>&1'),
            'seek-forward-func': lambda: os.system(pwd + 'player.sh -f > /dev/null 2>&1'),
            'seek-backward-func': lambda: os.system(pwd + 'player.sh -b > /dev/null 2>&1'),
        }, enumerate(m3u_items))
        try:
            curses.curs_set(0)  # hide cursor
            menu = Menu(tuple(menu_items), screen)
            menu.show()
        finally:
            curses.curs_set(1)


if __name__ == '__main__':
    import locale

    locale.setlocale(locale.LC_ALL, '')
    try:
        os.environ['ESCDELAY']
    except KeyError:
        os.environ['ESCDELAY'] = '25'
    curses.wrapper(MyApp)
