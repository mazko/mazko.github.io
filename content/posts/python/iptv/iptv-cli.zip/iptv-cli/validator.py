#!/usr/bin/env python  

from threading import Thread
import urllib2
import codecs
from contextlib import closing


class Validator:
    def __init__(self, on_fail=None, on_ok=None, on_finish=None):
        for func in [on_fail, on_ok, on_finish]:
            if func is not None and not callable(func):
                raise
        self.__on_fail = on_fail
        self.__on_ok = on_ok
        self.__on_finish = on_finish
        self.__async_scan_thread = None

    def scan(self, *args, **kwargs):
        if self.__async_scan_thread and self.__async_scan_thread.is_alive():
            raise
        self.__async_scan_thread = Thread(target=self.__scan_worker, args=args, kwargs=kwargs)
        self.__async_scan_thread.daemon = True
        self.__async_scan_thread.start()
        return self

    def __scan_worker(self, candidates, threads=2, timeout=11):
        iterable = iter(enumerate(candidates))
        workers = []
        for _ in range(threads):
            thread = Thread(target=self.__worker, args=(iterable, timeout))
            workers.append(thread)
            thread.daemon = True
            thread.start()
        for thread in workers:
            thread.join()
        if self.__on_finish:
            self.__on_finish()

    def __worker(self, iterable, timeout):
        while True:
            pair = next(iterable, None)
            if pair is None:
                break
            index, uri = pair
            try:
                with closing(urllib2.urlopen(uri, timeout=timeout)
                             if urllib2.splittype(uri)[0]
                             else codecs.open(uri, 'r')):
                    if self.__on_ok:
                        self.__on_ok(uri, index)
            except Exception, e:
                if self.__on_fail:
                    self.__on_fail(uri, index, e)

    def join_all(self, timeout=None):
        self.__async_scan_thread.join(timeout)
        return self


if __name__ == '__main__':
    urls = (
        'http://vm-edge-nolanet.la.net.ua/tv/9053.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/9014.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/9018.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/9035.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/9050.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/9060.m3u8',
        'http://vm-edge-nolanet.la.net.ua/tv/1001.m3u8',
        'cool.mp3',
        'validator.pyc',
    )

    from threading import Lock

    print_lock = Lock()


    def pr(x, y, z):
        with print_lock:
            print x, y, z


    Validator(
        on_ok=lambda url, index: pr('Success: ', url, index),
        on_fail=lambda url, index, err: pr('Fail: ', url, index),
        on_finish=lambda: pr('finished !', '!', '!')
    ).scan(urls, threads=4).join_all().scan(urls, threads=16).join_all()
