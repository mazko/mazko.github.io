#!/bin/bash

# chmod +x player.sh && sudo ln -s "`pwd`/player.sh" /usr/local/bin/play-to-tv

set -e
EXEC_TIMEOUT=15

# zeroconf replacement
timeout $EXEC_TIMEOUT adb shell true > /dev/null 2>&1 || {
  BASE_IP=`hostname -I | sed 's/\.[0-9 \t]*$//'`
  IPLIST=`for i in {1..254}; do ( \
    ping $BASE_IP.$i -c 1 -w $EXEC_TIMEOUT  >/dev/null && echo "$BASE_IP.$i" &); done`
  for ip in $IPLIST
  do
    adb kill-server > /dev/null 2>&1
    echo "adb connecting $ip"
    timeout $EXEC_TIMEOUT adb connect $ip > /dev/null 2>&1 || continue
    sleep 1
    timeout $EXEC_TIMEOUT adb shell true > /dev/null 2>&1 && break || continue
  done
}

# MX Player Free + Neon Codecs (adb shell cat /proc/cpuinfo | grep neon) + 
# org.adblockplus.android + 
# com.ttxapps.wifiadb +
# com.farproc.wifi.analyzer to select best channel
case "$1" in
  "-p")
    # pause
    timeout $EXEC_TIMEOUT adb shell input keyevent 62
    ;;
  "-f")
    # seek forward 
    timeout $EXEC_TIMEOUT adb shell input keyevent 22
    ;;
  "-b")
    # seek backward
    timeout $EXEC_TIMEOUT adb shell input keyevent 21
    ;;
  "-c")
    # copy title, url to clipboard
    echo -ne "#EXTINF:0,$2\n$3" | xclip -selection clipboard 2>&1
    ;;
  *)
    # stop
    timeout $EXEC_TIMEOUT adb shell "am force-stop com.mxtech.videoplayer.ad"
    # $# variable will tell you the number of input arguments the script was passed
    if [ $# -ne 0 ]
      then
        # play url $@
        timeout $EXEC_TIMEOUT adb shell \
          "am start -W -a action.intent.action.VIEW \
          -n com.mxtech.videoplayer.ad/.ActivityScreen -d '$@'"
    fi
    ;;
esac