#!/bin/bash
set -e

case "$1" in
  "-p")
    # TODO: pause
    ;;
  "-f")
    # TODO: seek forward 
    ;;
  "-b")
    # TODO: seek backward
    ;;
  "-c")
    # clipboard
    echo -ne "#EXTINF:0,$2\n$3" | xclip -selection clipboard 2>&1
    ;;
  *)
    # stop
    ps aux | grep -ie avplay | awk '{print $2}' | xargs kill -9 > /dev/null 2>&1 || true
    # $# variable will tell you the number of input arguments the script was passed
    if [ $# -ne 0 ]
      then
        # play url $@
        { nohup avplay -threads 8 $@ & } > /dev/null 2>&1
    fi
    ;;
esac