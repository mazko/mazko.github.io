#!/usr/bin/env python 

# more info on the M3U file format available here:
# https://en.wikipedia.org/wiki/M3U

import urllib2
import codecs
from contextlib import closing


class Track:
    def __init__(self, length, title, path):
        self.length = length
        self.title = title
        self.path = path


def parse(uri):
    with closing(urllib2.urlopen(uri)
                 if urllib2.splittype(uri)[0]
                 else codecs.open(uri, 'r')) as inf:
        # initialize playlist variables before reading file
        playlist = []
        song = Track(None, None, None)

        for line_no, line in enumerate(inf):
            try:
                line = line.strip(codecs.BOM_UTF8).strip()
                if line.startswith('#EXTINF:'):
                    # pull length and title from #EXTINF line
                    length, title = line.split('#EXTINF:')[1].split(',', 1)
                    song = Track(length, title, None)
                elif line.startswith('#'):
                    # comment, #EXTM3U
                    pass
                elif len(line) != 0:
                    # pull song path from all other, non-blank lines
                    song.path = line
                    playlist.append(song)

                    # reset the song variable so it doesn't use the same EXTINF more than once
                    song = Track(None, None, None)
            except Exception, ex:
                raise Exception("Can't parse line %d: %s" % (line_no, line), ex)

    return playlist


if __name__ == '__main__':
    m3ufile = 'http://dom-ntv.ru/playlist/Playlist-m3u-IPTV-dom-ntv.m3u'
    playlist = parse(m3ufile)
    for item in playlist:
        print (item.title, item.length, item.path)
