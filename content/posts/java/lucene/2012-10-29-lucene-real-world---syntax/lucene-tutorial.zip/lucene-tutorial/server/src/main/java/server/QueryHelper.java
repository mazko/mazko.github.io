package server;

import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;

import common.LuceneBinding;

final class QueryHelper {
	static Query generate(String story) throws ParseException {
		QueryParser parser = new MultiFieldQueryParser(
				new String[] { LuceneBinding.TITLE_FIELD, LuceneBinding.CONTENT_FIELD }, 
				LuceneBinding.getAnalyzer());

		/* Operator OR is used by default */

		parser.setDefaultOperator(QueryParser.Operator.AND);

		/* Here are some changes for SYNTAX DEMO */

		parser.setAllowLeadingWildcard(true);

		return parser.parse(story);
	}
}