package crawler;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

final class HtmlHelper {
	public static Collection<String> extractLinks(final String html, final String seed) {

		final Document document = Jsoup.parse(html, seed);
		final Set<String> linksSet = new HashSet<String>();
		for (final Element link : document.select("a[href]")) {
			final String strLink = link.attr("abs:href").trim().toLowerCase();
			if (!strLink.isEmpty()) {
				linksSet.add(strLink);
			}
		}

		return Collections.unmodifiableCollection(linksSet);
	}

	public static String download(final String link) throws IOException, InterruptedException {

		IOException ioe;
		int retry = 5;

		do {
			try {

				/* Crawling a real web site politeness > 5s */

				Thread.sleep(1);
				final Document bDoc = Jsoup.connect(link).userAgent("Mozilla").timeout(30000).get();
				return bDoc.html();
			} catch (final IOException ex) {
				ioe = ex;
			}
		} while (--retry > 0);

		throw ioe;
	}

	public static String extractTitle(final String html) {
		final Document doc = Jsoup.parse(html);
		final Elements elements = doc.select("table table div table font");
		if (elements != null && !elements.isEmpty()) {
			return elements.first().text();
		}
		return null;
	}

	public static String extractContent(final String html) {
		final Document doc = Jsoup.parse(html);
		final Elements elements = doc.select("table table div table div");
		if (elements != null && !elements.isEmpty()) {
			return elements.first().text();
		}
		return doc.select("table table div table").first().text();
	}
}