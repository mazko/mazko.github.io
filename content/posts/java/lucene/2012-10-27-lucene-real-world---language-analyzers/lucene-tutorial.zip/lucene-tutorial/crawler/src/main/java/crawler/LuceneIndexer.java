package crawler;

import java.io.Closeable;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import common.LuceneBinding;

class LuceneIndexer implements Closeable {
	private static final Logger logger = Logger.getLogger(LuceneIndexer.class.getName());

	/* IndexWriter is completely thread safe */

	private IndexWriter indexWriter = null;

	@Override
	public void close() throws IOException {
		if (this.indexWriter != null) {
			LuceneIndexer.logger
					.info("Closing Index < " + LuceneBinding.INDEX_PATH + " > NumDocs: " + this.indexWriter.numDocs());
			this.indexWriter.close();
			this.indexWriter = null;
			LuceneIndexer.logger.info("Index Closed OK!");
		} else {
			throw new IOException("Index already closed");
		}
	}

	public void new_index() throws IOException {
		final Directory directory = FSDirectory.open(LuceneBinding.INDEX_PATH);
		final IndexWriterConfig iwConfig = new IndexWriterConfig(LuceneBinding.getAnalyzer());
		iwConfig.setOpenMode(OpenMode.CREATE);
		this.indexWriter = new IndexWriter(directory, iwConfig);
	}

	public void add(final String url, final String html) {

		final String title = HtmlHelper.extractTitle(html);
		final String content = HtmlHelper.extractContent(html);

		LuceneIndexer.logger.info("***** " + url + " *****");
		if (title != null) {
			LuceneIndexer.logger.info(title);
		}
		LuceneIndexer.logger.info(content);

		final Document doc = new Document();

		final FieldType urlType = new FieldType();
		urlType.setIndexOptions(IndexOptions.DOCS);
		urlType.setStored(true);
		urlType.setTokenized(false);
		urlType.setStoreTermVectorOffsets(false);
		urlType.setStoreTermVectorPayloads(false);
		urlType.setStoreTermVectorPositions(false);
		urlType.setStoreTermVectors(false);
		doc.add(new Field(LuceneBinding.URI_FIELD, url, urlType));

		final FieldType tokType = new FieldType();
		tokType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS_AND_OFFSETS);
		tokType.setStored(true);
		tokType.setTokenized(true);
		tokType.setStoreTermVectorOffsets(true);
		tokType.setStoreTermVectorPayloads(true);
		tokType.setStoreTermVectorPositions(true);
		tokType.setStoreTermVectors(true);
		if (title != null) {
			doc.add(new Field(LuceneBinding.TITLE_FIELD, title, tokType));
		}
		doc.add(new Field(LuceneBinding.CONTENT_FIELD, content, tokType));

		// Language setStored(false) - we already have original value

		final FieldType lngType = new FieldType();
		lngType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS_AND_OFFSETS);
		lngType.setStored(false);
		lngType.setTokenized(true);
		lngType.setStoreTermVectorOffsets(true);
		lngType.setStoreTermVectorPayloads(true);
		lngType.setStoreTermVectorPositions(true);
		lngType.setStoreTermVectors(true);

		/* Russian */

		if (title != null) {
			doc.add(new Field(LuceneBinding.RUS_TITLE_FIELD, title, lngType));
		}
		doc.add(new Field(LuceneBinding.RUS_CONTENT_FIELD, content, lngType));

		/* English */

		if (title != null) {
			doc.add(new Field(LuceneBinding.ENG_TITLE_FIELD, title, lngType));
		}
		doc.add(new Field(LuceneBinding.ENG_CONTENT_FIELD, content, lngType));

		try {
			if (this.indexWriter != null) {
				this.indexWriter.addDocument(doc);
			}
		} catch (final IOException ex) {
			LuceneIndexer.logger.error(ex);
		}
	}
}
