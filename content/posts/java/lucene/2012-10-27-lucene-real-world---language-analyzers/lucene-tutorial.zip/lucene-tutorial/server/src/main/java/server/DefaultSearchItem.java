package server;

import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.ScoreDoc;

import common.LuceneBinding;

public class DefaultSearchItem {
	public final String title, content, uri;
	public final float score;

	DefaultSearchItem(final String title, final String content, final String uri, final float score) {

		this.uri = uri;
		this.title = title;
		this.content = content;
		this.score = score;
	}
}

class DefaultAgregator extends Aggregator<DefaultSearchItem> {

	@Override
	DefaultSearchItem aggregate(final ScoreDoc sd) throws IOException, CorruptIndexException {
		final Document doc = this.indexSearcher.doc(sd.doc);

		return new DefaultSearchItem(doc.get(LuceneBinding.TITLE_FIELD), doc.get(LuceneBinding.CONTENT_FIELD),
				doc.get(LuceneBinding.URI_FIELD), sd.score);
	}

}