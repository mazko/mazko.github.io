package server;

import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.QueryParserBase;
import org.apache.lucene.search.Query;

import common.LuceneBinding;

final class QueryHelper {
	static Query generate(final String story) throws ParseException {
		final QueryParser parser = new MultiFieldQueryParser(
				new String[] { 
						LuceneBinding.TITLE_FIELD, 
						LuceneBinding.CONTENT_FIELD,
						/* Russian */
						LuceneBinding.RUS_TITLE_FIELD, 
						LuceneBinding.RUS_CONTENT_FIELD,
						/* English */
						LuceneBinding.ENG_TITLE_FIELD, 
						LuceneBinding.ENG_CONTENT_FIELD },
				LuceneBinding.getAnalyzer());
		/* Operator OR is used by default */

		parser.setDefaultOperator(QueryParser.Operator.AND);

		return parser.parse(QueryParserBase.escape(story));
	}
}