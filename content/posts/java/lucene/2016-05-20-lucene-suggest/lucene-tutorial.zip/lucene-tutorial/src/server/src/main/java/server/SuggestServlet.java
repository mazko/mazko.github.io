package server;

import java.io.IOException;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import common.LuceneBinding.Suggester;

public class SuggestServlet extends HttpServlet {

	private static volatile Suggester suggester;
	private static int MAX_SUGGESTS = 22;

	@Override
	public void doGet(final HttpServletRequest req, final HttpServletResponse res)
			throws ServletException, IOException {

		if (SuggestServlet.suggester == null) {
			synchronized (SuggestServlet.class) {
				if (SuggestServlet.suggester == null) {
					SuggestServlet.suggester = Suggester.load();
				}
			}
		}

		final String query = req.getParameter("q");
		final Collection<?> lookupResultList = SuggestServlet.suggester
				.lookup(query, false, SuggestServlet.MAX_SUGGESTS).stream()
				.sorted((e1, e2) -> Long.compare(e2.value, e1.value))
				.map(v -> Stream
						.of(new SimpleEntry<>("key", v.key), new SimpleEntry<>("hi", v.highlightKey),
								new SimpleEntry<>("val", v.value))
						.collect(HashMap::new, (m, e) -> m.put(e.getKey(), e.getValue()), Map::putAll))
				.collect(Collectors.toCollection(ArrayList::new));

		final JSONArray json = new JSONArray(lookupResultList);
		res.setContentType("application/json");
		res.setCharacterEncoding("UTF-8");
		res.getWriter().write(json.toString());
	}
}