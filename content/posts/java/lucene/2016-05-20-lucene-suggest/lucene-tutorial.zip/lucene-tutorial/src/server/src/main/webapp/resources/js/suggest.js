(function () {
	var input = document.getElementById('input-suggest')
	var awesomplete = new Awesomplete(input, 
		{filter: function() { return true }})
	var lastValue = null

	input.onkeyup = function(e) {
		if (lastValue === input.value || e.keyCode == 13) return
		lastValue = input.value
		fetch("/api/suggest?q=" + 
				encodeURIComponent(input.value) + 
				"&_=" + new Date().getTime())
			.then(function(response) {
				if (response.status !== 200) {
					throw('Status Code: ' +  response.status)
				}
					return response.json()
			})
			.then(function(data) {
				if (lastValue === input.value) {
					awesomplete.list = data.map(function(v) {
						return v.key
					})
				}
			})  
			.catch(function(err) {  
				console.error('Fetch Error :-S', err);
			});
	}
})();