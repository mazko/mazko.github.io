package crawler;

import java.io.Closeable;
import java.io.IOException;
import java.nio.file.Path;

import org.apache.lucene.analysis.shingle.ShingleAnalyzerWrapper;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.search.spell.LuceneDictionary;
import org.apache.lucene.store.FSDirectory;

import common.LuceneBinding;
import common.LuceneBinding.Suggester;

public class SugestIndexer implements Closeable {

	private final IndexWriter writer;
	public static final String FIELD_SUGGEST = "SUGGEST";
	private static final Path SHINGLES_INDEX_PATH = LuceneBinding.SUGGEST_INDEX_PATH.resolve("shingles");

	public SugestIndexer() throws IOException {
		final IndexWriterConfig iwConfig = new IndexWriterConfig(
				new ShingleAnalyzerWrapper(LuceneBinding.getAnalyzer(), LuceneBinding.SUGGEST_MAX_SHINGLES));
		iwConfig.setOpenMode(OpenMode.CREATE);
		this.writer = new IndexWriter(FSDirectory.open(SugestIndexer.SHINGLES_INDEX_PATH), iwConfig);
	}

	public void add(final String... items) throws IOException {
		final Document doc = new Document();
		for (final String item : items) {
			doc.add(new TextField(SugestIndexer.FIELD_SUGGEST, item, Store.NO));
		}
		this.writer.addDocument(doc);
	}

	@Override
	public void close() throws IOException {
		this.writer.close();
		try (final IndexReader reader = DirectoryReader.open(this.writer.getDirectory())) {
			Suggester.store(new LuceneDictionary(reader, SugestIndexer.FIELD_SUGGEST));
		}
		// TODO: remove SHINGLES_INDEX_PATH directory
	}
}
