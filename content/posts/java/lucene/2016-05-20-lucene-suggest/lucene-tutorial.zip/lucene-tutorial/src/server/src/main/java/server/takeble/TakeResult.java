package server.takeble;

import java.util.Collection;
import java.util.Collections;

public class TakeResult<T> {
	private final int totalHits;
	private final Collection<T> items;

	protected TakeResult(final int totalHits, final Collection<T> items) {
		this.totalHits = totalHits;
		this.items = items;
	}

	public Collection<T> getItems() {
		if (this.items != null) {
			return Collections.unmodifiableCollection(this.items);
		}
		return null;
	}

	public int getTotalHits() {
		return this.totalHits;
	}
}
