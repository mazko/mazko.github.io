package server;

import java.io.IOException;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.lucene.facet.DrillSideways.DrillSidewaysResult;
import org.apache.lucene.facet.FacetResult;
import org.apache.lucene.facet.Facets;

import common.LuceneBinding;
import server.takeble.TakeResult;

public final class FacetTakeResult<T> extends TakeResult<T> {

	private static final int TOP = 333;

	private final Map<String, Number> directors;

	private final Map<String, Number> categories;

	private final Map<String, SimpleEntry<Number, Map<String, Number>>> dates;

	public Map<String, Number> getDirectors() {
		return this.directors;
	}

	public Map<String, Number> getCategories() {
		return this.categories;
	}

	public Map<String, SimpleEntry<Number, Map<String, Number>>> getDates() {
		return this.dates;
	}

	private static FacetResult bugHelper(final Facets facets, final String... path) {
		try {
			return facets.getTopChildren(FacetTakeResult.TOP, LuceneBinding.FACET_DATE, path);
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	public FacetTakeResult(final int totalHits, final Collection<T> items, final DrillSidewaysResult facetDrill)
			throws IOException {

		super(totalHits, items);

		if (totalHits > 0) {

			// Facets extraction: categories + date

			final Facets facets = facetDrill.facets;

			this.directors = Collections
					.unmodifiableMap(Arrays
							.stream(facets.getTopChildren(FacetTakeResult.TOP,
									LuceneBinding.FACET_DIRECTOR).labelValues)
							.sorted((e1, e2) -> Integer.compare(e2.value.intValue(), e1.value.intValue()))
							.collect(LinkedHashMap::new, (m, v) -> m.put(v.label, v.value), Map::putAll));

			this.categories = Collections
					.unmodifiableMap(Arrays
							.stream(facets.getTopChildren(FacetTakeResult.TOP,
									LuceneBinding.FACET_CATEGORY).labelValues)
							.sorted((e1, e2) -> Integer.compare(e2.value.intValue(), e1.value.intValue()))
							.collect(LinkedHashMap::new, (m, v) -> m.put(v.label, v.value), Map::putAll));

			this.dates = Collections
					.unmodifiableMap(Arrays.stream(FacetTakeResult.bugHelper(facets).labelValues)
							.sorted((y1, y2) -> Integer.compare(y2.value.intValue(), y1.value.intValue()))
							.collect(LinkedHashMap::new, (ymap, y) -> ymap.put(y.label, new SimpleEntry<>(y.value,
									Collections.unmodifiableMap(Arrays
											.stream(FacetTakeResult.bugHelper(facets, y.label).labelValues).sorted(
													(m1, m2) -> Integer.compare(m2.value.intValue(),
															m1.value.intValue()))
											.collect(LinkedHashMap::new, (mmap, m) -> mmap.put(m.label, m.value),
													Map::putAll)))),
									Map::putAll));
		} else {
			this.dates = null;
			this.directors = this.categories = null;
		}

	}

	public FacetTakeResult(final int totalHits, final DrillSidewaysResult facetDrill) throws IOException {
		this(totalHits, (Collection<T>) null, facetDrill);
	}
}