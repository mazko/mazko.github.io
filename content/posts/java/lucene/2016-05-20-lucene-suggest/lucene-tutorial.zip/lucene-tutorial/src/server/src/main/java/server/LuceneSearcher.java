package server;

import java.io.IOException;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.facet.DrillDownQuery;
import org.apache.lucene.facet.DrillSideways;
import org.apache.lucene.facet.DrillSideways.DrillSidewaysResult;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyReader;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TopFieldCollector;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import common.LuceneBinding;
import server.takeble.ITakeble;

abstract class SearchAggregator<T> {
	protected Query query;
	protected IndexSearcher indexSearcher;

	abstract T aggregate(ScoreDoc sd) throws IOException, CorruptIndexException, InvalidTokenOffsetsException;
}

class LuceneSearcher<T, A extends SearchAggregator<T>> implements ITakeble<T> {

	private final String story;
	private final List<SimpleEntry<String, String[]>> facets;
	private final Class<A> classA;

	/* IndexReader is thread safe - one instance for all requests */

	private static volatile IndexReader indexReader;

	private static volatile TaxonomyReader taxoReader;

	LuceneSearcher(final Class<A> classA, final String story, final List<SimpleEntry<String, String[]>> facets)
			throws IOException {

		this.story = story;
		this.facets = facets;
		this.classA = classA;

		if (LuceneSearcher.indexReader == null) {
			synchronized (LuceneSearcher.class) {
				if (LuceneSearcher.indexReader == null) {
					final Directory dir = FSDirectory.open(LuceneBinding.SEARCH_INDEX_PATH);
					LuceneSearcher.indexReader = DirectoryReader.open(dir);
				}
			}
		}

		if (LuceneSearcher.taxoReader == null) {
			synchronized (LuceneSearcher.class) {
				if (LuceneSearcher.taxoReader == null) {
					LuceneSearcher.taxoReader = new DirectoryTaxonomyReader(
							FSDirectory.open(LuceneBinding.TAXO_INDEX_PATH));
				}
			}
		}
	}

	@Override
	public FacetTakeResult<T> Take(final int count, final int start) throws ParseException, IOException,
			InstantiationException, IllegalAccessException, InvalidTokenOffsetsException {

		final int nDocs = start + count;

		final DrillDownQuery query = new DrillDownQuery(LuceneBinding.getFacetsConfig(),
				QueryHelper.generate(this.story));

		this.facets.forEach((i) -> query.add(i.getKey(), i.getValue()));

		final IndexSearcher indexSearcher = new IndexSearcher(LuceneSearcher.indexReader);
		final SortField sortField = new SortField(LuceneBinding.FIELD_RATE, SortField.Type.FLOAT, true);
		final TopFieldCollector topCollector = TopFieldCollector.create(new Sort(sortField), Math.max(nDocs, 1), false,
				true, false);

		final DrillSideways facetDrill = new DrillSideways(indexSearcher, LuceneBinding.getFacetsConfig(),
				LuceneSearcher.taxoReader);
		final DrillSidewaysResult drillResult = facetDrill.search(query, topCollector);

		final TopDocs topDocs = topCollector.topDocs();

		if (nDocs <= 0) {
			return new FacetTakeResult<T>(topDocs.totalHits, drillResult);
		}

		final ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		final int length = scoreDocs.length - start;

		if (length <= 0) {
			return new FacetTakeResult<T>(topDocs.totalHits, drillResult);
		}

		final List<T> items = new ArrayList<T>(length);
		final A aggregator = this.classA.newInstance();
		aggregator.query = query;
		aggregator.indexSearcher = indexSearcher;

		for (int i = start; i < scoreDocs.length; i++) {
			items.add(i - start, aggregator.aggregate(scoreDocs[i]));
		}

		return new FacetTakeResult<T>(topDocs.totalHits, items, drillResult);
	}
}