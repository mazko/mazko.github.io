package common;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.facet.FacetsConfig;
import org.apache.lucene.search.spell.Dictionary;
import org.apache.lucene.search.suggest.InputIterator;
import org.apache.lucene.search.suggest.analyzing.AnalyzingSuggester;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;

/* This class is used both by Crawler and SearchServlet */

public final class LuceneBinding {
	private static final Path ROOT = Paths.get(System.getProperty("user.home"), "lucene-tutorial-index");
	public static final Path SEARCH_INDEX_PATH = LuceneBinding.ROOT.resolve("search");
	public static final Path TAXO_INDEX_PATH = LuceneBinding.ROOT.resolve("taxo");
	public static final Path SUGGEST_INDEX_PATH = LuceneBinding.ROOT.resolve("suggest");

	public static final String FIELD_ID = "id";
	public static final String FIELD_TITLE = "title";
	public static final String FIELD_CONTENT = "content";
	public static final String FIELD_CATEGORY = "category";
	public static final String FIELD_DIRECTOR = "director";
	public static final String FIELD_RATE = "rate";

	public static final String FACET_DIRECTOR = "Director";
	public static final String FACET_DATE = "Release Date";
	public static final String FACET_CATEGORY = "Category";

	public static final int SUGGEST_MAX_SHINGLES = 5;

	public static FacetsConfig getFacetsConfig() {
		final FacetsConfig config = new FacetsConfig();
		config.setHierarchical(LuceneBinding.FACET_DATE, true);
		config.setMultiValued(LuceneBinding.FACET_CATEGORY, true);
		return config;
	}

	public static Analyzer getAnalyzer() {
		return new StandardAnalyzer();
	}

	public static final class Suggester extends AnalyzingSuggester {
		private static final Path ser = LuceneBinding.SUGGEST_INDEX_PATH.resolve("serialized");

		private Suggester() throws IOException {
			super(FSDirectory.open(LuceneBinding.SUGGEST_INDEX_PATH.resolve("tmp")), "", LuceneBinding.getAnalyzer());
		}

		public static void store(final Dictionary input) throws IOException {
			final Suggester suggester = new Suggester();
			suggester.build(new InputIterator() {
				final InputIterator i = input.getEntryIterator();
				private BytesRef c;
				final int MAX_TOKEN_LENGTH = LuceneBinding.SUGGEST_MAX_SHINGLES
						* (1 + StandardAnalyzer.DEFAULT_MAX_TOKEN_LENGTH);

				@Override
				public BytesRef next() throws IOException {
					this.c = this.i.next();
					return this.c;
				}

				@Override
				public long weight() {
					// short phrases more important
					return this.MAX_TOKEN_LENGTH - this.c.length;
				}

				@Override
				public BytesRef payload() {
					return this.i.payload();
				}

				@Override
				public boolean hasPayloads() {
					return this.i.hasPayloads();
				}

				@Override
				public Set<BytesRef> contexts() {
					return this.i.contexts();
				}

				@Override
				public boolean hasContexts() {
					return this.i.hasContexts();
				}
			});

			try (final OutputStream os = Files.newOutputStream(Suggester.ser)) {
				suggester.store(os);
			}
		}

		public static Suggester load() throws IOException {
			final Suggester suggester = new Suggester();
			try (final InputStream is = Files.newInputStream(Suggester.ser)) {
				suggester.load(is);
			}
			return suggester;
		}
	}
}
