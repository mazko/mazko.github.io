package server;

import java.io.IOException;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.LuceneBinding;

public class SearchServlet extends HttpServlet {

	public final static String QUERY_INPUT = "q";
	public final static String RESULTS_PER_PAGE = "per";
	public final static String CURRENT_PAGE = "cur";
	public final static String DIRECTED = "dir";
	public final static String CATEGORY = "cat";
	public final static String DATE = "date";

	public static int parseWithDefault(final String number, final int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (final NumberFormatException e) {
			return defaultVal;
		}
	}

	@Override
	public void doGet(final HttpServletRequest req, final HttpServletResponse res)
			throws ServletException, IOException {

		final String query = req.getParameter(SearchServlet.QUERY_INPUT);
		final int currentPage = SearchServlet.parseWithDefault(req.getParameter(SearchServlet.CURRENT_PAGE), 1);
		final int itemsPerPage = SearchServlet.parseWithDefault(req.getParameter(SearchServlet.RESULTS_PER_PAGE), 5);

		final String dir = req.getParameter(SearchServlet.DIRECTED);
		final String[] cats = req.getParameterValues(SearchServlet.CATEGORY);
		final String date = req.getParameter(SearchServlet.DATE);

		if (query != null && !query.isEmpty()) {
			try {
				final List<SimpleEntry<String, String[]>> facets = new ArrayList<>();
				if (dir != null && !dir.isEmpty()) {
					facets.add(new SimpleEntry<>(LuceneBinding.FACET_DIRECTOR, new String[] { dir }));
				}
				if (cats != null) {
					Arrays.stream(cats).filter(c -> !c.isEmpty()).forEach(
							c -> facets.add(new SimpleEntry<>(LuceneBinding.FACET_CATEGORY, new String[] { c })));
				}
				if (date != null && !date.isEmpty()) {
					facets.add(new SimpleEntry<>(LuceneBinding.FACET_DATE, date.split("-")));
				}
				req.setAttribute("searchmodel",
						new LuceneSearcher<HighlightedSearchItem, HighlightedSearchAgregator>(
								HighlightedSearchAgregator.class, query.trim(), Collections.unmodifiableList(facets))
										.Take(itemsPerPage, (currentPage - 1) * itemsPerPage));
			} catch (final Exception e) {
				throw new ServletException(e);
			}
		}

		req.setAttribute("searchcontext", Collections.unmodifiableMap(Stream
				.of(new SimpleEntry<>(SearchServlet.QUERY_INPUT, query), new SimpleEntry<>(SearchServlet.DIRECTED, dir),
						new SimpleEntry<>(SearchServlet.CATEGORY, cats), new SimpleEntry<>(SearchServlet.DATE, date),
						new SimpleEntry<>(SearchServlet.CURRENT_PAGE, currentPage),
						new SimpleEntry<>(SearchServlet.RESULTS_PER_PAGE, itemsPerPage))
				.collect(HashMap::new, (m, v) -> m.put(v.getKey(), v.getValue()), HashMap::putAll)));

		this.getServletContext().getRequestDispatcher("/index.jsp").forward(req, res);
	}
}