package server;

import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;

import common.LuceneBinding;

final class QueryHelper {
	static Query generate(final String story) throws ParseException {
		final QueryParser parser = new MultiFieldQueryParser(
				new String[] { LuceneBinding.FIELD_TITLE, LuceneBinding.FIELD_CONTENT }, LuceneBinding.getAnalyzer());

		/* Operator OR is used by default */

		parser.setDefaultOperator(QueryParser.Operator.AND);

		/* Here are some changes for SYNTAX DEMO */

		parser.setAllowLeadingWildcard(true);

		return parser.parse(story);
	}
}