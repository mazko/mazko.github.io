package crawler;

import java.io.Closeable;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.FloatDocValuesField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import common.LuceneBinding;

class LuceneIndexer implements Closeable {
	private static final Logger logger = Logger.getLogger(LuceneIndexer.class.getName());

	/* IndexWriter is completely thread safe */

	private IndexWriter indexWriter = null;

	private DirectoryTaxonomyWriter taxoWriter = null;

	@Override
	public void close() throws IOException {
		LuceneIndexer.logger.info(
				"Closing Index < " + LuceneBinding.SEARCH_INDEX_PATH + " > NumDocs: " + this.indexWriter.numDocs());
		this.indexWriter.close();
		this.taxoWriter.close();
		LuceneIndexer.logger.info("Index closed OK!");
	}

	public void new_index() throws IOException {
		final Directory directory = FSDirectory.open(LuceneBinding.SEARCH_INDEX_PATH);
		final IndexWriterConfig iwConfig = new IndexWriterConfig(LuceneBinding.getAnalyzer());
		iwConfig.setOpenMode(OpenMode.CREATE);
		this.indexWriter = new IndexWriter(directory, iwConfig);
		this.taxoWriter = new DirectoryTaxonomyWriter(FSDirectory.open(LuceneBinding.TAXO_INDEX_PATH));
	}

	public void add(final int id, final String title, final String content, final String director, final String[] cats,
			final Date date, final float rate) throws IOException {

		LuceneIndexer.logger.info("***** " + title + " *****");
		LuceneIndexer.logger.info(content);

		final Document doc = new Document();

		// A field that is indexed but not tokenized: the entire String value is
		// indexed as a single token
		doc.add(new StringField(LuceneBinding.FIELD_ID, new Integer(id).toString(), Store.YES));

		// A field that is indexed and tokenized, without term vectors.
		doc.add(new TextField(LuceneBinding.FIELD_TITLE, title, Store.YES));
		doc.add(new TextField(LuceneBinding.FIELD_CONTENT, content, Store.YES));

		// A field that is indexed but not tokenized
		doc.add(new StringField(LuceneBinding.FIELD_DIRECTOR, director, Store.YES));

		// Field that stores a per-document long value for scoring, sorting or
		// value retrieval
		doc.add(new FloatDocValuesField(LuceneBinding.FIELD_RATE, rate));
		doc.add(new StringField(LuceneBinding.FIELD_RATE, Float.toString(rate), Store.YES));

		// Facet
		doc.add(new FacetField(LuceneBinding.FACET_DIRECTOR, director));
		for (final String cat : cats) {
			doc.add(new FacetField(LuceneBinding.FACET_CATEGORY, cat));
			doc.add(new StringField(LuceneBinding.FIELD_CATEGORY, cat, Store.YES));
		}
		doc.add(new FacetField(LuceneBinding.FACET_DATE, new SimpleDateFormat("yyyy").format(date),
				new SimpleDateFormat("MM").format(date), new SimpleDateFormat("dd").format(date)));

		this.indexWriter.addDocument(LuceneBinding.getFacetsConfig().build(this.taxoWriter, doc));
	}
}
