package crawler;

import java.io.FileReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.StreamSupport;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class App {

	private static final Logger logger = Logger.getLogger(App.class.getName());

	public static void main(final String[] args) {
		try (final LuceneIndexer luceneIndexer = new LuceneIndexer()) {
			luceneIndexer.new_index();
			try (final Reader fileReader = new FileReader("../Top.json")) {
				for (final Object o : new JSONArray(new JSONTokener(fileReader))) {
					final JSONObject jo = (JSONObject) o;
					final int id = jo.getInt("id");
					final String title = jo.getString("name");
					final String description = jo.getString("description");
					final String[] category = StreamSupport.stream(jo.getJSONArray("category").spliterator(), false)
							.toArray(size -> new String[size]);
					final Date date = new SimpleDateFormat("yyyy-MM-dd").parse(jo.getString("date"));
					final String director = (String) StreamSupport
							.stream(jo.getJSONArray("directed").spliterator(), false).findFirst().orElse("НЕИЗВЕСТЕН");
					final float rate = (float) jo.getDouble("rate");
					luceneIndexer.add(id, title, description, director, category, date, rate);
				}
			}
		} catch (final Exception ex) {
			App.logger.error("Unable to start !", ex);
		}
	}
}