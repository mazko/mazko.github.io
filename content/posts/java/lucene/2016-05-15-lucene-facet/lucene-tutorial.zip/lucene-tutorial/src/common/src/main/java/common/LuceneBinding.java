package common;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.facet.FacetsConfig;

/* This class is used both by Crawler and SearchServlet */

public final class LuceneBinding {
	public static final Path SEARCH_INDEX_PATH = Paths.get(System.getProperty("user.home"), "lucene-tutorial-index",
			"search");
	public static final Path TAXO_INDEX_PATH = Paths.get(System.getProperty("user.home"), "lucene-tutorial-index",
			"taxo");

	public static final String FIELD_ID = "id";
	public static final String FIELD_TITLE = "title";
	public static final String FIELD_CONTENT = "content";
	public static final String FIELD_CATEGORY = "category";
	public static final String FIELD_DIRECTOR = "director";
	public static final String FIELD_RATE = "rate";

	public static final String FACET_DIRECTOR = "Director";
	public static final String FACET_DATE = "Release Date";
	public static final String FACET_CATEGORY = "Category";

	public static FacetsConfig getFacetsConfig() {
		final FacetsConfig config = new FacetsConfig();
		config.setHierarchical(LuceneBinding.FACET_DATE, true);
		config.setMultiValued(LuceneBinding.FACET_CATEGORY, true);
		return config;
	}

	public static Analyzer getAnalyzer() {
		return new StandardAnalyzer();
	}
}
