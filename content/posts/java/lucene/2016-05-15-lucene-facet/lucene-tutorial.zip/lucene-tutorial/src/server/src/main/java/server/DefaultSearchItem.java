package server;

public class DefaultSearchItem {
	private final String title, content, id, director, rate;

	public String getTitle() {
		return this.title;
	}

	public String getContent() {
		return this.content;
	}

	public String getId() {
		return this.id;
	}

	private final float score;

	public String getRate() {
		return this.rate;
	}

	public float getScore() {
		return this.score;
	}

	private final String[] categories;

	public String getDirector() {
		return this.director;
	}

	public String[] getCategories() {
		return this.categories;
	}

	DefaultSearchItem(final float score, final String title, final String content, final String id,
			final String director, final String[] categories, final String rate) {
		this.id = id;
		this.title = title;
		this.content = content;
		this.score = score;
		this.director = director;
		this.categories = categories;
		this.rate = rate;
	}
}