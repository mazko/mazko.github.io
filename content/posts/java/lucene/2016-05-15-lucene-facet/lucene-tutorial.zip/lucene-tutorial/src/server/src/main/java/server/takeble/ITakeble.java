package server.takeble;

import java.io.IOException;

import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;

public interface ITakeble<T> {
	TakeResult<T> Take(int count, int start) throws ParseException, IOException, InstantiationException,
			IllegalAccessException, InvalidTokenOffsetsException;
}