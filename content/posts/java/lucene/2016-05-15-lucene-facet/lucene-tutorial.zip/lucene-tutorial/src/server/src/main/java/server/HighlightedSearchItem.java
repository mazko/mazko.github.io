package server;

import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.highlight.SimpleSpanFragmenter;

import common.LuceneBinding;

public class HighlightedSearchItem extends DefaultSearchItem {

	public final String highlightedTitle, highlightedContent;

	public String getHighlightedTitle() {
		return this.highlightedTitle;
	}

	public String getHighlightedContent() {
		return this.highlightedContent;
	}

	HighlightedSearchItem(final float score, final String title, final String content, final String id,
			final String director, final String[] categories, final String rate, final String highlightedTitle,
			final String highlightedContent) {
		super(score, title, content, id, director, categories, rate);
		this.highlightedContent = highlightedContent;
		this.highlightedTitle = highlightedTitle;
	}
}

class HighlightedSearchAgregator extends SearchAggregator<HighlightedSearchItem> {

	private Highlighter highlighter;

	private final String tryHighlight(final String text, final String[] fields)
			throws IOException, InvalidTokenOffsetsException {

		if (text == null) {
			return null;
		}

		if (this.highlighter == null) {
			final QueryScorer scorer = new QueryScorer(this.query);
			this.highlighter = new Highlighter(new SimpleHTMLFormatter("[mazko.github.io]", "[/mazko.github.io]"),
					scorer);
			this.highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer, 330));
		}

		for (final String field : fields) {
			final String highlighted = this.highlighter.getBestFragment(LuceneBinding.getAnalyzer(), field, text);
			if (highlighted != null) {
				return highlighted;
			}
		}

		return text;
	}

	@Override
	HighlightedSearchItem aggregate(final ScoreDoc sd)
			throws IOException, CorruptIndexException, InvalidTokenOffsetsException {

		final Document doc = this.indexSearcher.doc(sd.doc);
		final String title = doc.get(LuceneBinding.FIELD_TITLE);
		final String content = doc.get(LuceneBinding.FIELD_CONTENT);

		final String highlightedTitle = this.tryHighlight(title, new String[] { LuceneBinding.FIELD_TITLE });
		final String highlightedContent = this.tryHighlight(content, new String[] { LuceneBinding.FIELD_CONTENT });

		return new HighlightedSearchItem(sd.score, title, content, doc.get(LuceneBinding.FIELD_ID),
				doc.get(LuceneBinding.FIELD_DIRECTOR), doc.getValues(LuceneBinding.FIELD_CATEGORY),
				doc.get(LuceneBinding.FIELD_RATE), highlightedTitle, highlightedContent);
	}
}
