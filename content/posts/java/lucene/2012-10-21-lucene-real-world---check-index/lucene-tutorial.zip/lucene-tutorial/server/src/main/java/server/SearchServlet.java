package server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.index.CheckIndex;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class SearchServlet extends HttpServlet {

    @Override
    public void doGet(final HttpServletRequest req, final HttpServletResponse res)
            throws ServletException, IOException {
        try (final OutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            final Directory dir = FSDirectory.open(common.LuceneBinding.INDEX_PATH);
            try (final CheckIndex checkIndex = new CheckIndex(dir)) {
                checkIndex.setInfoStream(new PrintStream(byteArrayOutputStream));
                checkIndex.checkIndex();
                byteArrayOutputStream.flush();
                req.setAttribute("checkindexmodel", byteArrayOutputStream.toString());
            }
        }

        this.getServletContext().getRequestDispatcher("/index.jsp").forward(req, res);
    }
}
