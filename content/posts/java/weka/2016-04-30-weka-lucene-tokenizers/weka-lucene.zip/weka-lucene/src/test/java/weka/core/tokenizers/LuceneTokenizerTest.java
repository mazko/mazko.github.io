package weka.core.tokenizers;

import org.junit.Assert;
import org.junit.Test;


public class LuceneTokenizerTest {

	/** Creates a default LuceneTokenizer */
	final Tokenizer m_Tokenizer = new LuceneTokenizer();

	/**
	 * tests the number of generated tokens
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNumberOfGeneratedTokens() throws Exception {

		final String s = "HOWEVER, the egg only got larger and larger, and more and more human";
		String[] result;

		// only 1-grams

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "1", s });
		Assert.assertEquals("number of tokens differ (1)", 13, result.length);

		// only 2-grams

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "2", "-max", "2", s });
		Assert.assertEquals("number of tokens differ (2)", 12, result.length);

		// 1 to 3-grams

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "3", s });
		Assert.assertEquals("number of tokens differ (3)", 36, result.length);

		// 1 to 5-grams

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "5", s });
		Assert.assertEquals("number of tokens differ (4)", 55, result.length);
	}

	/**
	 * tests the number of generated tokens
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNumberOfGeneratedTokensCannotSplit() throws Exception {

		// 1 to 3-grams, but sentence only has 2 grams

		final String s = "cannot split";
		String[] result;

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "3", s });
		Assert.assertEquals("number of tokens differ", 3, result.length);
	}

	/**
	 * tests the number of generated tokens
	 * 
	 * @throws Exception
	 */
	@Test
	public void testNumberOfGeneratedBlank() throws Exception {
		String s;
		String[] result;

		s = " ";
		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "3", s });
		Assert.assertEquals("number of tokens differ", 0, result.length);

		s = "!-/";
		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "3", s });
		Assert.assertEquals("number of tokens differ", 0, result.length);
	}

	/**
	 * tests the content of generated tokens
	 * 
	 * @throws Exception
	 */
	@Test
	public void testContentOfGeneratedTokens() throws Exception {
		final String s = "The quick brown fox jumps over the lazy dog@dog.com";
		String[] result;

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "1", "-max", "3", s });
		Assert.assertArrayEquals("dismatch", new String[] {
			"The", "The quick", "The quick brown",
			"quick", "quick brown", "quick brown fox",
			"brown", "brown fox", "brown fox jumps",
			"fox", "fox jumps", "fox jumps over",
			"jumps", "jumps over", "jumps over the",
			"over", "over the", "over the lazy",
			"the", "the lazy", "the lazy dog@dog.com",
			"lazy", "lazy dog@dog.com", "dog@dog.com"
		}, result);

		result = Tokenizer.tokenize(m_Tokenizer, new String[] { "-min", "2", "-max", "4", s });
		Assert.assertArrayEquals("dismatch", new String[] {
			"The quick", "The quick brown", "The quick brown fox",
			"quick brown", "quick brown fox", "quick brown fox jumps",
			"brown fox", "brown fox jumps", "brown fox jumps over",
			"fox jumps", "fox jumps over", "fox jumps over the",
			"jumps over", "jumps over the", "jumps over the lazy",
			"over the", "over the lazy", "over the lazy dog@dog.com",
			"the lazy", "the lazy dog@dog.com", "lazy dog@dog.com"
		}, result);
	}

}
