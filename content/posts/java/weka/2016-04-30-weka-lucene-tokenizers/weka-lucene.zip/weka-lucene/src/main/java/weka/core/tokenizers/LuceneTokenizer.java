package weka.core.tokenizers;

import java.lang.Math;
import java.io.IOException;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Vector;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.shingle.ShingleFilter;
import org.apache.lucene.analysis.standard.UAX29URLEmailTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;

import weka.core.Option;
import weka.core.RevisionUtils;
import weka.core.Utils;

public class LuceneTokenizer extends Tokenizer {

	private transient TokenStream m_stream;

	/** the maximum number of N */
	private int m_NMax = 3;

	/** the minimum number of N */
	private int m_NMin = 1;

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1.0 $");
	}

	/**
	 * Returns a string describing the tokenizer
	 * 
	 * @return a description suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	@Override
	public String globalInfo() {
		return "Tokenizer based on Apache Lucene UAX29URLEmailTokenizer & ShingleFilter.";
	}

	/**
	 * Returns true if there's more elements available
	 * 
	 * @return true if there are more elements available
	 */
	@Override
	public boolean hasMoreElements() {
		try {
			if (m_stream.incrementToken()) {
				return true;
			} else {
				m_stream.end();
				m_stream.close();
				return false;
			}
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Returns N-grams and also (N-1)-grams and .... and 1-grams.
	 * 
	 * @return the next element
	 */
	@Override
	public String nextElement() {
		final CharSequence o = m_stream.getAttribute(CharTermAttribute.class);
		return o.toString();
	}

	/**
	 * Sets the string to tokenize.
	 * 
	 * @param s
	 *            the string to tokenize
	 */
	@Override
	public void tokenize(final String s) {
		final UAX29URLEmailTokenizer t = new UAX29URLEmailTokenizer();
		t.setReader(new StringReader(s));
		if (m_NMax > 1) {
			final ShingleFilter f = new ShingleFilter(t, m_NMax);
			if (m_NMin > 1) {
				f.setMinShingleSize(m_NMin);
				f.setOutputUnigrams(false);
			}
			m_stream = f;
		} else {
			m_stream = t;
		}

		try {
			m_stream.reset();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Returns an enumeration of all the available options..
	 * 
	 * @return an enumeration of all available options.
	 */

	@Override
	public Enumeration<Option> listOptions() {
		final Vector<Option> result = new Vector<Option>();
		@SuppressWarnings("unchecked")
		final Enumeration<Option> enm = super.listOptions();

		while (enm.hasMoreElements()) {
			result.addElement(enm.nextElement());
		}

		result.addElement(
			new Option("\tThe max size of the Ngram (default = 3).", "max", 1, "-max <int>"));

		result.addElement(
			new Option("\tThe min size of the Ngram (default = 1).", "min", 1, "-min <int>"));

		return result.elements();
	}

	/**
	 * Gets the current option settings for the OptionHandler.
	 * 
	 * @return the list of current option settings as an array of strings
	 */
	@Override
	public String[] getOptions() {
		Vector<String> result;
		String[] options;
		int i;

		result = new Vector<String>();

		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		result.add("-max");
		result.add("" + getNGramMaxSize());

		result.add("-min");
		result.add("" + getNGramMinSize());

		return result.toArray(new String[result.size()]);
	}

	/**
	 * Parses a given list of options.
	 * 
	 * @param options
	 *            the list of options as an array of strings
	 * @throws Exception
	 *             if an option is not supported
	 */
	@Override
	public void setOptions(final String[] options) throws Exception {
		String value;

		super.setOptions(options);

		value = Utils.getOption("max", options);
		if (value.length() != 0) {
			setNGramMaxSize(Integer.parseInt(value));
		} else {
			setNGramMaxSize(3);
		}

		value = Utils.getOption("min", options);
		if (value.length() != 0) {
			setNGramMinSize(Integer.parseInt(value));
		} else {
			setNGramMinSize(1);
		}
	}

	/**
	 * Gets the max N of the NGram.
	 * 
	 * @return the size (N) of the NGram.
	 */
	public int getNGramMaxSize() {
		return m_NMax;
	}

	/**
	 * Sets the max size of the Ngram.
	 * 
	 * @param value
	 *            the size of the NGram.
	 */
	public void setNGramMaxSize(final int value) {
		m_NMax = Math.max(1, value);
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String NGramMaxSizeTipText() {
		return "The max N of the NGram.";
	}

	/**
	 * Sets the min size of the Ngram.
	 * 
	 * @param value
	 *            the size of the NGram.
	 */
	public void setNGramMinSize(final int value) {
		m_NMin = Math.max(1, value);
	}

	/**
	 * Gets the min N of the NGram.
	 * 
	 * @return the size (N) of the NGram.
	 */
	public int getNGramMinSize() {
		return m_NMin;
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String NGramMinSizeTipText() {
		return "The min N of the NGram.";
	}

	/**
	 * Runs the tokenizer with the given options and strings to tokenize. The
	 * tokens are printed to stdout.
	 * 
	 * @param args
	 *            the commandline options and strings to tokenize
	 */
	public static void main(final String[] args) {
		runTokenizer(new LuceneTokenizer(), args);
	}
}
