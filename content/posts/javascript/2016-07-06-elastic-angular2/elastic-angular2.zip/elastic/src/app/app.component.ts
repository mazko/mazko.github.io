import { Component } from '@angular/core';
import { FilmsSearchComponent } from './films-search';

@Component({
  moduleId: module.id,
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.css'],
  directives: [FilmsSearchComponent]
})
export class AppComponent {}
