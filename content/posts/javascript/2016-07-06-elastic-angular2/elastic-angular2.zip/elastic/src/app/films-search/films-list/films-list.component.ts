import { Component, Input } from '@angular/core';
import { IFilm } from '../elastic.service';
import { HiComponent } from '../hi';

@Component({
  moduleId: module.id,
  selector: 'films-list',
  templateUrl: 'films-list.component.html',
  styleUrls: ['films-list.component.css'],
  directives: [HiComponent]
})
export class FilmsListComponent {

  @Input() films: IFilm[];

}
