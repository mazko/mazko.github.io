// /* tslint:disable:no-unused-variable */

// import {
//   beforeEach, beforeEachProviders,
//   describe, xdescribe,
//   expect, it, xit,
//   async, inject
// } from '@angular/core/testing';

// import { MockBackend, MockConnection } from '@angular/http/testing';
// import { Http } from '@angular/http';
// import { provide } from '@angular/core';
// import { BaseRequestOptions, Response, ResponseOptions } from '@angular/http';

// import { ElasticService } from './elastic.service';

// describe('Elastic Service', () => {

//   beforeEachProviders(() => [
//     ElasticService,
//     BaseRequestOptions,
//     MockBackend,
//     provide(Http, {
//       useFactory: (backend: MockBackend, defaultOptions: BaseRequestOptions) => {
//         return new Http(backend, defaultOptions);
//       },
//       deps: [MockBackend, BaseRequestOptions]
//     })
//   ]);

//   beforeEach(inject([MockBackend], (backend: MockBackend) => {
//     const baseResponse = new Response(new ResponseOptions({
//       body: JSON.stringify({
//         hits: {
//           total : 42,
//           hits: [
//             { fields : { rate : [ 8.042 ], id : [ 409640 ] } },
//             { fields : { rate : [ 7.943 ], id : [ 153013 ] } }
//           ]
//         }
//       }) 
//     }));
//     backend.connections.subscribe((c: MockConnection) => c.mockRespond(baseResponse));
//   }));

//   it('should elastic search',
//     inject([ElasticService], (elk: ElasticService) => 
//       elk.search().then(chunk => {
//         expect(chunk.items.length).toBe(2);
//         expect(chunk.total).toBe(42);
//         expect(chunk.items[1].id).toEqual([153013]);
//       })
//     )
//   );
// });
