import { Injectable } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/toPromise';

// Elastic docs:
// Field values fetched from the document it self 
// are always returned as an array.
export interface IFilm {
  id: number[];
  name: string[];
  date: string[];
  description: string[];
  rate: number[];
  starring: string[];
  category: string[];
  directed: string[];
}

export interface IChunk<T> {
  items: T[];
  total: number;
}

export interface IAggs {
  directors: Array<{key:string; doc_count:number}>;
  categories: Array<{key:string; doc_count:number}>;
  stars: Array<{key:string; doc_count:number}>;
  years: Array<{key:number; doc_count:number; 
    months?:Array<{key:number; doc_count:number}>}>;
}

const ELASTIC_URL = '//localhost:9200/kinopoisk/';

interface ISearchKwargs {
  q?: string; from?: number; size?: number; fields?: string[];
  year?: number; month?: number;
  star?: string, director?: string, category?: string
}

@Injectable()
export class ElasticService {

  constructor(private _http : Http){}

  suggest(a:string, size:number=10) : Promise<string[]> {
    const params = new URLSearchParams();
    // Elastic docs: 
    // For libraries that don’t accept a request body 
    // for non-POST requests, you can pass the request 
    // body as the source query string parameter instead.
    params.set('source', JSON.stringify({
      "kino" : {
        "text" : a,
        "completion" : {
          "field" : "suggest",
          "size": size
        }
      }
    }));
    return this._http
      .get(ELASTIC_URL + '_suggest', { search: params })
      .toPromise()
      .then(response => {
        const opts = response.json().kino[0].options;
        return opts.map(opt => opt.text);
      });
  }

  search(kwargs? : ISearchKwargs) : Promise<{chunk:IChunk<IFilm>; aggs:IAggs}> {
    const kwargsDefs : ISearchKwargs = {
      from: 0, size: 5, fields: [ "name", "description" ]
    };
    kwargs = Object.assign(kwargsDefs, kwargs);

    const params = new URLSearchParams();
    // Elastic docs: 
    // For libraries that don’t accept a request body 
    // for non-POST requests, you can pass the request 
    // body as the source query string parameter instead.
    params.set('source', JSON.stringify({
      'from': kwargs.from,
      'size': kwargs.size,
      "fields" : [
        "id", "name", "date", 
        "description", "rate", 
        "starring", "category", "directed"],
      "query" : {
        "bool": {
          "must": [
            kwargs.q 
              ? { "query_string" : {
                    "query": kwargs.q,
                    "fields": kwargs.fields,
                    "default_operator": "and"
                  }
                } 
              : { "match_all": {} },
          ],
          "filter": [
            kwargs.year
              ? {
                "range" : {
                  "date" : {
                    "gte" : kwargs.month >= 0 ? kwargs.year + "-" + kwargs.month : kwargs.year,
                    "lt" : kwargs.year + (kwargs.month >= 0 ? "-" + kwargs.month + "||+1M" : "||+1y"),
                    "format": "yyyy-MM||yyyy"
                  }
                }
              }
              : null,
           kwargs.category 
             ? {
               "match": {
                 "category.raw": kwargs.category
               }
             } : null,
           kwargs.director 
             ? {
               "match": {
                 "directed.raw": kwargs.director
               }
             } : null,
           kwargs.star 
             ? {
               "match": {
                 "starring.raw": kwargs.star
               }
             } : null,
          ].filter(v => v !== null)
        }
      },
      "highlight" : {
        "pre_tags" : ["[mazko.github.io]"],
        "post_tags" : ["[/mazko.github.io]"],
        "fields" : kwargs.fields.reduce(
          (result, item) => {
            result[item] = {
              "fragment_size" : 333
            };
            return result;
          }, {})
      },
      "sort" : [
        {"rate" : {"order" : "desc"} }
       ],
      "aggs": {
        "years": {
          "date_histogram": {
            "field": "date",
            "interval": "year",
            "min_doc_count": 1,
            "order" : { "_count" : "desc" }
          },
          "aggs": {
            "months": {
              "date_histogram": {
                "field": "date",
                "interval": "month",
                "min_doc_count": 1,
                "order" : { "_count" : "desc" }
              }
            }
          }
        },
        "categories" : {
          "terms" : { "field" : "category.raw", "size": 1000 }
        },
        "directors" : {
          "terms" : { "field" : "directed.raw", "size": 1000 }
        },
        "stars" : {
          "terms" : { "field" : "starring.raw", "size": 1000 }
        }
      }
    }));
    return this._http
      .get(ELASTIC_URL + 'film/_search', { search: params })
      .toPromise()
      .then(response => {
        const { hits, aggregations } = response.json();
        const chunk : IChunk<IFilm> = {
          items: hits.hits.map(
            hit => Object.assign(hit.fields, hit.highlight)),
          total: hits.total
        };
        const aggs : IAggs = {
          directors: aggregations.directors.buckets,
          categories: aggregations.categories.buckets,
          stars: aggregations.stars.buckets,
          years: aggregations.years.buckets.map(y => {
            return {
              doc_count: y.doc_count, 
              key: new Date(y.key).getFullYear(),
              months: y.months.buckets.map(m => {
                return {
                  doc_count: m.doc_count, 
                  key: new Date(m.key).getMonth() + 1
                }
              })
            }
          })
        };
        return {chunk, aggs};
      });
  }
}
