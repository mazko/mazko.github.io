// /* tslint:disable:no-unused-variable */

// import { By }           from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import {
//   beforeEach, beforeEachProviders,
//   describe, xdescribe,
//   expect, it, xit,
//   async, inject
// } from '@angular/core/testing';

// import { AutoCompleteComponent } from './auto-complete.component';

// describe('Component: AutoComplete', () => {
//   it('should create an instance', () => {
//     let component = new AutoCompleteComponent();
//     expect(component).toBeTruthy();
//   });
// });
