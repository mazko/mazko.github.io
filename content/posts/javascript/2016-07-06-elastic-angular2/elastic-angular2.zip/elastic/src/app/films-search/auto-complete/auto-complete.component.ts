import { Component, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { Subject }        from 'rxjs/Subject';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import { ElasticService } from '../elastic.service';

@Component({
  moduleId: module.id,
  selector: 'auto-complete',
  host: {
    '(document:click)': 'handleClick($event)',
  },
  templateUrl: 'auto-complete.component.html',
  providers: [ElasticService],
  styleUrls: ['auto-complete.component.css']
})
export class AutoCompleteComponent  {

  @Output() q_change = new EventEmitter<string>();
  @ViewChild('menu') private menuRef;

  private searchTermStream = new Subject<string>();

  constructor(private _es : ElasticService) {
    this.searchTermStream
      .debounceTime(333)
      .distinctUntilChanged()
      .switchMap(q => q 
        ? this._es.suggest(q).catch(e => Promise.resolve([])) 
        : Promise.resolve([]))
      .subscribe(suggestions => {
         this.suggestions = suggestions;
      });
  }

  suggestions: string[];
  query: string;

  handleClear() {
    this.suggestions = [];
    this.searchTermStream.next('');
  }

  handleQuery() {
    this.q_change.emit(this.query);
  }

  handleKey(keyCode: number) {
    if ([27, 13].indexOf(keyCode) > -1) {
      this.handleClear();
    } else {
      this.searchTermStream.next(this.query);
    }
  }

  private isEventInsideElement(event:Event, child:ElementRef) : boolean {
    return child.nativeElement.contains(event.target);
  }

  handleClick(event:MouseEvent) {
    if (this.isEventInsideElement(event, this.menuRef)) {
      this.query = (<HTMLElement>event.target).dataset['val'];
      this.handleQuery();
    } 
    this.handleClear();
  }
}
