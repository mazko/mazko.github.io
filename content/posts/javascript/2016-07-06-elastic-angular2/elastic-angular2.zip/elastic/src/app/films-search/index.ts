export * from './films-search.component';
