// /* tslint:disable:no-unused-variable */

// import { provide } from '@angular/core';

// import {
//   beforeEach, beforeEachProviders,
//   describe, xdescribe,
//   expect, it, xit,
//   async, inject
// } from '@angular/core/testing';

// import { TestComponentBuilder } from '@angular/compiler/testing'

// import { FilmsSearchComponent } from './films-search.component';
// import { ElasticService } from './elastic.service';

// class MockElasticService {

//   search() {
//     return Promise.resolve({
//       items: [
//         { 
//           id: [409640],
//           name: ["Касл (сериал 2009 – ...)"],
//           rate: 8.042
//         },
//         { 
//           id: [153013],
//           name: ["Звездный крейсер Галактика (сериал 2004 – 2009)"],
//           rate: 7.943
//         }
//       ],
//       total: 42
//     });
//   }
// }

// describe('Component: FilmsSearch', () => {
//   let tcb:TestComponentBuilder;
  
//   //setup
//   beforeEach(inject([TestComponentBuilder], _tcb => 
//     tcb = _tcb.overrideProviders(
//       FilmsSearchComponent,
//       [provide(ElasticService, { useClass: MockElasticService })]
//     )
//   ));

//   //specs
//   it('should render films', () =>
//     tcb.createAsync(FilmsSearchComponent)
//     .then(fixture => {
//       const element = fixture.nativeElement;
//       fixture.detectChanges();
//       expect(element.querySelectorAll('div').length).toBe(2);
//       expect(element.querySelector('div p a').innerText).toBe('8.042');
//     })
//   );

// });
