import { Component, OnInit } from '@angular/core';
import { ElasticService, IFilm, IAggs } from './elastic.service';
import { FilmsListComponent } from './films-list';
import { AutoCompleteComponent } from './auto-complete';
import { AggregationsComponent, IAggsFilter } from './aggregations';

@Component({
  moduleId: module.id,
  selector: 'films-search',
  templateUrl: 'films-search.component.html',
  styleUrls: ['films-search.component.css'],
  providers: [ElasticService],
  directives: [FilmsListComponent, AutoCompleteComponent, AggregationsComponent]
})
export class FilmsSearchComponent implements OnInit {

  films: IFilm[];
  films_per_page: number = 5;
  aggs: IAggs;
  total_pages: number;
  current_page: number;
  search_query: string;
  search_aggs: IAggsFilter;

  is_fetching_state: boolean;

  // this shorthand syntax automatically creates and
  // initializes a new private member in the class
  constructor(private _es : ElasticService){}

  private _search() {
    const from = (this.current_page - 1) * this.films_per_page;
    this.is_fetching_state = true;
    const filter = this.search_aggs || <IAggsFilter>{};
    this._es.search({
      q: this.search_query, 
      from, size: this.films_per_page,
      year: filter.year, month: filter.month,
      star: filter.star, category: filter.category, 
      director: filter.director
    }).then(({chunk, aggs}) => {
      this.is_fetching_state = false;
      this.films = chunk.items;
      this.total_pages = Math.ceil(chunk.total / this.films_per_page);
      this.aggs = aggs;
    }).catch(e => alert(e));
  }

  handlePerPage(value:string) {
    this.films_per_page = Number(value);
    this.handleQuery(this.search_query);
  }

  handleNextPage() {
    this.current_page += 1;
    this._search();
  }

  handlePrevPage() {
    this.current_page -= 1;
    this._search();
  }

  handleQuery(query? : string) {
    this.search_query = query;
    this.current_page = 1;
    this._search();
  }

  ngOnInit() {
    this.handleQuery();
  }

  handleAggs(filter : IAggsFilter) {
    this.search_aggs = filter;
    this.handleQuery(this.search_query);
  }
}