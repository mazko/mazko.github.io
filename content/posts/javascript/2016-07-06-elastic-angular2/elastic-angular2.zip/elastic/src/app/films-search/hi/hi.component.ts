import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'hi',
  templateUrl: 'hi.component.html',
  styleUrls: ['hi.component.css']
})
export class HiComponent implements AfterViewInit {

  @Input() content: string;

  @ViewChild('hi') hi;

  ngAfterViewInit() {
    // https://angular.io/docs/ts/latest/guide/cheatsheet.html
    // hi is set
    const hi = this.hi.nativeElement;
    hi.innerHTML = hi.innerHTML.replace(
        /\[mazko\.github\.io\](.*?)\[\/mazko\.github\.io\]/g, 
        "<b style=\"color:red;\">$1</b>");
  }

}
