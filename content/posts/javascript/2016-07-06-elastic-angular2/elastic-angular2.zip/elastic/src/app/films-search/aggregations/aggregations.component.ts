import { Component, Output, EventEmitter, Input } from '@angular/core';
import { IAggs } from '../elastic.service';

export class IAggsFilter {
  year: number;
  month: number;
  star: string;
  category: string;
  director: string;
}

@Component({
  moduleId: module.id,
  selector: 'aggregations',
  templateUrl: 'aggregations.component.html',
  styleUrls: ['aggregations.component.css']
})
export class AggregationsComponent {

  @Output() aggs_change = new EventEmitter<IAggsFilter>();

  @Input() set data(aggs : IAggs) {
    if (!aggs) return;
    // Flatten array easier to work in Angular2
    // TODO: strong typing <reduce>
    aggs.years = aggs.years.reduce(
      (flat, toFlat) => [
        ...flat,
        { year: toFlat.key, doc_count: toFlat.doc_count },
        ...toFlat.months.map(m => {
          return {
            year: toFlat.key,
            month: m.key,
            doc_count: m.doc_count
          }
        })
      ], []);

    if (this.search_star && aggs.stars.length === 0) {
      aggs.stars = [{key: this.search_star, doc_count: 0}];
    }
    if (this.search_category && aggs.categories.length === 0) {
      aggs.categories = [{key: this.search_category, doc_count: 0}];
    }
    if (this.search_director && aggs.directors.length === 0) {
      aggs.directors = [{key: this.search_director, doc_count: 0}];
    }
    // TODO: strong typing <any>
    if (this.search_month && aggs.years.length === 0) {
      aggs.years = [
        <any>{year: this.search_year, doc_count: 0},
        <any>{year: this.search_year, month: this.search_month, doc_count: 0}
      ];
    } else if (this.search_year && aggs.years.length === 0) {
      aggs.years = [<any>{year: this.search_year, doc_count: 0}];
    }

    this.aggs = aggs;
   }

  aggs:IAggs;

  search_year: number;
  search_month: number;
  search_star: string;
  search_category: string;
  search_director: string;

  private _emit() {
    this.aggs_change.emit({
      year: this.search_year,
      month: this.search_month,
      star: this.search_star,
      category: this.search_category,
      director: this.search_director
    });
  }

  handleYM(index:string) {
    const idx = Number(index);
    if (idx >= 0) {
      this.search_year = this.aggs.years[idx]['year'];
      this.search_month = this.aggs.years[idx]['month'];
    } else {
      this.search_year = this.search_month = undefined;
    }
    this._emit();
  }

  handleStar(star:string) {
    this.search_star = star;
    this._emit();
  }

  handleDirector(dir:string) {
    this.search_director= dir;
    this._emit();
  }

  handleCaterory(cat:string) {
    this.search_category = cat;
    this._emit();
  }
}
