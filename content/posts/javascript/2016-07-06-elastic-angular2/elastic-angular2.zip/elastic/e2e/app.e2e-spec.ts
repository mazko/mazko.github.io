import { ElasticPage } from './app.po';

describe('elastic App', function() {
  let page: ElasticPage;

  beforeEach(() => {
    page = new ElasticPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
