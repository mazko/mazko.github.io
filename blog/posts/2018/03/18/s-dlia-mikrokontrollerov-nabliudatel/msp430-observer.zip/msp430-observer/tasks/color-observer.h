#include "observers/buttons.h"

namespace tasks {

    template<class Leds, char R, char G, char B, char C>
    class ColorObserver : public obsevers::buttons::IObserver
    {
        Leds m_leds;

    public:

        void observe(char aButton) {
            switch (aButton) {
                case 1 << R:
                    m_leds.set_red();
                    break;
                case 1 << G:
                    m_leds.set_green();
                    break;
                case 1 << B:
                    m_leds.set_blue();
                    break;
                case 1 << C:
                    m_leds.clr();
                    break;
            }
        }
    };
}