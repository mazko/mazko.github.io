#include "right.h"
#include "color-observer.h"
#include "draw.h"
#include "hal.h"

using namespace obsevers;
using namespace tasks;

static ColorObserver<hal::RightLeds, 6, 5, 4, 7> observer;

namespace tasks {

    namespace right {

        void start() {
            draw::str(draw::PAGE_2, "right subscribed");
            buttons::event.addObserver(&observer);
        }

    }

}