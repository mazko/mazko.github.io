#include "DoublyLinkedList.h"
#include "non-copyable.h"

namespace obsevers {

    // alias
    template<class T> using DLLE = mozilla::DoublyLinkedListElement<T>;

    namespace buttons {

        struct IObserver : public DLLE<IObserver>, NonCopyable
        {
            virtual void observe(char) = 0;
        };


        class Container : NonCopyable
        {
            mozilla::DoublyLinkedList<IObserver> mList;

        public:
            void addObserver(IObserver* aObserver)
            {
                // Will assert if |aObserver| is part of another list.
                mList.pushFront(aObserver);
            }

            void removeObserver(IObserver* aObserver)
            {
                // Will assert if |aObserver| is not part of |list|.
                mList.remove(aObserver);
            }

            void notifyObservers(char aButton)
            {
                for (IObserver& o : mList) {
                    o.observe(aButton);
                }
            }
        };

        extern Container event;

    }
  
}