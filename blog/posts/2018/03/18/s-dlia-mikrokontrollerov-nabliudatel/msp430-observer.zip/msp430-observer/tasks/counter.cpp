#include "counter.h"
#include "color-observer.h"
#include "draw.h"

using namespace obsevers;

class CountObserver : public buttons::IObserver
{
    uint16_t m_c;

    void observe(char aButton) {
        draw::str_hex(draw::PAGE_4, "total clicks:", ++m_c);
    }
};

static CountObserver observer;

namespace tasks {

    namespace counter {

        void start() {
          draw::str(draw::PAGE_2, "right subscribed");
          buttons::event.addObserver(&observer);
        }

    }

}