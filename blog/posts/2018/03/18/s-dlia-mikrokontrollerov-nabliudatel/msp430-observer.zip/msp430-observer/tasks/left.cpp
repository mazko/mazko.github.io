#include "left.h"
#include "color-observer.h"
#include "observers/state.h"
#include "draw.h"
#include "hal.h"

using namespace obsevers;
using namespace tasks;

class LockerObserver : public state::IObserver {

    ColorObserver<hal::LeftLeds, 1, 2, 3, 0> o;

    void observe(state::state_t aState) {
        switch (aState) {
            case state::left_active:
                str("left subscribed  ");
                buttons::event.addObserver(&o);
                break;
            case state::left_sleep:
                str("left unsubscribed");
                buttons::event.removeObserver(&o);
                break;
        }
    }

    public: 
        void str(const char* str) {
          draw::str(draw::PAGE_0, str);
        }
};

static LockerObserver observer;

namespace tasks {

    namespace left {

        void start() {
            observer.str("left unsubscribed");
            state::event.addObserver(&observer);
        }

    }

}