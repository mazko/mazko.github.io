#include "TypeTraits.h"

void assert_called(char const *module, int loc);

#define DEBUG

#ifdef DEBUG
#  define MOZ_ASSERT(x, ...) if( ( x ) == 0 ) assert_called( __FILE__,  __LINE__)
#else
#  define MOZ_ASSERT(...) do { } while (0)
#endif /* DEBUG */