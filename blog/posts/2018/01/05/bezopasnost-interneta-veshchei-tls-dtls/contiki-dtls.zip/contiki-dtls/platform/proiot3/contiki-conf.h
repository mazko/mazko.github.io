#ifndef CONTIKI_CONF_H_
#define CONTIKI_CONF_H_

#include <inttypes.h>
#include <limits.h>

#include "platform-conf.h"

#define CCIF
#define CLIF

#define UIP_CONF_BUFFER_SIZE   1500

/* These names are deprecated, use C99 names. */
typedef uint8_t   u8_t;
typedef uint16_t u16_t;
typedef uint32_t u32_t;
typedef  int32_t s32_t;

typedef unsigned short uip_stats_t;

#if UIP_CONF_IPV6_RPL
#define UIP_CONF_ROUTER                 0
#define UIP_CONF_ND6_SEND_RA            0
#define UIP_CONF_ND6_REACHABLE_TIME     600000
#define UIP_CONF_ND6_RETRANS_TIMER      10000

#if RPL_BORDER_ROUTER
#error RPL_BORDER_ROUTER not impl
#endif

#endif /* UIP_CONF_IPV6_RPL */

#define UIP_CONF_LLH_LEN              14
#define UIP_CONF_MAX_CONNECTIONS      4
#define UIP_CONF_MAX_LISTENPORTS      8
#define UIP_CONF_BYTE_ORDER           UIP_LITTLE_ENDIAN
#define UIP_CONF_TCP_SPLIT            0
#define UIP_CONF_IP_FORWARD           0
#define UIP_CONF_LOGGING              0
#define UIP_CONF_UDP_CHECKSUMS        1

#if NETSTACK_CONF_WITH_IPV6
#define UIP_CONF_IPV6_QUEUE_PKT       0
#define UIP_CONF_IPV6_CHECKS          1
#endif /* NETSTACK_CONF_WITH_IPV6 */

typedef unsigned long clock_time_t;
#define INFINITE_TIME ULONG_MAX

#endif /* CONTIKI_CONF_H_ */
