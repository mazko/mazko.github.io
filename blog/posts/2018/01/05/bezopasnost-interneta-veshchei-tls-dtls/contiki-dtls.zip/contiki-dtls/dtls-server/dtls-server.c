#include "contiki-net.h"
#include "leds.h"
#include "draw.h"
#include "dtls.h"
#include "dtls-echo.h"

#include <stdio.h> // printf

PROCESS(boot_process, "Boot");
PROCESS_NAME(display_process);
/*---------------------------------------------------------------------------*/
AUTOSTART_PROCESSES(
  &boot_process,
  &display_process);
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(boot_process, ev, data)
{
  PROCESS_BEGIN();

  dtls_init();

  process_start(&dtls_echo_server_process, NULL);

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/