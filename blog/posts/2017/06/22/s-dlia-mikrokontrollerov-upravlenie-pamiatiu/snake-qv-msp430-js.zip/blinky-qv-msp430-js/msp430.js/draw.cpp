#include "draw.h"
#include "ssd1306.h"
#include "qpcpp.h"  // Q_ASSERT_COMPILE
#include <bitset>
#include "estd/vector.h"

using namespace std; // memmove

Q_DEFINE_THIS_FILE


void
esrlabs::estd::assert_func(const char *file, int line, const char *test)
{
    Q_onAssert(test, line);
}


namespace draw {

    namespace grid {
        enum /* constexpr */ { CX_MAX = (128 / 4) - 1, CY_MAX = (64 / 4) - 1,
                MAX_SZ = (CX_MAX + 1) * (CY_MAX + 1) };

        // one-dimensional array
        static std::bitset<MAX_SZ> frame_buffer;

        // convert a multi-dimensional array to a one-dimensional array
        static uint16_t xy_to_id(const uint8_t cx, const uint8_t cy) {
            Q_ASSERT( cx <= CX_MAX );
            Q_ASSERT( cy <= CY_MAX );

            const uint16_t id = cx + (cy * (CX_MAX + 1));

            Q_ASSERT( id < MAX_SZ );

            return id;
        }


        static bool occupied(const uint8_t cx, const uint8_t cy) {
            return frame_buffer.test(xy_to_id(cx, cy));
        }


        static uint8_t id_to_x(const uint16_t id) {
            Q_ASSERT( id < MAX_SZ );
            const uint8_t x = id % (CX_MAX + 1);
            Q_ASSERT( x <= CX_MAX );
            return x;
        }


        static uint8_t id_to_y(const uint16_t id) {
            Q_ASSERT( id < MAX_SZ );
            const uint8_t y = id / (CX_MAX + 1);
            Q_ASSERT( y <= CY_MAX );
            return y;
        }


        static void brick(const uint8_t cx, const uint8_t cy) {

            frame_buffer.set(xy_to_id(cx, cy));

            const bool pair = occupied(cx, cy % 2 ? cy - 1 : cy + 1);
            const uint8_t byte = pair ? 0xFF : cy % 2 ? 0xF0 : 0xF;

            ssd1306::write_byte(4*cx, cy/2, byte);
            for (uint8_t i = 1; i < 4; i++ ) {
                ssd1306::write_data(byte);
            }
        }


        static void clr(const uint8_t cx, const uint8_t cy) {

            frame_buffer.reset(xy_to_id(cx, cy));

            const bool pair = occupied(cx, cy % 2 ? cy - 1 : cy + 1);
            const uint8_t byte = pair ? cy % 2 ? 0xF : 0xF0 : 0;

            ssd1306::write_byte(4*cx, cy/2, byte);
            for (uint8_t i = 1; i < 4; i++ ) {
                ssd1306::write_data(byte);
            }
        }
    }


    // TODO: this implementation is very slow
    uint16_t Food::random() {
        uint16_t rnd_ids [grid::MAX_SZ], j = 0;
        for (uint16_t i = 0; i < grid::MAX_SZ; i++) {
            if (!grid::frame_buffer.test(i)) {
                rnd_ids[j++] = i;
            }
        }
        Q_ASSERT(j);
        Q_ASSERT(j == grid::frame_buffer.size() - grid::frame_buffer.count());

        const uint16_t idx = rand() % j;
        Q_ASSERT(idx < j);

        return rnd_ids[idx];
    }


    Food::Food(const uint16_t id): x(grid::id_to_x(id)), y(grid::id_to_y(id)) {
        grid::brick(x, y);
    }


    static struct Pimpl {
        // snake body
        esrlabs::estd::declare::vector<uint16_t, grid::MAX_SZ> body;
    } __snake_pimpl_pool[1];


    Snake::Snake() {

        // TODO: non reentrant snake (1 instance)

        _pimpl = &__snake_pimpl_pool[0];
        _pimpl->body.clear();
        grid::frame_buffer.reset();

        // snake always has head (first element in container) and tail (last)

        _pimpl->body.push_back(grid::xy_to_id(grid::CX_MAX, 0));
        _pimpl->body.push_back(grid::xy_to_id(0, 0));
    }


    void Snake::set_direction(const int8_t dx, const int8_t dy) {
        Q_ASSERT( dx == 1 || dx == -1 || dx == 0 );
        Q_ASSERT( dy == 1 || dy == -1 || dy == 0 );

        _direction.dx = dx;
        _direction.dy = dy;
    }


    uint16_t Snake::get_next_id() const {
        const int8_t dx = _direction.dx, dy = _direction.dy;

        const uint16_t head_id = _pimpl->body[0];
        const uint8_t head_x = grid::id_to_x(head_id),
                      head_y = grid::id_to_y(head_id);

        const uint8_t next_x = dx > 0 && head_x == grid::CX_MAX ? 0
                             : dx < 0 && head_x == 0 ? grid::CX_MAX : head_x + dx,
                      next_y = dy > 0 && head_y == grid::CY_MAX ? 0
                             : dy < 0 && head_y == 0 ? grid::CY_MAX : head_y + dy;

        return grid::xy_to_id(next_x, next_y);
    }


    bool Snake::can_eat(const int8_t x, const int8_t y) const {
        Q_ASSERT( x <= grid::CX_MAX );
        Q_ASSERT( y <= grid::CY_MAX );
        const uint16_t next_id = get_next_id();
        return grid::id_to_x(next_id) == x && grid::id_to_y(next_id) == y;
    }


    void Snake::eat() {
        const uint16_t next_id = get_next_id();

        _pimpl->body.insert(_pimpl->body.begin(), next_id);

        grid::brick(grid::id_to_x(next_id), grid::id_to_y(next_id));
    }


    bool Snake::move() {

        const int8_t dx = _direction.dx, dy = _direction.dy;

        // pop tail

        const uint16_t tail_id = _pimpl->body.back();
        _pimpl->body.pop_back();
        const uint8_t tail_x = grid::id_to_x(tail_id),
                      tail_y = grid::id_to_y(tail_id);

        grid::clr(tail_x, tail_y);

        // push head

        eat();

        const uint16_t head_id = _pimpl->body[0];

        // check body collision
        // the head of the snake bumps into its body
        return std::find(_pimpl->body.begin() + 1, _pimpl->body.end(), head_id ) == _pimpl->body.end();
    }


    void character(const uint8_t x, const uint8_t page, const char c) {
        #include "font.cpp"
        Q_ASSERT_COMPILE(sizeof(font) == 256 * 5 /* uint8_t values 0..255 == 256 */);
        for (uint8_t i = 0; i < 5; i++ ) {
          ssd1306::write_byte(x + i, page, *(font+(c*5)+i));
        }
    }


    void str(uint8_t x, uint8_t page, const char* s) {
        while (s && *s) {
            character(x, page, *s++);
            x += 6;     // 6 pixels wide
            if (x + 6 >= SSD1306_X_PIXELS) {
              x = 0;    // ran out of this page
              page++;
            }
            if (page >= SSD1306_PIXEL_PAGES)
              break;    // ran out of space :(
         }
    }


    // http://stackoverflow.com/a/33447587

    template <typename I, size_t hex_len = (sizeof(I)<<1)> const char* n2hexstr(I w) {
        static char rc[1 + hex_len]; // non-reentrant
        for (size_t i=0, j=(hex_len-1)*4 ; i<hex_len; ++i,j-=4)
            rc[i] = "0123456789ABCDEF"[(w>>j) & 0x0f];
        rc[ hex_len ] = '\0';
        return rc;
    }


    void str_hex(const uint8_t p, const char* const m, const uint16_t v) {
      str(1, p,  m);
      str(1 + (6 * 15), p,  "0x");
      str(1 + (6 * 17), p,  n2hexstr(v));
    }

    void clr() {
        ssd1306::clear_screen();
    }


    void init() {
        ssd1306::init_display();
    }

}
