/*

reset && (export GCC_DIR=~/ti/msp430_gcc ; 
    $GCC_DIR/bin/msp430-elf-gcc \
    -I $GCC_DIR/include -L $GCC_DIR/include \
    -Werror -Wall -mmcu=msp430f1611 -O2 blink.c ssd1306.c)

*/


#include <msp430.h>
#include <stdint.h>


#include "ssd1306.h"
#include "font.c"


#define STATIC_ASSERT(cond) typedef int foo[(cond) ? 1 : -1]
STATIC_ASSERT(sizeof(font) == 256 * 5 /* uint8_t values 0..255 == 256 */);
#undef STATIC_ASSERT


static void drawchar(const uint8_t x, const uint8_t page, const uint8_t c) {
  for (uint8_t i = 0; i < 5; i++ ) {
    ssd1306_write_byte(x + i, page, *(font+(c*5)+i));
  }
}


static void drawstr(uint8_t x, uint8_t page, const char *s) {
  while (s && *s) {
    drawchar(x, page, *s++);
    x += 6; // 6 pixels wide
    if (x + 6 >= SSD1306_X_PIXELS) {
      x = 0;    // ran out of this page
      page++;
    }
    if (page >= SSD1306_PIXEL_PAGES)
      break;        // ran out of space :(
  }
}


int main(void) {
    WDTCTL = WDTPW | WDTHOLD;     // Stop watchdog timer

    // DCO = 3, RSEL = 0, f = 0.13 MHz
    DCOCTL = /* DCO2 + */ DCO1 + DCO0; 
    BCSCTL1 = XT2OFF /* + RSEL1 + RSEL0 + RSEL2 */;

    P2OUT = 0; P3OUT = 0;
    P2DIR = P3DIR = 0xFF;

    ssd1306_init_display();

    for(;;) {

      ssd1306_reset_cursor ();

      drawstr(0, 0, "!\"#$%&'()*+,-./0123456789:;<=>?@"
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`"
                    "abcdefghijklmnopqrstuvwxyz{|}~");
    }

    return 0;
}