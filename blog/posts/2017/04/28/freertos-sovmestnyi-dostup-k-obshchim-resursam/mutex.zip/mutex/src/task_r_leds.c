#include <msp430.h>


#include <FreeRTOS.h>
#include <task.h>

#include "task_r_leds.h"
#include "task_l_leds.h" // xP4P5P6Mutex
#include "task_stat.h"


static void safe_or(const uint8_t p3mask, volatile uint8_t * const port) {
    xSemaphoreTake( xP3Mutex, portMAX_DELAY );
    P3OUT |= p3mask;
    xSemaphoreGive( xP3Mutex );

    xSemaphoreTake( xP4P5P6Mutex, portMAX_DELAY );
    *port |= ~0b11111;
    xSemaphoreGive( xP4P5P6Mutex );
}


void vTaskLedsR( void *pvParameters ) {
  for( ;; ) {
    safe_or(0b100100, &P4OUT);    // +red
    vTaskDelay(10 /* ticks */);
    safe_or(0b1001000, &P5OUT);   // +green
    vTaskDelay(10 /* ticks */);
    safe_or(0b10010000, &P6OUT);  // +blue
    vTaskDelay(10 /* ticks */);

    // off
    xSemaphoreTake( xP3Mutex, portMAX_DELAY );
    P3OUT &= 0b11;  // don't touch LCD pins 0b11            
    xSemaphoreGive( xP3Mutex );

    xSemaphoreTake( xP4P5P6Mutex, portMAX_DELAY );
    P6OUT &= 0b11111; P5OUT &= 0b11111; P4OUT &= 0b11111; 
    xSemaphoreGive( xP4P5P6Mutex );

    vTaskDelay(10 /* ticks */);
  }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}