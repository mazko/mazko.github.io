#include <FreeRTOS.h>
#include <task.h>

#include "draw.h"

#include "task_stat.h"


volatile xSemaphoreHandle xP3Mutex;


static void safe_draw(const uint8_t p, const char* const m, const uint16_t v) {
    /* Attempt to take the mutex, blocking indefinitely to wait for the mutex */
    xSemaphoreTake( xP3Mutex, portMAX_DELAY );

    draw_str_hex(p, m, v);

    /* The mutex MUST be given back! */
    xSemaphoreGive( xP3Mutex );
}

void vTaskStat( void *pvParameters ) {

    // once
    for (uint8_t i = 0; i < (128 / 6); i++) {
      xSemaphoreTake( xP3Mutex, portMAX_DELAY );
      draw_char(1 + (i * 6) , 3, '-');
      xSemaphoreGive( xP3Mutex );
    }

    safe_draw(4, "portBASE_TYPE", sizeof(portBASE_TYPE));
    safe_draw(5, "portTickType", sizeof(portTickType));
    safe_draw(6, "tick rate (Hz)", configTICK_RATE_HZ);

    // loop
    for( ;; ) {
      safe_draw(0, "uptime", xTaskGetTickCount());
      safe_draw(1, "freeHeapSize", xPortGetFreeHeapSize());
      safe_draw(2, "numberOfTasks", uxTaskGetNumberOfTasks());
    }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}
