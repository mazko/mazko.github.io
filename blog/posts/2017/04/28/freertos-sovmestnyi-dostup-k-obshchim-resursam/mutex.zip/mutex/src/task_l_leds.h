void vTaskLedsL( void *pvParameters );

#include <FreeRTOS.h>
#include <semphr.h>

extern volatile xSemaphoreHandle xP4P5P6Mutex;