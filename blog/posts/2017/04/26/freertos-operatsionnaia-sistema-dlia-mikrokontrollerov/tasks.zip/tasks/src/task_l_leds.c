#include <FreeRTOS.h>
#include <task.h>

#include "task_l_leds.h"


static void rotate_rgb(volatile unsigned char * const port) {
    *port = 0b10000;
    do {
        vTaskDelay(5 /* ticks */);
        *port >>= 1;
    } while (*port);
}


void vTaskLedsL( void *pvParameters ) {
   for( ;; ) {
     vTaskDelay(42 /* ticks */);
     rotate_rgb(&P4OUT);
     rotate_rgb(&P5OUT);
     rotate_rgb(&P6OUT);
   }

  /* Should the task implementation ever break out of the above loop, then the task
    must be deleted before reaching the end of its implementing function. The NULL
    parameter passed to the vTaskDelete() API function indicates that the task to be
    deleted is the calling (this) task. */

   vTaskDelete( NULL );
}