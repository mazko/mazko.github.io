#include "contiki-net.h"
#include "er-coap-engine.h"


#define DEBUG 1
#if DEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#define PRINT6ADDR(addr) PRINTF("[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]", ((uint8_t *)addr)[0], ((uint8_t *)addr)[1], ((uint8_t *)addr)[2], ((uint8_t *)addr)[3], ((uint8_t *)addr)[4], ((uint8_t *)addr)[5], ((uint8_t *)addr)[6], ((uint8_t *)addr)[7], ((uint8_t *)addr)[8], ((uint8_t *)addr)[9], ((uint8_t *)addr)[10], ((uint8_t *)addr)[11], ((uint8_t *)addr)[12], ((uint8_t *)addr)[13], ((uint8_t *)addr)[14], ((uint8_t *)addr)[15])
#define PRINTLLADDR(lladdr) PRINTF("[%02x:%02x:%02x:%02x:%02x:%02x]", (lladdr)->addr[0], (lladdr)->addr[1], (lladdr)->addr[2], (lladdr)->addr[3], (lladdr)->addr[4], (lladdr)->addr[5])
#else
#define PRINTF(...)
#define PRINT6ADDR(addr)
#define PRINTLLADDR(addr)
#endif

static char btn_last_value;

PROCESS(er_example_client, "Erbium Example Client");
PROCESS_NAME(display_process);

// proiot 

static void btn_scan_init() {
  // clear the interrupt flag
  P1IFG = 0;
  // enable interrupt on BIT 0..7
  P1IE  = 0xFF;
}

static char btn_get_value() {
  char value = btn_last_value;
  btn_last_value = 0;
  return value;
}

interrupt(PORT1_VECTOR) btn_isr(void) {
  P1IFG = 0;  // clear the interrupt flag

  btn_last_value = P1IN;

  // https://github.com/contiki-os/contiki/wiki/Processes#polling
  // Polling is the way to make a process run from an interrupt. 
  // The process_poll() function is the only function in the process 
  // module that is safe to call from preemptive mode.

  process_poll(&er_example_client);
}


/*---------------------------------------------------------------------------*/
static uip_ipaddr_t server_ipaddr;

/* Example URIs that can be queried. */
#define NUMBER_OF_URLS 3
/* leading and ending slashes only for demo purposes, get cropped automatically when setting the Uri-Path */
char *service_urls[NUMBER_OF_URLS] =
{ ".well-known/core", "/actuators/toggle" };

#define SERVER_NODE(ipaddr)   uip_ip6addr(ipaddr, 0xfe80, 0, 0, 0, 0x200, 0xe2ff, 0xfe58, 0xb66b)

#define REMOTE_PORT     UIP_HTONS(COAP_DEFAULT_PORT)

#define TOGGLE_INTERVAL 10

/*---------------------------------------------------------------------------*/

/* This function is will be passed to COAP_BLOCKING_REQUEST() to handle responses. */
void
client_chunk_handler(void *response)
{
  const uint8_t *chunk;

  int len = coap_get_payload(response, &chunk);

  printf("|%.*s", len, (char *)chunk);
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(er_example_client, ev, data)
{
  PROCESS_BEGIN();

  static coap_packet_t request[1];      /* This way the packet can be treated as pointer as usual. */

  SERVER_NODE(&server_ipaddr);

  /* receives all CoAP messages */
  coap_init_engine();

  btn_scan_init();

  while(1) {
    PROCESS_YIELD();

    if(ev == PROCESS_EVENT_POLL) {
      /* send a request to notify the end of the process */

      /* prepare request, TID is set by COAP_BLOCKING_REQUEST() */
      coap_init_message(request, COAP_TYPE_CON, COAP_PUT, 0);
      coap_set_header_uri_path(request, "/actuators/leds" );

      char button_value = btn_get_value();
      switch ((unsigned char)button_value) {
        case 1 << 0:
        case 1 << 1: {
          coap_set_header_uri_query(request, "?color=r");
          const char msg[] = "mode=on";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        case 1 << 2: {
          coap_set_header_uri_query(request, "?color=g");
          const char msg[] = "mode=on";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        case 1 << 3: {
          coap_set_header_uri_query(request, "?color=b");
          const char msg[] = "mode=on";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        case 1 << 4: {
          coap_set_header_uri_query(request, "?color=b");
          const char msg[] = "mode=off";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        case 1 << 5: {
          coap_set_header_uri_query(request, "?color=g");
          const char msg[] = "mode=off";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        case 1 << 7:
        case 1 << 6: {
          coap_set_header_uri_query(request, "?color=r");
          const char msg[] = "mode=off";
          coap_set_payload(request, (uint8_t *)msg, sizeof(msg) - 1);
          break;
        }
        default:
          PRINTF("button ? %u", button_value);
          continue;
      }

      PRINT6ADDR(&server_ipaddr);
      PRINTF(" : %u\n", UIP_HTONS(REMOTE_PORT));

      COAP_BLOCKING_REQUEST(&server_ipaddr, REMOTE_PORT, request,
                            client_chunk_handler);

      PRINTF("\n--Done--\n");

    }
  }

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
AUTOSTART_PROCESSES(
  &er_example_client,
  &display_process);