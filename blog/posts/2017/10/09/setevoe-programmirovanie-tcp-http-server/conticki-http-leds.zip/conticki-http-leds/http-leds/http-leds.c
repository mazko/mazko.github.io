#include "contiki-net.h"
#include "httpd-simple.h"
#include "led.h"

#include <stdio.h> // printf

PROCESS_NAME(display_process);
PROCESS_NAME(dhcp_client_process);

PROCESS(webserver_nogui_process, "Web server");
PROCESS_THREAD(webserver_nogui_process, ev, data)
{
  PROCESS_BEGIN();

// --------------- see minimal-net -------------------
#if NETSTACK_CONF_WITH_IPV6
#if UIP_CONF_IPV6_RPL
#error UIP_CONF_IPV6_RPL see minimal-net
#else
  {
    uip_ipaddr_t ipaddr;
    uip_ip6addr(&ipaddr, 0xabcd, 0, 0, 0, 0, 0, 0, 0);
#if UIP_CONF_ROUTER
      if(!uip_ds6_prefix_add(&ipaddr, UIP_DEFAULT_PREFIX_LEN, 0, 0, 0, 0)) {
        printf("uip_ds6_prefix_add() failed.\n");
      }
#else /* UIP_CONF_ROUTER */
      #error UIP_CONF_ROUTER see minimal-net
#endif /* UIP_CONF_ROUTER */

    uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
    uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);
  }
#endif /* !UIP_CONF_IPV6_RPL */

#endif /* !NETSTACK_CONF_WITH_IPV6 */
// -------------- see minimal-net end ------------------

  httpd_init();

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(ev == tcpip_event);
    httpd_appcall(data);
  }

  PROCESS_END();
}
AUTOSTART_PROCESSES(
  &webserver_nogui_process,
#if NETSTACK_CONF_WITH_IPV4
  &dhcp_client_process,
#endif
  &display_process);
/*---------------------------------------------------------------------------*/
static
PT_THREAD(generate_leds_html(struct httpd_state *s))
{
  PSOCK_BEGIN(&s->sout);

  SEND_STRING(&s->sout, "<html><head><title>Contiki RGB</title></head><body>\n");

  if (strncmp(s->filename, "/r", 2) == 0) {
    led_toggle_red();
  } else if (strncmp(s->filename, "/g", 2) == 0) {
    led_toggle_green();
  } else if (strncmp(s->filename, "/b", 2) == 0) {
    led_toggle_blue();
  }

  SEND_STRING(&s->sout, "<p style='color:red;'>Red is <a href='/r'>");
  if (led_status_red()) {
    SEND_STRING(&s->sout, "ON");
  } else {
    SEND_STRING(&s->sout, "OFF");
  }
  SEND_STRING(&s->sout, "</a></p>\n");

  SEND_STRING(&s->sout, "<p style='color:green;'>Green is <a href='/g'>");
  if (led_status_green()) {
    SEND_STRING(&s->sout, "ON");
  } else {
    SEND_STRING(&s->sout, "OFF");
  }
  SEND_STRING(&s->sout, "</a></p>\n");

  SEND_STRING(&s->sout, "<p style='color:blue;'>Blue is <a href='/b'>");
  if (led_status_blue()) {
    SEND_STRING(&s->sout, "ON");
  } else {
    SEND_STRING(&s->sout, "OFF");
  }
  SEND_STRING(&s->sout, "</a></p>\n");

  SEND_STRING(&s->sout, "</body></html>\n");

  PSOCK_END(&s->sout);
}
/*---------------------------------------------------------------------------*/
httpd_simple_script_t
httpd_simple_get_script(const char *name)
{
  printf("script for: %s\n", name);
  return generate_leds_html;
}