#ifndef __LED_TOGGLE_H__
#define __LED_TOGGLE_H__

void led_toggle_red();
void led_toggle_green();
void led_toggle_blue();

char led_status_red();
char led_status_green();
char led_status_blue();

#endif
