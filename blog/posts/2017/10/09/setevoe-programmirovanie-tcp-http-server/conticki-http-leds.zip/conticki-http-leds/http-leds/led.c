#include "led.h"
#include <msp430.h>


void led_toggle_red() {
  P4OUT ^= 0xFF;
  P3OUT ^= (1 << 2) | (1 << 5);
}

char led_status_red() {
  return P4OUT;
}

void led_toggle_green() {
  P5OUT ^= 0xF0;
  P3OUT ^= (1 << 3) | (1 << 6);
}

char led_status_green() {
  return P5OUT & 0xF0;
}

void led_toggle_blue() {
  P6OUT ^= 0xFF;
  P3OUT ^= (1 << 4) | (1 << 7);
}

char led_status_blue() {
  return P6OUT;
}