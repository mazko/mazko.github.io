#ifndef __DHCP_CLIENT_APP_H__
#define __DHCP_CLIENT_APP_H__

#include "contiki.h"

CCIF extern process_event_t dhcp_client_event_updated;

#endif
