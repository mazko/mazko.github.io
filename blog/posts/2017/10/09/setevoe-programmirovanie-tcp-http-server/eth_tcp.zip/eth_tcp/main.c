#include "hal/bsp.h"
#include "hal/uart0.h"
#include "hal/draw.h"
#include "lan.h"

#include <stdio.h>
#include <string.h>

uint16_t tcp_data(eth_frame_t *frame, uint16_t len)
{
	ip_packet_t *ip = (void*)(frame->data);
	tcp_packet_t *tcp = (void*)(ip->data);
	char *data = (char*)tcp->data;

	draw_clr();
	data[len - 1] = 0;
	draw_str(1, 0, data);
	printf(">> %s\n", data);

	// piggyback
	const char* response = "!!! OK !!!\n";
	strcpy(data, response);
	return strlen(response);
}

int main(void)
{
	bsp_init();
	uart0_init();
	lan_init();
	draw_init();

	printf("Start polling...\n");
	while(1)
		lan_poll();

	return 0;
}