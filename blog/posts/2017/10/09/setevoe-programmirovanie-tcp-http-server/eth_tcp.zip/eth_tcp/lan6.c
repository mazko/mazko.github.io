#include "lan.h"
#include "hal/enc28j60.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STATIC_ASSERT(cond) typedef int foo[(cond) ? 1 : -1]

#define DEBUG 1
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

/*
 * BE conversion
 *
 * htons: host to network short 
 * ntohs: network to host short 
 * htonl: host to network long 
 * ntohl: network to host long 
 */

#define htons(a)			((((a)>>8)&0xff)|(((a)<<8)&0xff00))
#define ntohs(a)			htons(a)

#define htonl(a)			( (((a)>>24)&0xff) | (((a)>>8)&0xff00) | \
											(((a)<<8)&0xff0000) | (((a)<<24)&0xff000000) )
#define ntohl(a)			htonl(a)

/*
 * Ethernet
 */

#define ETH_TYPE_IP6	htons(0x86DD)

/** IPv6 version */
#define IPV6_VER htonl(0x60000000UL)

/** IPv6 version mask */
#define IPV6_MASK_VER htonl(0xf0000000UL)

/*
 * IP
 */

#define IP_PROTOCOL_TCP		6
#define IP_PROTOCOL_UDP		17
#define IP_PROTOCOL_ICMP6	58

/*
 * TCP
 */

#define TCP_FLAG_URG        0x20
#define TCP_FLAG_ACK        0x10
#define TCP_FLAG_PSH        0x08
#define TCP_FLAG_RST        0x04
#define TCP_FLAG_SYN        0x02
#define TCP_FLAG_FIN        0x01

#define TCP_WINDOW_SIZE     65535
#define TCP_SYN_MSS         448

/*
 * ICMP
 */

// https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol_version_6

#define ICMP_TYPE_NEIGHBOR_SOLICITATION   135
#define ICMP_TYPE_NEIGHBOR_ADVERTISEMENT  136

typedef struct icmp_packet {
	uint8_t type;
	uint8_t code;
	uint16_t cksum;
	uint32_t flags;
	uint8_t data[];
} icmp_packet_t;

static const uint8_t mac_addr[6] = { 2, 0, 0, 0, 0, 0x42 };

// https://stackoverflow.com/a/37316533
// http://www.sput.nl/cgi-bin/cgi-llmac
// 02:00:00:00:00:42 => fe80::0:0ff:fe00:42

static const union {
	uint8_t   u6_addr8 [16];
	uint16_t  u6_addr16 [8];
	uint32_t  u6_addr32 [4];
} my_ip = { .u6_addr16 = { htons(0xfe80), 0, 0, 0, 0, htons(0xff), htons(0xfe00), htons(0x42) } };

static uint8_t net_buf[1500 /* MTU */];

/*---------------------------------------------------------------------------*/
static uint32_t gettc(void) {
  STATIC_ASSERT(RAND_MAX == 0x7fffffff);
  return rand(); // returns a pseudo-random integer between 0 and RAND_MAX
}
/*---------------------------------------------------------------------------*/
#define PRINT_SRC_DEST(packet, pre) \
	PRINTF(pre "%x:%x:%x:%x:%x:%x:%x:%x -> %x:%x:%x:%x:%x:%x:%x:%x\n", 	  \
		htons(packet->src.u6_addr16[0]),  htons(packet->src.u6_addr16[1]),	\
		htons(packet->src.u6_addr16[2]),  htons(packet->src.u6_addr16[3]),	\
		htons(packet->src.u6_addr16[4]),  htons(packet->src.u6_addr16[5]),	\
		htons(packet->src.u6_addr16[6]),  htons(packet->src.u6_addr16[7]),	\
		htons(packet->dest.u6_addr16[0]), htons(packet->dest.u6_addr16[1]),	\
		htons(packet->dest.u6_addr16[2]), htons(packet->dest.u6_addr16[3]),	\
		htons(packet->dest.u6_addr16[4]), htons(packet->dest.u6_addr16[5]),	\
		htons(packet->dest.u6_addr16[6]), htons(packet->dest.u6_addr16[7]))
/*---------------------------------------------------------------------------*/
static uint16_t ip_cksum(uint32_t sum, uint8_t *buf, size_t len)
{
	while(len >= 2)
	{
		sum += ((uint16_t)*buf << 8) | *(buf+1);
		buf += 2;
		len -= 2;
	}

	if(len)
		sum += (uint16_t)*buf << 8;

	while(sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);

	return ~htons((uint16_t)sum);
}
/*---------------------------------------------------------------------------*/
static void eth_reply(eth_frame_t *frame, uint16_t len)
{
	memcpy(frame->to_addr, frame->from_addr, sizeof mac_addr);
	memcpy(frame->from_addr, mac_addr, sizeof mac_addr);
	enc28j60_send((void*)frame, len + sizeof(eth_frame_t));
}
/*---------------------------------------------------------------------------*/
// reply 2 tcp pkt
// must be set manually:
//  - tcp.seq_num
//  - tcp.ack_num
//  - tcp.flags
static void tcp_reply(eth_frame_t *frame, uint16_t len)
{
  uint16_t temp;

  ip_packet_t *ip = (void*)(frame->data);
  tcp_packet_t *tcp = (void*)(ip->data);

  // swap src/dst, fill tcp hdr?
  temp = tcp->from_port;
  tcp->from_port = tcp->to_port;
  tcp->to_port = temp;
  tcp->window = htons(TCP_WINDOW_SIZE);
  tcp->urgent_ptr = 0;

  // SYN packet?
  if(tcp->flags & TCP_FLAG_SYN) {
    // add MSS option
    tcp->data_offset = (sizeof(tcp_packet_t) + 4) << 2;
    tcp->data[0] = 2; // MSS option
    tcp->data[1] = 4; // MSS option length = 4 bytes
    tcp->data[2] = TCP_SYN_MSS>>8;
    tcp->data[3] = TCP_SYN_MSS&0xff;
    len = 4;
  }
  else {
    // not syn packet - no options
    tcp->data_offset = sizeof(tcp_packet_t) << 2;
  }

  // calculate chksum
  len += sizeof(tcp_packet_t);
  tcp->cksum = 0;
  tcp->cksum = ip_cksum(len + IP_PROTOCOL_TCP, (void *)&ip->src, len + (2 * sizeof my_ip));

  ip->payload_len = htons(len);
  memcpy(&ip->dest, &ip->src, sizeof ip->src);
  memcpy(&ip->src, &my_ip, sizeof ip->src);
  eth_reply(frame, len + sizeof(ip_packet_t));
}
/*---------------------------------------------------------------------------*/
// swap seq/ack num, then count ack up
//   (num - num bytes received == ack_num increment)
static void tcp_step(tcp_packet_t *tcp, uint16_t num)
{
  uint32_t ack_num;
  ack_num = ntohl(tcp->seq_num) + num;
  tcp->seq_num = tcp->ack_num;
  tcp->ack_num = htonl(ack_num);
}
/*---------------------------------------------------------------------------*/
static void tcp_filter(eth_frame_t *frame, uint16_t len)
{
  ip_packet_t *ip = (void*)(frame->data);
  tcp_packet_t *tcp = (void*)(ip->data);

  switch(tcp->flags) {
    case TCP_FLAG_SYN:
      PRINTF("TCP_FLAG_SYN\n");
      // send SYN/ACK
      tcp->flags = TCP_FLAG_SYN | TCP_FLAG_ACK;
      tcp_step(tcp, 1);
      tcp->seq_num = htonl(gettc());
      tcp_reply(frame, 0);
      break;

    case TCP_FLAG_ACK:
      PRINTF("TCP_FLAG_ACK\n");
      break;

    case TCP_FLAG_PSH | TCP_FLAG_ACK:
      len -= sizeof (tcp_packet_t);
      PRINTF("TCP_FLAG_PSH [len: %u]\n", len);
      tcp_step(tcp, len);
      // send ACK
      tcp->flags = TCP_FLAG_ACK;
      // feed/read data to/from app
      tcp_reply(frame, tcp_data(frame, len));
      break;

    case TCP_FLAG_FIN | TCP_FLAG_ACK:
      PRINTF("TCP_FLAG_FIN\n");
      tcp_step(tcp, 1);
      tcp_reply(frame, 0);
      break;

    default:
      PRINTF("Unhandled TCP flag(s): %u\n", tcp->flags);
  }
}
/*---------------------------------------------------------------------------*/
static void icmp_filter(eth_frame_t *frame, uint16_t len)
{
	ip_packet_t *packet = (void*)frame->data;
	icmp_packet_t *icmp = (void*)packet->data;

	struct {
		uint8_t target_address_u6_addr8[sizeof my_ip];
		uint8_t type;
		uint8_t length;
		uint8_t addr[sizeof mac_addr];
	} *option = (void*)icmp->data;

	STATIC_ASSERT(32 /* == len */ == sizeof(icmp_packet_t) + sizeof *option);

	if( len >= sizeof(icmp_packet_t) + sizeof *option )
	{
		if(icmp->type == ICMP_TYPE_NEIGHBOR_SOLICITATION && icmp->code == 0)
		{
			icmp->type = ICMP_TYPE_NEIGHBOR_ADVERTISEMENT;
			icmp->flags = htonl(0x60000000); // Solicited: Set, Override: Set
			icmp->cksum = 0;
			option->type = 2; // Type: Target link-layer address (2) 
			memcpy(option->addr, mac_addr, sizeof mac_addr);
			memcpy(&packet->dest, &packet->src, sizeof packet->src);
			memcpy(&packet->src, &my_ip, sizeof packet->src);
			icmp->cksum = ip_cksum(len + IP_PROTOCOL_ICMP6, (void *)&packet->src, len + (2 * sizeof my_ip));

			eth_reply(frame, len + sizeof(ip_packet_t));
		}
	}
}
/*---------------------------------------------------------------------------*/
static char toMe(uint32_t u6_addr32[4]) {
	return
		( !memcmp(&my_ip, u6_addr32, sizeof my_ip) ) || 
		// multicast
		( u6_addr32[0] == htonl(0xff020000) &&
		u6_addr32[1] == 0 && u6_addr32[2] == htonl(1l) &&
		u6_addr32[3] == (my_ip.u6_addr32[3] | htonl(0xff000000)) );
}
/*---------------------------------------------------------------------------*/
static void ip_filter(eth_frame_t *frame, uint16_t len)
{
	ip_packet_t *packet = (void*)(frame->data);
	
	if(len >= sizeof(ip_packet_t))
	{
		if( (packet->ver_tc_label & IPV6_MASK_VER) == IPV6_VER && toMe(packet->dest.u6_addr32) ) {
			
			const uint16_t p_len = ntohs(packet->payload_len);

			switch(packet->next_header)
			{
			case IP_PROTOCOL_ICMP6:
				PRINT_SRC_DEST(packet, "ICMP6: ");
				icmp_filter(frame, p_len);
				break;
			case IP_PROTOCOL_TCP:
				PRINT_SRC_DEST(packet, "TCP: ");
				tcp_filter(frame, p_len);
				break;
			}
		}
	}
}
/*---------------------------------------------------------------------------*/
static void eth_filter(eth_frame_t *frame, uint16_t len)
{
	if(len >= sizeof(eth_frame_t))
	{
		switch(frame->type)
		{
		case ETH_TYPE_IP6:
			ip_filter(frame, len - sizeof(eth_frame_t));
			break;
		}
	}
}
/*---------------------------------------------------------------------------*/
void lan_init(void)
{
	enc28j60_init(mac_addr);
}
/*---------------------------------------------------------------------------*/
void lan_poll(void)
{
	uint16_t len;
	eth_frame_t *frame = (void*)net_buf;
	
	while((len = enc28j60_read(net_buf, sizeof(net_buf)))) {
    if (len > sizeof(net_buf)) {
      PRINTF("frame too big %u > %u net_buf size", len, sizeof(net_buf));
    } else {
      eth_filter(frame, len);
    }
  }
}
