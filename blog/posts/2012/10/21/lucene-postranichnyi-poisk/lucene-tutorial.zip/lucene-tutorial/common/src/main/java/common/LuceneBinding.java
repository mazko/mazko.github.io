package common;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

/* This class is used both by Crawler and SearchServlet */

public final class LuceneBinding {
	public static final Path INDEX_PATH = Paths.get(System.getProperty("user.home"), "lucene-tutorial-index");
	public static final String URI_FIELD = "uri";
	public static final String TITLE_FIELD = "title";
	public static final String CONTENT_FIELD = "content";

	public static Analyzer getAnalyzer() {
		return new StandardAnalyzer();
	}
}
