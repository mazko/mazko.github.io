package crawler;

import org.apache.log4j.Logger;

public class App {

	private static final Logger logger = Logger.getLogger(App.class.getName());

	private final static String crawlSeed = "http://localhost:8080";

	public static void main(final String[] args) {
		try (final LuceneIndexer luceneIndexer = new LuceneIndexer()) {

			luceneIndexer.new_index();

			/* Start crawler and perform indexing */

			new SimpleCrawler(App.crawlSeed, new SimpleCrawler.ICrawlEvents() {

				/* Proceed page - add to Lucene index */

				@Override
				public void onVisit(final String url, final String html, final String seed) {
					luceneIndexer.add(url, html);
				}

				/* Skip any external links */

				@Override
				public boolean shouldVisit(final String url, final String seed) {
					return url.startsWith(seed);
				}

			}).run();

		} catch (final Exception ex) {
			App.logger.error("Unable to start !", ex);
		}
	}
}