package common;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.ru.RussianAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

/* This class is used both by Crawler and SearchServlet */

public final class LuceneBinding {
	public static final Path INDEX_PATH = Paths.get(System.getProperty("user.home"), "lucene-tutorial-index");

	public static final String URI_FIELD = "uri";
	public static final String TITLE_FIELD = "title";
	public static final String CONTENT_FIELD = "content";

	/* Russian */

	public static final String RUS_TITLE_FIELD = "rustitle";
	public static final String RUS_CONTENT_FIELD = "ruscontent";

	/* English */

	public static final String ENG_TITLE_FIELD = "engtitle";
	public static final String ENG_CONTENT_FIELD = "engcontent";

	public static Analyzer getAnalyzer() {
		final Map<String, Analyzer> analyzers = new HashMap<String, Analyzer>();
		analyzers.put(LuceneBinding.RUS_TITLE_FIELD, new RussianAnalyzer());
		analyzers.put(LuceneBinding.RUS_CONTENT_FIELD, new RussianAnalyzer());
		analyzers.put(LuceneBinding.ENG_TITLE_FIELD, new EnglishAnalyzer());
		analyzers.put(LuceneBinding.ENG_CONTENT_FIELD, new EnglishAnalyzer());

		return new PerFieldAnalyzerWrapper(new StandardAnalyzer(), analyzers);
	}
}
