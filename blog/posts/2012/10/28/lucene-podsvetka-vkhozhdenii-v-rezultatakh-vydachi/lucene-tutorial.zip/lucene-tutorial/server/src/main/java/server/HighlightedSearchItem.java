package server;

import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.highlight.SimpleSpanFragmenter;

import common.LuceneBinding;

public class HighlightedSearchItem extends DefaultSearchItem {

	public final String highlightedTitle, highlightedContent;

	HighlightedSearchItem(final String title, final String content, final String uri, final float score,
			final String highlightedTitle, final String highlightedContent) {
		super(title, content, uri, score);
		this.highlightedContent = highlightedContent;
		this.highlightedTitle = highlightedTitle;
	}
}

class HighlightedAgregator extends Aggregator<HighlightedSearchItem> {

	private Highlighter highlighter;

	private final String tryHighlight(final String text, final String[] fields)
			throws IOException, InvalidTokenOffsetsException {

		if (text == null) {
			return null;
		}

		if (this.highlighter == null) {
			final QueryScorer scorer = new QueryScorer(this.query);
			this.highlighter = new Highlighter(new SimpleHTMLFormatter("[mazko.github.io]", "[/mazko.github.io]"),
					scorer);
			this.highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer, 330));
		}

		for (final String field : fields) {
			final String highlighted = this.highlighter.getBestFragment(LuceneBinding.getAnalyzer(), field, text);
			if (highlighted != null) {
				return highlighted;
			}
		}

		return text;
	}

	@Override
	HighlightedSearchItem aggregate(final ScoreDoc sd)
			throws IOException, CorruptIndexException, InvalidTokenOffsetsException {

		final Document doc = this.indexSearcher.doc(sd.doc);
		final String title = doc.get(LuceneBinding.TITLE_FIELD);
		final String content = doc.get(LuceneBinding.CONTENT_FIELD);

		final String highlightedTitle = this.tryHighlight(title, new String[] { LuceneBinding.RUS_TITLE_FIELD,
				LuceneBinding.ENG_TITLE_FIELD, LuceneBinding.TITLE_FIELD });
		final String highlightedContent = this.tryHighlight(content, new String[] { LuceneBinding.RUS_CONTENT_FIELD,
				LuceneBinding.ENG_CONTENT_FIELD, LuceneBinding.CONTENT_FIELD });

		return new HighlightedSearchItem(title, content, doc.get(LuceneBinding.URI_FIELD), sd.score, highlightedTitle,
				highlightedContent);
	}
}
