package crawler;

import java.util.HashSet;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

class SimpleCrawler {

	public interface ICrawlEvents {
		void onVisit(String url, String html, String seed);

		boolean shouldVisit(String url, String seed);
	}

	private static final Logger logger = Logger.getLogger(SimpleCrawler.class.getName());

	private final ICrawlEvents events;
	private NavigableSet<String> linksToCrawl;
	private Set<String> linksCrawled;
	private final String seed;

	public SimpleCrawler(final String seed, final ICrawlEvents events) {
		this.events = events;
		this.seed = seed;
	};

	public boolean hasLinksToCrawl() {
		return !this.linksToCrawl.isEmpty();
	}

	public void run() {

		this.linksCrawled = new HashSet<String>();
		this.linksToCrawl = new TreeSet<String>();
		this.linksToCrawl.add(this.seed);

		while (this.hasLinksToCrawl()) {

			final String strURL = this.linksToCrawl.pollFirst();
			this.linksCrawled.add(strURL);

			try {
				final String html = HtmlHelper.download(strURL);

				int linksAdded = 0;
				for (final String l : HtmlHelper.extractLinks(html, this.seed)) {
					if (this.events.shouldVisit(l, this.seed) && !this.linksCrawled.contains(l)
							&& !this.linksToCrawl.contains(l)) {
						this.linksToCrawl.add(l);
						linksAdded++;
					}
				}

				SimpleCrawler.logger.info(String.format("Fetched: [%s] %d new links", strURL, linksAdded));
				this.events.onVisit(strURL, html, this.seed);
			} catch (final Exception ex) {
				SimpleCrawler.logger.error(String.format("Fetch error: [%s].", strURL), ex);
			}
		}
	}
}