package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.util.Version;

public class SearchServlet extends HttpServlet {

    @Override
    public void doGet(final HttpServletRequest req, final HttpServletResponse res)
            throws ServletException, IOException {
        final PrintWriter out = res.getWriter();
        final String luceneVersions = Arrays.toString(Version.class.getFields());

        out.println("<HTML>");
        out.println("<BODY>");
        out.println(luceneVersions.replace(",", "<br />"));
        out.println("</BODY>");
        out.println("</HTML>");

        out.close();
    }
}
