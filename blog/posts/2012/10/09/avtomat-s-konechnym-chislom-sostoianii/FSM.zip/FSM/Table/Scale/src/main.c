#include "main.h"

typedef enum {
	LEFT_TO_RIGHT,
	RIGHT_TO_LEFT,

	/* Add brightness algoritms States */

	RIGHT_LEFT_TO_BRIGHT
} State;

/* Global variable to hold current state */

static State currentState = RIGHT_TO_LEFT;

/* Event handlers implementations */

static void onLeftToRightTickImpl() {
	nextLeftLed(); // in main.h
}

static void onLeftToRightNextImpl() {
	resetLeds(); // in main.h
	currentState = RIGHT_TO_LEFT;
}

static void onRightToLeftTickImpl() {
	nextRightLed(); // in main.h
}

/* LEFT_TO_RIGHT ==> RIGHT_LEFT_TO_BRIGHT */

static void onRightToLeftNextImpl() {
	resetLeds(); // in main.h
	currentState = RIGHT_LEFT_TO_BRIGHT;
}

/* Add brightness handlers */

static void onRightToLeftBrigtTickImpl() {
	nextRightBrightLed(); // in main.h
}

static void onRightToLeftBrigtNextImpl() {
	resetLeds(); // in main.h
	currentState = LEFT_TO_RIGHT;
}

void main (void) {

	initHardware(); // in main.h

	typedef enum {
		NEXT,
		TICK
	} Event;

	typedef struct _Transition {
		State state;
		Event event;
		void (*EventFunc)();
	} Transition;

	const Transition transitionTable[] = {
		{LEFT_TO_RIGHT, TICK, onLeftToRightTickImpl},
		{LEFT_TO_RIGHT, NEXT, onLeftToRightNextImpl},
		{RIGHT_TO_LEFT, TICK, onRightToLeftTickImpl},
		{RIGHT_TO_LEFT, NEXT, onRightToLeftNextImpl},

		/* Add brightness algoritms transitions */

		{RIGHT_LEFT_TO_BRIGHT, TICK, onRightToLeftBrigtTickImpl},
		{RIGHT_LEFT_TO_BRIGHT, NEXT, onRightToLeftBrigtNextImpl}
	};

	for (;;) {

		/* Default event to fire */

		Event eventToFire = TICK;

		/* Wait a little for button pressed. If so change eventToFire to NEXT */

 		for (unsigned int i = 5000; i; i--) {
			if (isNextButtonPressed()) {
				eventToFire = NEXT;
				break; // Fire NEXT event
			} 
		}

		/* Perform event. Read our previous post about Idioms in C */

		int elementsCount = sizeof(transitionTable) / sizeof(transitionTable[0]);
		while (elementsCount--) {
			Transition transition = transitionTable[elementsCount];
			if (transition.state == currentState && transition.event == eventToFire) {
				transition.EventFunc();
				break; // Target EventFunc founded and fired!
			}
		}
	}
}
