#!/bin/bash

cd "`dirname "${0}"`"

/usr/hitech/picc/9.83/bin/PICC-SOCKET-FIREWALL -q --opt=all --chip=16F1823 --ASMLIST main.c

rm -f *.cof *.sym *.hxl *.obj *.pre *.p1 *.rlf *.as *.sdb startup.lst
