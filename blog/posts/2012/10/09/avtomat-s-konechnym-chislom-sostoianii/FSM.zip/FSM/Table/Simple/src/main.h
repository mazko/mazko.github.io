#include <htc.h>

__CONFIG ( WDTE_OFF );

static void initHardware() {
	DACOE = DACEN = 1;
	DACCON1 = 0b11111; // max

	PORTC = 0b111;
	TRISC = 0b100000;
}

static char isNextButtonPressed() {
	if (RC5) {
		while (RC5);
		return 1;
	}
	return 0;
}

static unsigned char presaler = 0;

static void nextRightLed() {
	if (++presaler < 5) return;
	presaler = 0;

	if (PORTC == 0b111) {
		PORTC = 0b110;
	} else if (PORTC == 0b110) {
		PORTC = 0b101;
	} else if (PORTC == 0b101) {
		PORTC = 0b011;
	} else {
		PORTC = 0b111;
	}
}

static void nextLeftLed() {
	if (++presaler < 5) return;
	presaler = 0;

	if (PORTC == 0b111) {
		PORTC = 0b011;
	} else if (PORTC == 0b011) {
		PORTC = 0b101;
	} else if (PORTC == 0b101) {
		PORTC = 0b110;
	} else {
		PORTC = 0b111;
	}
}

static void resetLeds() {
	PORTC = 0b111;
	DACCON1 = 0b11111; // max
	presaler = 0;
}

