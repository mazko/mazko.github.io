import React from 'react';
import Hi from '../hi/hi.component.jsx';


class Film extends React.Component {
  render() {
    const film = this.props.film,
          opt = (v, s=' | ') => v && v.join(s),
          date = v => v && v.map(d => d.toLocaleDateString())

    return (
      <div>
        <hr/>
        <p>
          <b>Название: </b><Hi content={film.name} /> {' | '}
          <a href={'https://www.kinopoisk.ru/film/' + film.id}>{film.rate}</a>
          {' | '} {date(film.date)}
        </p>
        <p>
          <b>Режиссёр: </b>{opt(film.directed)}
        </p>
        <p>
          <b>Жанр: </b>{opt(film.category)}
        </p>
        <p>
          <b>Актёры: </b>{opt(film.starring)}
        </p>
        <p>
          <b>Описание: </b><Hi content={opt(film.description, '...')} />
        </p>
      </div>
    );
  }
}
Film.propTypes = { 
  film: React.PropTypes.shape({
    id: React.PropTypes.arrayOf(React.PropTypes.number).isRequired,
    name: React.PropTypes.arrayOf(React.PropTypes.string).isRequired,
    rate: React.PropTypes.arrayOf(React.PropTypes.number).isRequired,
    date: React.PropTypes.arrayOf(React.PropTypes.instanceOf(Date)),
    category: React.PropTypes.arrayOf(React.PropTypes.string),
    starring: React.PropTypes.arrayOf(React.PropTypes.string),
    directed: React.PropTypes.arrayOf(React.PropTypes.string),
    description: React.PropTypes.arrayOf(React.PropTypes.string).isRequired,
  }) 
};

class FilmsList extends React.Component {

  render() {
    const filmNodes = this.props.films.map(film => (
      <Film film={film} key={film.id} />
    ));
    return (
       <div>
          {filmNodes}
       </div>
    );
  }
}
FilmsList.propTypes = {
  films: React.PropTypes.array.isRequired
};

export default FilmsList;