import fetch from 'isomorphic-fetch';

const ELASTIC_URL = 'http://localhost:9200/kinopoisk/';

function search(kwargs) {
  const kwargsDefs = {
    from: 0, size: 5, fields: [ "name", "description" ]
  };
  kwargs = Object.assign(kwargsDefs, kwargs);

  const url = new URL(ELASTIC_URL + 'film/_search');
  url.searchParams.set('source', JSON.stringify({
    'from': kwargs.from,
    'size': kwargs.size,
    "fields" : [
      "id", "name", "date", 
      "description", "rate", 
      "starring", "category", "directed"],
    "query" : {
      "bool": {
        "must": [
          kwargs.q 
            ? { "query_string" : {
                  "query": kwargs.q,
                  "fields": kwargs.fields,
                  "default_operator": "and"
                }
              } 
            : { "match_all": {} },
        ],
        "filter": [
          kwargs.year
            ? {
              "range" : {
                "date" : {
                  "gte" : kwargs.month >= 0 ? kwargs.year + "-" + kwargs.month : kwargs.year,
                  "lt" : kwargs.year + (kwargs.month >= 0 ? "-" + kwargs.month + "||+1M" : "||+1y"),
                  "format": "yyyy-MM||yyyy"
                }
              }
            }
            : null,
         kwargs.category 
           ? {
             "match": {
               "category.raw": kwargs.category
             }
           } : null,
         kwargs.director 
           ? {
             "match": {
               "directed.raw": kwargs.director
             }
           } : null,
         kwargs.star 
           ? {
             "match": {
               "starring.raw": kwargs.star
             }
           } : null,
        ].filter(v => v !== null)
      }
    },
    "highlight" : {
      "pre_tags" : ["[mazko.github.io]"],
      "post_tags" : ["[/mazko.github.io]"],
      "fields" : kwargs.fields.reduce(
        (result, item) => {
          result[item] = {
            "fragment_size" : 333
          };
          return result;
        }, {})
    },
    "sort" : [
      {"rate" : {"order" : "desc"} }
     ],
    "aggs": {
      "years": {
        "date_histogram": {
          "field": "date",
          "interval": "year",
          "min_doc_count": 1,
          "order" : { "_count" : "desc" }
        },
        "aggs": {
          "months": {
            "date_histogram": {
              "field": "date",
              "interval": "month",
              "min_doc_count": 1,
              "order" : { "_count" : "desc" }
            }
          }
        }
      },
      "categories" : {
        "terms" : { "field" : "category.raw", "size": 1000 }
      },
      "directors" : {
        "terms" : { "field" : "directed.raw", "size": 1000 }
      },
      "stars" : {
        "terms" : { "field" : "starring.raw", "size": 1000 }
      }
    }
  }));
  return fetch(url)
    .then(response => {
      if (response.status >= 400) {
          throw new Error("Bad response from server");
      }
      return response.json();
    })
    .then(({ hits, aggregations }) => {
      const chunk = {
        items: hits.hits
          .map(
            hit => Object.assign(hit.fields, hit.highlight))
          .map(film => {
            film.date = film.date && film.date.map(d => new Date(d));
            return film;
          }),
        total: hits.total
      };
      const aggs = {
        directors: aggregations.directors.buckets,
        categories: aggregations.categories.buckets,
        stars: aggregations.stars.buckets,
        years: aggregations.years.buckets.map(y => {
          return {
            doc_count: y.doc_count, 
            key: new Date(y.key).getFullYear(),
            months: y.months.buckets.map(m => {
              return {
                doc_count: m.doc_count, 
                key: new Date(m.key).getMonth() + 1
              }
            })
          }
        })
      };
      return {chunk, aggs};
    });
}

function suggest(a, size=10) {
  const url = new URL(ELASTIC_URL + '_suggest');
  url.searchParams.set('source', JSON.stringify({
    "kino" : {
      "text" : a,
      "completion" : {
        "field" : "suggest",
        "size": size
      }
    }
  }));
  return fetch(url)
    .then(response => {
      if (response.status >= 400) {
          throw new Error("Bad response from server");
      }
      return response.json();
    })
    .then(data => {
      const opts = data.kino[0].options;
      return opts.map(opt => opt.text);
    });
}

export default {
  search,
  suggest
}
