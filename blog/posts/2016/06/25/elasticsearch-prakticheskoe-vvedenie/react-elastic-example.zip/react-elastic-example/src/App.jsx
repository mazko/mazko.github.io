import React from 'react';
import FilmsSearch from './films-search/films-search.component.jsx'


export default class extends React.Component {
   render() {
      return (
         <FilmsSearch/>
      );
   }
}