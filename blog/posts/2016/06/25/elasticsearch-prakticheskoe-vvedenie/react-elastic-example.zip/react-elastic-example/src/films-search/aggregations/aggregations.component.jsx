import React from 'react';
import styles from './aggregations.component.css';


class AggregationsComponent extends React.Component {

  constructor(props) {
    super(props);
    this.state = {};
  }

  componentWillReceiveProps(nextProps) {
    let {aggs} = nextProps;

    if (!aggs) return;
    // clone
    aggs = Object.assign({}, aggs);
    // Flatten array easier to render
    aggs.years = aggs.years.reduce(
      (flat, toFlat) => [
        ...flat,
        { year: toFlat.key, doc_count: toFlat.doc_count },
        ...toFlat.months.map(m => {
          return {
            year: toFlat.key,
            month: m.key,
            doc_count: m.doc_count
          }
        })
      ], []);

    // user friendly empty search results
    const {
      search_star, search_director, search_category,
      search_month, search_year
    } = this.state;

    if (search_star && aggs.stars.length === 0) {
      aggs.stars = [{key: search_star, doc_count: 0}];
    }
    if (search_category && aggs.categories.length === 0) {
      aggs.categories = [{key: search_category, doc_count: 0}];
    }
    if (search_director && aggs.directors.length === 0) {
      aggs.directors = [{key: search_director, doc_count: 0}];
    }
    if (search_month && aggs.years.length === 0) {
      aggs.years = [
        {year: search_year, doc_count: 0},
        {year: search_year, month: search_month, doc_count: 0}
      ];
    } else if (search_year && aggs.years.length === 0) {
      aggs.years = [{year: search_year, doc_count: 0}];
    }

    this.setState({aggs});
  }

  handleStar(e) {
    this.setState({search_star: e.target.value}, this._emit);
  }

  handleDirector(e) {
    this.setState({search_director: e.target.value}, this._emit);
  }

  handleCaterory(e) {
    this.setState({search_category: e.target.value}, this._emit);
  }

  handleYM(e) {
    const idx = e.target.value, {aggs} = this.state;
    if (idx >= 0) {
      this.setState({
          search_year: aggs.years[idx]['year'],
          search_month: aggs.years[idx]['month'],
        }, this._emit);
    } else {
      this.setState({
          search_year: undefined,
          search_month: undefined,
        }, this._emit);
    }
  }

  _emit() {
    this.props.onAggsChange({
      year: this.state.search_year,
      month: this.state.search_month,
      star: this.state.search_star,
      category: this.state.search_category,
      director: this.state.search_director
    });
  }

  render() {
    const {
      aggs, search_star, search_director, search_category,
      search_month, search_year
    } = this.state;

    const ym = aggs && aggs.years.map((v, i) => (
      <option key={i} value={i}>
        {(v.month >= 0 
            ? '-> ' + ("00" + v.month).slice(-2) 
            : v.year) + ' | ' + v.doc_count}
      </option>
      )
    );

    const stars = aggs && aggs.stars.map(v => (
      <option key={v.key} value={v.key}>
        {v.doc_count} | {v.key}
      </option>
      )
    );

    const dirs = aggs && aggs.directors.map(v => (
      <option key={v.key} value={v.key}>
        {v.doc_count} | {v.key}
      </option>
      )
    );

    const cats = aggs && aggs.categories.map(v => (
      <option key={v.key} value={v.key}>
        {v.doc_count} | {v.key}
      </option>
      )
    );

    const search_ym_idx = aggs && aggs.years.findIndex(v => 
      v.month === search_month && v.year === search_year);

    return (
      <span className={styles.span}>
        <select value={search_ym_idx}
                onChange={this.handleYM.bind(this)}>
          <option value='-1'>&nbsp;</option>
          {ym}
        </select>
        <select value={search_star} 
                onChange={this.handleStar.bind(this)}>
          <option value=''>&nbsp;</option>
          {stars}
        </select>
        <select value={search_director} 
                onChange={this.handleDirector.bind(this)}>
          <option value=''>&nbsp;</option>
          {dirs}
        </select>
        <select value={search_category} 
                onChange={this.handleCaterory.bind(this)}>
          <option value=''>&nbsp;</option>
          {cats}
        </select>
      </span>
    );
  }
}
AggregationsComponent.propTypes = {
  onAggsChange : React.PropTypes.func,
  filter: React.PropTypes.shape({
    year: React.PropTypes.number,
    month: React.PropTypes.number,
    star: React.PropTypes.string,
    category: React.PropTypes.string,
    director: React.PropTypes.string
  }) 
};

export default AggregationsComponent;