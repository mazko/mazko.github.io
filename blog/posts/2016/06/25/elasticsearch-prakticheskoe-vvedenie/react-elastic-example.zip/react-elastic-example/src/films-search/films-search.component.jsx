import React from 'react';
import elastic from './elastic.service';
import FilmsList from './films-list/films-list.component.jsx';
import Autocomplete from './auto-complete/auto-complete.component.jsx';
import AggsComponent from './aggregations/aggregations.component.jsx';

import styles from './films-search.component.css';


export default class extends React.Component {

  constructor(props) {
    super(props);
    this.state = { 
      films: [],
      films_per_page: 5,
    };
  }

  componentDidMount() {
    this.handleQuery();
  }

  handleQuery(search_query) {
    this.setState(
      {current_page: 1, search_query}, 
      this._search
    );
  }

  handlePerPage(e) {
    this.setState(
      {films_per_page: e.target.value},
      () => this.handleQuery(this.state.search_query)
    );
  }

  handlePrevPage() {
    this.setState(
      {current_page: this.state.current_page -1},
      this._search
    );
  }

  handleNextPage() {
    this.setState(
      {current_page: this.state.current_page +1}, 
      this._search
    );
  }

  handleAggs(search_aggs) {
    this.setState({search_aggs},
      () => this.handleQuery(this.state.search_query));
  }

  _search() {
    const {
      current_page, total_pages, films_per_page,
      search_query, search_aggs
    } = this.state, from = (current_page - 1) * films_per_page;
    this.setState({is_fetching_state: true});
    elastic.search(Object.assign({
      from, size: films_per_page,
      q: search_query
    }, search_aggs)).catch(e => alert(e)).then(
      ({chunk, aggs}) => {
        this.setState({
          aggs,
          is_fetching_state: false,
          films: chunk.items,
          total_pages: Math.ceil(chunk.total / films_per_page)
        })
    }); 
  }

  render() {
    const {
      current_page, total_pages, films_per_page, is_fetching_state
    } = this.state;
    return (
      <div className={styles.div}>
        <div className={styles.row}>
          <Autocomplete onQueryChange={this.handleQuery.bind(this)} />
          <span className={styles.span}>
            <select className={styles.select} 
                    disabled={is_fetching_state}
                    value={films_per_page} 
                    onChange={this.handlePerPage.bind(this)}>
              { 
                [3, 5, 10, 25].map(v => 
                (<option key={v} value={v}>{v}</option>)) 
              }
            </select>
          </span>

          {
            current_page > 1
            ? <button className={styles.button}
                      disabled={is_fetching_state}
                      onClick={this.handlePrevPage.bind(this)}>
                {'<'}
              </button>
            : null
          }
          
          {
            current_page < total_pages
            ? <button className={styles.button} 
                      disabled={is_fetching_state}
                      onClick={this.handleNextPage.bind(this)}>
                {'>'}
              </button>
            : null
          }

          <span className={styles.span + ' ' + styles.center}>
            Страница {current_page} из {total_pages}
          </span>

        </div>

        <p>
          <AggsComponent aggs={this.state.aggs} 
              onAggsChange={this.handleAggs.bind(this)} />
        </p>  

        <FilmsList films={this.state.films} />
      </div>
    );
  }
}