import React from 'react';
import elastic from '../elastic.service';
import styles from './auto-complete.component.css';


class Autocomplete extends React.Component {

  constructor(props) {
    super(props);
    this.state = { suggestions: [], query: '' };
  }

  handleKeyUp(e) {
    if (e.key === 'Enter') {
      this.props.onQueryChange(e.target.value);
    }
    if (['Enter', 'Escape'].indexOf(e.key) > -1) {
      this.setState({suggestions: []});
    }
  }

  handleChange(e) {
    const query = e.target.value;
    this.setState({query});
    elastic.suggest(query).then( /* TODO: debounce */
      suggestions => this.setState({suggestions})
    );
  }

  handleDocumentClick(e) {
    if (this.refs.menu.contains(e.target)) {
      const query = e.target.dataset['val'];
      this.props.onQueryChange(query);
      this.setState({query});
    } 
    this.setState({suggestions: []});
  }

  componentWillMount() {
    document.addEventListener('click', 
      this.handleDocumentClick.bind(this), false);
  }

  componentWillUnmount() {
    document.removeEventListener('click', 
      this.handleDocumentClick.bind(this), false);
  }

  render() {
    const menu = this.state.suggestions.map(
      v => (
        <li key={v} data-val={v} className={styles.ulli}>{v}</li>
      )
    );
    return (
      <div className={styles.div}>
        <span>
          <input
            type="text" 
            placeholder="пример:космос" 
            autoComplete="off"
            onChange={this.handleChange.bind(this)}
            value={this.state.query}
            onKeyUp={this.handleKeyUp.bind(this)} />
        </span>
        <ul ref='menu'>
          {menu}
        </ul>
      </div>
    );
  }
}
Autocomplete.propTypes = {
  onQueryChange : React.PropTypes.func
};

export default Autocomplete;