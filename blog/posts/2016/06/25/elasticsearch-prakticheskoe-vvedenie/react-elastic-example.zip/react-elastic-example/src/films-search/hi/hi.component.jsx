import React from 'react';


class Hi extends React.Component {

  constructor(props) {
    super(props);
    this.state = { hiHtml: '' };
  }

  updateHiHtml(){
    const {me} = this.refs;
    if (me) {
      const hiHtml = me.innerHTML.replace(
          /\[mazko\.github\.io\](.*?)\[\/mazko\.github\.io\]/g, 
          "<b style=\"color:red;\">$1</b>"
      );
      if (me.innerHTML !== hiHtml) {
        this.setState({hiHtml}); 
      }
    }  
  }

  componentDidUpdate() {
    this.updateHiHtml();
  }

  componentDidMount() {
    this.updateHiHtml();
  }

  componentWillReceiveProps() {
    this.setState({hiHtml: ''});
  }

  render() {
    return (
      this.state.hiHtml 
        ? <span dangerouslySetInnerHTML={{__html: this.state.hiHtml}} />
        : <span ref='me'>{this.props.content}</span>
    );
  }
}
Hi.propTypes = {
  content : React.PropTypes.oneOfType([
    React.PropTypes.string,
    React.PropTypes.arrayOf(React.PropTypes.string)
  ]).isRequired
};

export default Hi;