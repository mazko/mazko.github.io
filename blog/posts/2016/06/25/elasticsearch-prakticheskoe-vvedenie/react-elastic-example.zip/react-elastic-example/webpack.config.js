module.exports = {
   entry: './src/main.js',
  
   output: {
      path:'./dist',
      filename: 'bundle.js',
   },

   devtool: 'source-map',
  
   devServer: {
      inline: true,
      port: 8080
   },
  
   module: {
      loaders: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel',
            query: {
               presets: ['es2015', 'react']
            }
         },
         { 
            test: /\.css$/, 
            loader: "style-loader!css-loader?modules=true" 
         }
      ]
   }
};