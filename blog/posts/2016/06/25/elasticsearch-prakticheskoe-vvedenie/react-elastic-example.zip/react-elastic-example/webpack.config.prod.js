var dev = require("./webpack.config.js"),
    webpack = require('webpack');

dev.plugins = dev.plugins || [];

dev.plugins.push(
  new webpack.DefinePlugin({
    'process.env': {
      'NODE_ENV': JSON.stringify('production')
    }
  })
);

dev.plugins.push(
  new webpack.optimize.UglifyJsPlugin({
    compress: {
      warnings: false
    }
  })
);

module.exports = dev;