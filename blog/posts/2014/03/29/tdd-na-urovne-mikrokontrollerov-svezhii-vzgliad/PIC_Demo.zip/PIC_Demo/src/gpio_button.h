#ifndef gpio_button_H
#define gpio_button_H

void gpio_button_init(void);

#endif // gpio_H

