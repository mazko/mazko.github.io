OUT_FILE = "test/simulation/out.txt"
File.delete OUT_FILE if File.exists? OUT_FILE

pipe = IO.popen("/opt/microchip/mplabx/mplab_ide/bin/mdb.sh " \
                "./test/simulation/mplab_sim_instructions.txt " \
                "> #{OUT_FILE}")

trap("INT") { Process.kill("KILL", pipe.pid); exit }

Process.wait(pipe.pid)
if File.exists? OUT_FILE
    file_contents = File.read OUT_FILE
    print file_contents
else
    print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n" \
          "! Program was not simulated ? !\n" \
          "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
end

