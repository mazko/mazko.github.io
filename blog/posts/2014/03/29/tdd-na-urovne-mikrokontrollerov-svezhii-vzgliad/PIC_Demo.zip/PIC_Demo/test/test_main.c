#include "unity.h"
#include "hello.h"
#include "mock_system.h"
#include "mock_gpio_led.h"

void setUp(void){
    gpio_led_init_Expect();
}

void tearDown(void){
}

void test_main_function_without_loop(void){
    system_should_abort_app_ExpectAndReturn(true);
    TEST_ASSERT_EQUAL(0, test_main());
}

void test_main_function_loop_one_iteration(void){
    system_should_abort_app_ExpectAndReturn(false);
    gpio_led_set_Expect(11);
    gpio_led_clear_Expect();
    system_should_abort_app_ExpectAndReturn(true);
    TEST_ASSERT_EQUAL(0, test_main());
}

