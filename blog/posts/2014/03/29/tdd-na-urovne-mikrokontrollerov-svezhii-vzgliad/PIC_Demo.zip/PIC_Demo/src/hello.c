#include "hello.h"
#include "system.h"
#include "gpio_led.h"
#ifdef TEST
int test_main(void)
#else
int main (void)
#endif
{
    gpio_led_init();
    while(!system_should_abort_app()) {
        gpio_led_set(11);
        gpio_led_clear();
    }
    return 0;
}

