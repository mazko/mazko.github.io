#include "gpio_button.h"
#include "gpio_led.h"
#include <xc.h>

void gpio_button_init() {
    TRISFbits.TRISF0 = 1;
    CNENFbits.CNIEF0 = 1;
    IFS1bits.CNIF = 0;
    IEC1bits.CNIE = 1;
}

void __attribute__((interrupt,auto_psv)) _CNInterrupt(void)
{
    IFS1bits.CNIF = 0;
    gpio_led_set(42);
}
