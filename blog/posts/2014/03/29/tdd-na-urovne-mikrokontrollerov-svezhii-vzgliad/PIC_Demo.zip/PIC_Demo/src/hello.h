#ifndef hello_H
#define hello_H

#ifdef TEST
int test_main(void);
#endif

#endif // hello_H

