#include "unity.h"
#include "gpio_led.h"
#include <xc.h>
#include <string.h>

void setUp(void){
    gpio_led_init();
    LATABITS clean = {0};
    memcpy((void*)&LATAbits, (void*)&clean, sizeof clean);
}

void tearDown(void){
}

void test_gpio_led_set(void){
    TEST_ASSERT_EQUAL(0, LATAbits.LATA0);
    gpio_led_set(11);
    TEST_ASSERT_EQUAL(1, LATAbits.LATA0);
}

void test_gpio_led_clear(void){
    test_gpio_led_set();
    gpio_led_clear();
    TEST_ASSERT_EQUAL(0, LATAbits.LATA0);
}
