#include "unity.h"
#include "gpio_button.h"
#include "mock_gpio_led.h"
#include <xc.h>

void setUp(void){
    gpio_button_init();
}

void tearDown(void){
}

void test_gpio_button_interrupt(void){
    gpio_led_set_Expect(42);
    IFS1bits.CNIF = 1;
    asm("NOP");
}
