#ifndef system_H
#define system_H
#include <stdbool.h>

bool system_should_abort_app();

#endif // system_H
