#include "gpio_led.h"
#include <xc.h>

void gpio_led_init() {
    TRISAbits.TRISA0 = 0;
}

void gpio_led_set(int brightness) {
    /* TODO: brightness :) */
    LATAbits.LATA0 = 1;
}

void gpio_led_clear() {
    LATAbits.LATA0 = 0;
}

