#ifndef gpio_led_H
#define gpio_led_H

void gpio_led_init(void);
void gpio_led_set(int brightness);
void gpio_led_clear();

#endif // gpio_H

