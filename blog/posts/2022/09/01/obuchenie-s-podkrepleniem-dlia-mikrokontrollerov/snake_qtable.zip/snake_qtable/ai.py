#!/usr/bin/env python3

from snake_game import SnakeGame
from functools import reduce
import time
import copy
import json
import gzip

with gzip.open('snake.qtable.json.gz', 'rt') as f:
  qtable = json.load(f)

def extract_features(game):
  snake, food = game.get_state()
  obsticle = lambda k: copy.deepcopy(game).step(k).done
  obs = sum(v << i for i, v in enumerate(obsticle(k) for k in game.ACTION))
  return obs, snake.head.h, snake.head.w, food.h, food.w

def extract_features_wrapper(game):
  win, gui = game.win, game.gui
  game.win, game.gui = None, False
  fe = extract_features(game)
  game.win, game.gui = win, gui
  return fe

try:
  game = SnakeGame(gui = True)
  while not game.done:
    time.sleep(0.2)
    fe = extract_features_wrapper(game)
    action = reduce(lambda a, i: a[i], fe, qtable)
    state, *done_reward, info = game.step(action)

except KeyboardInterrupt:
  pass

game.end_game()
*state, info = (tuple(p) for p in (
    state.snake.head, *state.snake.body, state.food, info) if p)
print(*state, *done_reward, info)