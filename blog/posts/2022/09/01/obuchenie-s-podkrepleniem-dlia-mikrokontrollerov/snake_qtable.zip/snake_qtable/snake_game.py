#!/usr/bin/env python3

import curses
import random
from enum import Enum
from collections import namedtuple

Point = namedtuple('Point', 'h w')
Snake = namedtuple('Snake', 'head body')
State = namedtuple('State', 'snake food')
Info  = namedtuple('Info' , 'score health')
Step  = namedtuple('Step' , 'state reward done info')

class SnakeGame:

    ACTION = Enum('action', {'UP': 0, 'RIGHT': 1, 'DOWN': 2, 'LEFT': 3})

    def __init__(self, board_width = 32, board_height = 16, gui = False):
        self.board_width = board_width
        self.board_height = board_height
        self.gui = gui
        if self.gui: self.render_init()
        self.reset()

    def reset(self):
        self.current_direction = None
        self.score = 0
        self.done = False
        self.snake = [Point(random.randrange(self.board_height),
                            random.randrange(self.board_width))]
        self.generate_food()
        if self.gui: self.render()
        return self.get_state()

    def generate_food(self):
        self.health = self.board_width * self.board_height - len(self.snake)
        if not self.health:
            raise NotImplemented()
        candidates = []
        for i in range(self.board_height):
            for j in range(self.board_width):
                point = Point(i, j)
                if point not in self.snake:
                    candidates.append(point)
        self.food = random.choice(candidates)

    def render_init(self):
        curses.initscr()
        border = Point(self.board_height + 2, self.board_width + 4) # ui: 2, 4 padding
        center = (curses.LINES - border.h) // 2, (curses.COLS - border.w) // 2
        win = curses.newwin(*border, *center)
        curses.curs_set(0)
        win.nodelay(True) # getch() will be non-blocking
        win.keypad(True)  # allow getch() to see arrow keys
        self.win = win

    def render(self):
        self.win.clear()
        self.win.border()
        self.win.addstr(0, 2, ' Score : %X |' % self.score + 
                              ' Health : %X ' % self.health)
        for point in self.snake + [self.food]: # ui: draw offset 1 from border
            self.win.addch(point.h + 1, point.w + 1, curses.ACS_DIAMOND)
        self.win.refresh()

    def check_opposite_direction(self, act):
        map = {
            self.ACTION.UP:    self.ACTION.DOWN,
            self.ACTION.RIGHT: self.ACTION.LEFT,
            self.ACTION.DOWN:  self.ACTION.UP,
            self.ACTION.LEFT:  self.ACTION.RIGHT,
        }
        self.done = map[act] is self.current_direction
        self.current_direction = act

    def step(self, act):
        act = self.ACTION(act)
        self.check_opposite_direction(act)
        if not self.done:
            self.create_new_point(act)
            if self.food_eaten():
                reward = 1
                self.score += 100
                self.generate_food()
            else:
                self.remove_last_point()
                self.check_collisions()
                if not self.done:
                    self.health -= 1
                    self.score -= 1
                    self.done = not self.health
                    reward = 0
        if self.done: reward = -1
        if self.gui: self.render()
        return Step(self.get_state(), float(reward),
                    self.done, Info(self.score, self.health))

    def create_new_point(self, act):
        new_point_h, new_point_w = self.snake[0]
        if act is self.ACTION.UP:
            new_point_h -= 1
        elif act is self.ACTION.RIGHT:
            new_point_w += 1
        elif act is self.ACTION.DOWN:
            new_point_h += 1
        elif act is self.ACTION.LEFT:
            new_point_w -= 1
        else:
            raise ValueError('Invalid act {}'.format(act))

        bounds = {
            -1: self.board_height - 1,
            self.board_height: 0
        }
        if new_point_h in bounds:
            new_point_h = bounds[new_point_h]

        bounds = {
            -1: self.board_width - 1,
            self.board_width: 0
        }
        if new_point_w in bounds:
            new_point_w = bounds[new_point_w]

        self.snake.insert(0, Point(new_point_h, new_point_w))

    def remove_last_point(self):
        self.snake.pop()

    def food_eaten(self):
        return self.snake[0] == self.food

    def check_collisions(self):
        self.done = self.snake[0] in self.snake[1:]

    def keyboard_action(self):
        ch = self.win.getch()
        map = {
          curses.KEY_UP:    self.ACTION.UP,
          curses.KEY_RIGHT: self.ACTION.RIGHT,
          curses.KEY_DOWN:  self.ACTION.DOWN,
          curses.KEY_LEFT:  self.ACTION.LEFT,
        }
        return map[ch].value if ch in map else None

    def random_action(self):
        return random.choice(list(self.ACTION)).value

    def get_state(self):
        return State(Snake(self.snake[0], tuple(self.snake[1:])), self.food)

    def render_destroy(self):
        curses.endwin()

    def end_game(self):
        if self.gui: self.render_destroy()

if __name__ == "__main__":
    import time

    game = SnakeGame(gui = True)
    act  = game.random_action()
    try:
        while not game.done:
            time.sleep(0.2)
            new_act = game.keyboard_action()
            if new_act is not None: act = new_act
            state, *done_reward, info = game.step(act)
    except KeyboardInterrupt:
        pass

    game.end_game()
    *state, info = (tuple(p) for p in (
        state.snake.head, *state.snake.body, state.food, info) if p)
    print(*state, *done_reward, info)
