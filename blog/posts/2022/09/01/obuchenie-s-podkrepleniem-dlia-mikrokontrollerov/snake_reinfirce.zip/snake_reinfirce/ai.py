#!/usr/bin/env python3

from snake_game import SnakeGame
import time
import copy
import json

with open('snake.reinforce.json', 'r') as f:
  weights = json.load(f)

def mlp(x, test=None):
  dot  = lambda x, y: [sum(i * j[k] for i, j in zip(x, y)) for k in range(len(y[0]))]
  relu = lambda x: [max(i, 0) for i in x]
  add  = lambda x, y: [i + j for i, j in zip(x, y)]
  amax = lambda x: max(range(len(x)), key=lambda i: x[i])
  for w,b in zip(weights[::2], weights[1::2]):
    x = add(dot(x, w), b)
    if b is not weights[-1]: x = relu(x)
  if test:
    for i, j in zip(x, test):
      if abs(i - j) > 1e-5:
        raise AssertionError(str(i) + ' != ' + str(j))
  return amax(x)

def extract_features(game):
  obsticle = lambda k: copy.deepcopy(game).step(k).done
  snake, food = game.get_state()
  head,  food = [h + w * game.board_height for h, w in (snake.head, food)]
  obs = sum(v << i for i, v in enumerate(obsticle(k) for k in game.ACTION))
  max = game.board_height * game.board_width - 1
  return obs / 0b1111, head / max, food / max

def extract_features_wrapper(game):
  win, gui = game.win, game.gui
  game.win, game.gui = None, False
  fe = extract_features(game)
  game.win, game.gui = win, gui
  return fe

mlp(3*[0], [5.8412104, -4.8576665, -5.276733, -1.5355242])
mlp(3*[1], [6.1069336, -12.892834, -12.935051, 5.11665])

try:
  game = SnakeGame(gui = True)
  while not game.done:
    time.sleep(0.2)
    fe = extract_features_wrapper(game)
    action = mlp(fe)
    state, *done_reward, info = game.step(action)

except KeyboardInterrupt:
  pass

game.end_game()
*state, info = (tuple(p) for p in (
    state.snake.head, *state.snake.body, state.food, info) if p)
print(*state, *done_reward, info)
